package com.heart.campus.service.data.comment.mapper;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.CommentDO;
import com.heart.campus.service.data.comment.model.CommentModel;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

/**
 * Comment映射类
 *
 * @author: yuwu
 * @date: 2017/11/16
 */
@Repository("commentMapper")
public class CommentMapper implements AbstractMapper<CommentModel, CommentDO> {

    @Override
    public CommentModel toModel(CommentDO data) {
        if (data == null) {
            return null;
        }
        CommentModel model = new CommentModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public CommentDO toDO(CommentModel model) {
        if (model == null) {
            return null;
        }
        CommentDO data = new CommentDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
