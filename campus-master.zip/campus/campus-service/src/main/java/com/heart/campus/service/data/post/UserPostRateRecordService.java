package com.heart.campus.service.data.post;

import java.util.List;

import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.domain.ItemCluster;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.post.model.UserPostRateRecordModel;
import com.heart.campus.service.data.post.param.UserPostRateRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public interface UserPostRateRecordService extends AbstractService<UserPostRateRecordModel, UserPostRateRecordParam> {

    /**
     * K-means解析
     *
     * @param dataItems
     * @return
     */
    List<ItemCluster> doAnalysis(List<DataItem> dataItems);

}
