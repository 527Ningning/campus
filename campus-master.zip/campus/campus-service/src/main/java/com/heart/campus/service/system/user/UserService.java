package com.heart.campus.service.system.user;

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.system.user.model.UserModel;
import com.heart.campus.service.system.user.param.UserParam;

/**
 * User服务接口
 *
 * @author: heart
 * @date: 2017/11/2
 */
public interface UserService extends AbstractService<UserModel, UserParam> {


    /**
     * 删除用户信息（逻辑删除）
     *
     * @param id
     * @return 是否删除成功
     */
    Result<Boolean> delete(Long id);

    /**
     * 删除用户信息（物理删除）
     *
     * @param id
     * @return 是否删除成功
     */
    Result<Boolean> relDelete(Long id);

    /**
     * 根据userId查询用户信息
     *
     * @param userId
     * @return
     */
    Result<UserModel> getByUserId(String userId);

    /**
     * 根据用户名查询用户信息
     *
     * @param userName
     * @return
     */
    Result<UserModel> getByName(String userName);

}
