package com.heart.campus.service.system.role;

import java.util.List;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.system.role.model.RoleModel;
import com.heart.campus.service.system.role.param.RoleParam;

/**
 * 用户角色服务接口
 *
 * @author: heart
 * @date: 2017/11/12
 */
public interface RoleService extends AbstractService<RoleModel, RoleParam> {


    /**
     * 删除角色<逻辑>
     * 
     * @param id
     * @return
     */
    Result<Boolean> delete(Long id);

    /**
     * 删除角色<物理>
     * 
     * @param id
     * @return
     */
    Result<Boolean> relDelete(Long id);

    /**
     * 批量删除角色<逻辑>
     * 
     * @param idList
     * @return
     */
    Result<Integer> batchDelete(List<Long> idList);

    /**
     * 批量获取角色名称
     * 
     * @param idList
     * @return
     */
    Result<List<String>> batchGetNames(List<Long> idList);

    /**
     * 根据名称获取角色
     * 
     * @param roleName
     * @return
     */
    Result<RoleModel> getByName(String roleName);

}
