package com.heart.campus.service.data.post;

import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.post.model.PostTypeRecordModel;
import com.heart.campus.service.data.post.param.PostTypeRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public interface PostTypeRecordService extends AbstractService<PostTypeRecordModel, PostTypeRecordParam> {

}
