package com.heart.campus.service.data.post.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.dal.dao.data.PostDAO;
import com.heart.campus.dal.domain.data.PostDO;
import com.heart.campus.service.data.post.PostService;
import com.heart.campus.service.data.post.mapper.PostMapper;
import com.heart.campus.service.data.post.model.PostModel;
import com.heart.campus.service.data.post.param.PostParam;

/**
 * PostService接口实现类
 *
 * @author: yuwu
 * @date: 2017/11/14
 */
@Service("postService")
public class PostServiceImpl extends DefaultService<PostModel, PostDO, PostParam> implements PostService {

    private static final Logger LOG = LoggerFactory.getLogger("CampusLog");

    @Autowired
    private PostDAO             postDao;

    @Autowired
    private PostMapper          postMapper;

    @Override
    public Result<Boolean> delete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<PostModel> result = find(id);
        if (result == null || result.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PostModel model = result.getContent();
        model.setStatus(CommonStatusEnum.DELETE.getValue());
        return super.update(model);
    }

    @Override
    public Result<Boolean> relDelete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        PostParam delParam = new PostParam();
        delParam.setIdList(Arrays.asList(id));
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(true);
    }

    @Override
    public Result<Integer> batchDelete(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        PostParam delParam = new PostParam();
        delParam.setIdList(idList);
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(num);
    }

    @Override
    public Result<PostModel> getLiveById(Long postId) {
        if (postId == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        PostParam queryParam = new PostParam();
        List<Long> idList = new ArrayList<>();
        idList.add(postId);
        queryParam.setIdList(idList);
        queryParam.setStatus(CommonStatusEnum.NORMAL.getValue());
        Result<PageList<PostModel>> listResult = super.query(queryParam);
        if (listResult.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PageList<PostModel> typeList = listResult.getContent();

        return ResultGenerator.genSuccess(typeList.first());
    }

    @Override
    public AbstractMapper<PostModel, PostDO> getMapper() {
        return postMapper;
    }

    @Override
    public AbstractDAO<PostDO> getDao() {
        return postDao;
    }
}
