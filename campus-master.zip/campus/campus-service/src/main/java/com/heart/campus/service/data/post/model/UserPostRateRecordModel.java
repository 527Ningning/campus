package com.heart.campus.service.data.post.model;

import com.heart.campus.common.domain.AbstractModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class UserPostRateRecordModel extends AbstractModel {

    private String  userId;
    private Double  postRate;
    private Double  visitRate;
    private Double  commentRate;
    private Double  upvoteRate;
    private Integer status;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Double getPostRate() {
        return postRate;
    }

    public void setPostRate(Double postRate) {
        this.postRate = postRate;
    }

    public Double getVisitRate() {
        return visitRate;
    }

    public void setVisitRate(Double visitRate) {
        this.visitRate = visitRate;
    }

    public Double getCommentRate() {
        return commentRate;
    }

    public void setCommentRate(Double commentRate) {
        this.commentRate = commentRate;
    }

    public Double getUpvoteRate() {
        return upvoteRate;
    }

    public void setUpvoteRate(Double upvoteRate) {
        this.upvoteRate = upvoteRate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
