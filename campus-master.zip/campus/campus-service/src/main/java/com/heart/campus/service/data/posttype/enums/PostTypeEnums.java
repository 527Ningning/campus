package com.heart.campus.service.data.posttype.enums;

import com.heart.campus.common.util.StringUtil;

/**
 * @Description: 帖子类型枚举
 * @Author: heart
 * @Date: 2018/1/29
 */
public enum PostTypeEnums {

    /**
     * 校园百科
     */
    TREASURE_SKY(8, "校园百科"),
    /**
     * 勤工俭学
     */
    LOVE_SKY(4, "勤工俭学"),
    /**
     * 七嘴八舌
     */
    MOUTH_SKY(1, "七嘴八舌"),
    /**
     * 吃喝玩乐
     */
    EAT_SKY(2, "约喝约玩"),
    /**
     * 学术殿堂
     */
    STUDY_SKY(6, "学术殿堂"),
    /**
     * 二手市场
     */
    BUY_SELL_SKY(3, "二手市场"),
    /**
     * 求职天地
     */
    JOB_SKY(5, "求职天地"),
    /**
     * 失物招领
     */
    QUESTION_SKY(7, "失物招领");


    int code;
    String message;

    PostTypeEnums(int code) {
        this.code = code;
    }

    PostTypeEnums(String message) {
        this.message = message;
    }

    PostTypeEnums(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public static PostTypeEnums parseCode(int code) {
        for (PostTypeEnums e : PostTypeEnums.values()) {
            if (e.getCode() == code) {
                return e;
            }
        }
        return null;
    }

    public static PostTypeEnums parseName(String name) {
        if (StringUtil.isBlank(name)) {
            return null;
        }
        for (PostTypeEnums e : PostTypeEnums.values()) {
            if (e.name().equalsIgnoreCase(name)) {
                return e;
            }
        }
        return null;
    }
}

