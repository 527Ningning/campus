package com.heart.campus.service.data.post.param;

import java.util.Map;

import com.heart.campus.common.param.AbstractQueryParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class UserPostRateRecordParam extends AbstractQueryParam {

    private String  userId;
    private Integer status;

    private String  orderFiled;
    private String  orderType;

    @Override
    protected void addParams(Map<String, Object> existParam) {
        addIfNotNull(existParam, "userId", userId);
        addIfNotNull(existParam, "status", status);
    }

    @Override
    public void addLikeParams(Map<String, Object> existParam) {

    }

    @Override
    public String getOrderBy() {
        return orderFiled;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String getOrder() {
        return orderType;
    }
}
