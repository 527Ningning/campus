package com.heart.campus.service.data.post.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.heart.campus.common.algorithm.kmeans.KmeansHandler;
import com.heart.campus.common.algorithm.kmeans.KmeansModel;
import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.domain.ItemCluster;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.dal.dao.data.UserPostCountRecordDAO;
import com.heart.campus.dal.domain.data.UserPostCountRecordDO;
import com.heart.campus.service.data.post.UserPostCountRecordService;
import com.heart.campus.service.data.post.mapper.UserPostCountRecordMapper;
import com.heart.campus.service.data.post.model.UserPostCountRecordModel;
import com.heart.campus.service.data.post.param.UserPostCountRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Service("userCountRateRecodeService")
public class UserPostCountRecordServiceImpl extends DefaultService<UserPostCountRecordModel, UserPostCountRecordDO, UserPostCountRecordParam> implements UserPostCountRecordService {

    @Autowired
    private UserPostCountRecordDAO    userPostCountRecordDAO;

    @Autowired
    private UserPostCountRecordMapper userPostCountRecordMapper;

    @Override
    public AbstractMapper<UserPostCountRecordModel, UserPostCountRecordDO> getMapper() {
        return userPostCountRecordMapper;
    }

    @Override
    public AbstractDAO<UserPostCountRecordDO> getDao() {
        return userPostCountRecordDAO;
    }

    @Override
    public List<ItemCluster> doAnalysis(List<DataItem> dataItems) {
        if (CollectionUtil.isEmpty(dataItems)) {
            return null;
        }
        KmeansModel model = getKmeansModel(dataItems);
        List<ItemCluster> itemClusters = model.matrixToItemCluster();
        return itemClusters;
    }

    private KmeansModel getKmeansModel(List<DataItem> dataItems) {
        KmeansHandler kmeansHandler = new KmeansHandler();
        KmeansModel model = kmeansHandler.execute(dataItems);
        if (model == null) {
            return null;
        }
        return model;
    }
}
