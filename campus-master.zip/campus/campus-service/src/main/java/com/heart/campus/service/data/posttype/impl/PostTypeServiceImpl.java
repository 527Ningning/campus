package com.heart.campus.service.data.posttype.impl;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.common.util.StringUtil;
import com.heart.campus.dal.dao.data.PostTypeDAO;
import com.heart.campus.dal.domain.data.PostTypeDO;
import com.heart.campus.service.data.posttype.PostTypeService;
import com.heart.campus.service.data.posttype.mapper.PostTypeMapper;
import com.heart.campus.service.data.posttype.model.PostTypeModel;
import com.heart.campus.service.data.posttype.param.PostTypeParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 帖子类型服务实现类
 *
 * @author: yuwu
 * @date: 2017/11/13
 */
@Service("postTypeService")
public class PostTypeServiceImpl extends DefaultService<PostTypeModel, PostTypeDO, PostTypeParam> implements PostTypeService {

    private static final Logger LOG = LoggerFactory.getLogger("CampusLog");

    @Autowired
    private PostTypeDAO         postTypeDAO;

    @Autowired
    private PostTypeMapper      postTypeMapper;

    @Override
    public AbstractMapper<PostTypeModel, PostTypeDO> getMapper() {
        return postTypeMapper;
    }

    @Override
    public AbstractDAO<PostTypeDO> getDao() {
        return postTypeDAO;
    }

    @Override
    public Result<Boolean> delete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<PostTypeModel> typeById = find(id);
        if (typeById == null || typeById.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PostTypeModel typeModel = typeById.getContent();
        typeModel.setStatus(CommonStatusEnum.DELETE.getValue());
        return super.update(typeModel);
    }

    @Override
    public Result<Boolean> relDelete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        PostTypeParam delParam = new PostTypeParam();
        delParam.setIdList(Arrays.asList(id));
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(true);
    }

    @Override
    public Result<Integer> batchDelete(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        PostTypeParam delParam = new PostTypeParam();
        delParam.setIdList(idList);
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(num);
    }

    @Override
    public Result<List<String>> batchGetNames(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        PostTypeParam queryParam = new PostTypeParam();
        queryParam.setIdList(idList);
        Result<PageList<PostTypeModel>> result = super.query(queryParam);
        if (result.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        List<PostTypeModel> typeList = result.getContent().getDataList();
        if (CollectionUtil.isEmpty(typeList)) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        List<String> postTypes = new ArrayList<>();
        for (PostTypeModel postTypeModel : typeList) {
            postTypes.add(postTypeModel.getDesc());
        }
        return ResultGenerator.genSuccess(postTypes);
    }

    @Override
    public Result<PostTypeModel> getByName(String desc) {
        if (StringUtil.isBlank(desc)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        PostTypeParam queryParam = new PostTypeParam();
        queryParam.setDesc(desc);
        Result<PageList<PostTypeModel>> listResult = super.query(queryParam);
        if (listResult.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PageList<PostTypeModel> typeList = listResult.getContent();

        return ResultGenerator.genSuccess(typeList.first());
    }

}
