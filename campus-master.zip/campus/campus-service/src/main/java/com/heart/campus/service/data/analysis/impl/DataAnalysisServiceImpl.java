package com.heart.campus.service.data.analysis.impl;/**
 * Created by Administrator on 2018/3/23.
 */

import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.domain.ItemCluster;
import com.heart.campus.service.data.analysis.DataAnalysisService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/23
 */
@Service("dataAnalysisService")
public class DataAnalysisServiceImpl implements DataAnalysisService {

    @Override
    public List<ItemCluster> doClusterAnalysis(List<DataItem> dataItems) {
        return null;
    }
}

