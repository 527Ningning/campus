package com.heart.campus.service.data.posttype.param;

import com.heart.campus.common.param.AbstractQueryParam;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 帖子类型查询参数
 *
 * @author: yuwu
 * @date: 2017/11/13
 */
public class PostTypeParam extends AbstractQueryParam {

    /**
     * 帖子类型
     */
    private String       desc;

    /**
     * 删除标志位
     */
    private Integer      status;

    /**
     * 排序参数 需要使用排序的数据均需要该字段
     *
     * @param existParam
     */
    private String       orderFiled;
    private String       orderType;

    private List<Long>   idList     = new ArrayList<>();
    private List<String> statusList = new ArrayList<>();

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getOrderFiled() {
        return orderFiled;
    }

    public void setOrderFiled(String orderFiled) {
        this.orderFiled = orderFiled;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    @Override
    protected void addParams(Map<String, Object> existParam) {
        addIfNotEmpty(existParam, "desc", desc);
        addIfNotNull(existParam, "status", status);
        addIfNotEmpty(existParam, "statusList", statusList);
        addIfNotEmpty(existParam, "idList", idList);
    }

    @Override
    public void addLikeParams(Map<String, Object> existParam) {

    }

    @Override
    public String getOrderBy() {
        return orderFiled;
    }

    @Override
    public String getOrder() {
        return orderType;
    }
}
