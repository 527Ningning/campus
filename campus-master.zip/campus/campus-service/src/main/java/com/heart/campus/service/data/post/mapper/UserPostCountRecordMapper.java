package com.heart.campus.service.data.post.mapper;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.UserPostCountRecordDO;
import com.heart.campus.service.data.post.model.UserPostCountRecordModel;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Repository("userPostCountRecordMapper")
public class UserPostCountRecordMapper implements AbstractMapper<UserPostCountRecordModel, UserPostCountRecordDO> {

    @Override
    public UserPostCountRecordModel toModel(UserPostCountRecordDO data) {
        if (data == null) {
            return null;
        }
        UserPostCountRecordModel model = new UserPostCountRecordModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public UserPostCountRecordDO toDO(UserPostCountRecordModel model) {
        if (model == null) {
            return null;
        }
        UserPostCountRecordDO data = new UserPostCountRecordDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}

