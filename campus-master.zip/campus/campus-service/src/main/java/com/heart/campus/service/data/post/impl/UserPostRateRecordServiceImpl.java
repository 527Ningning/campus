package com.heart.campus.service.data.post.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.heart.campus.common.algorithm.kmeans.KmeansHandler;
import com.heart.campus.common.algorithm.kmeans.KmeansModel;
import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.domain.ItemCluster;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.dal.dao.data.UserPostRateRecordDAO;
import com.heart.campus.dal.domain.data.UserPostRateRecordDO;
import com.heart.campus.service.data.post.UserPostRateRecordService;
import com.heart.campus.service.data.post.mapper.UserPostRateRecordMapper;
import com.heart.campus.service.data.post.model.UserPostRateRecordModel;
import com.heart.campus.service.data.post.param.UserPostRateRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Service("userPostRateRecodeService")
public class UserPostRateRecordServiceImpl extends DefaultService<UserPostRateRecordModel, UserPostRateRecordDO, UserPostRateRecordParam> implements UserPostRateRecordService {

    @Autowired
    private UserPostRateRecordDAO    userPostRateRecordDAO;

    @Autowired
    private UserPostRateRecordMapper userPostRateRecordMapper;

    @Override
    public AbstractMapper<UserPostRateRecordModel, UserPostRateRecordDO> getMapper() {
        return userPostRateRecordMapper;
    }

    @Override
    public AbstractDAO<UserPostRateRecordDO> getDao() {
        return userPostRateRecordDAO;
    }

    @Override
    public List<ItemCluster> doAnalysis(List<DataItem> dataItems) {
        if (CollectionUtil.isEmpty(dataItems)) {
            return null;
        }
        KmeansModel model = getKmeansModel(dataItems);
        if (model == null) return null;
        List<ItemCluster> itemClusters = model.matrixToItemCluster();
        return itemClusters;
    }

    private KmeansModel getKmeansModel(List<DataItem> dataItems) {
        KmeansHandler kmeansHandler = new KmeansHandler();
        KmeansModel model = kmeansHandler.execute(dataItems);
        if (model == null) {
            return null;
        }
        return model;
    }
}
