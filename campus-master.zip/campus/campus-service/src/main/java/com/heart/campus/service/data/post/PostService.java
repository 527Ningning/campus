package com.heart.campus.service.data.post;

import java.util.List;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.post.model.PostModel;
import com.heart.campus.service.data.post.param.PostParam;

/**
 * PostService服务接口
 *
 * @author: yuwu
 * @date: 2017/11/14
 */

public interface PostService extends AbstractService<PostModel, PostParam> {

    /**
     * 删除帖子<逻辑>
     *
     * @param id
     * @return
     */
    Result<Boolean> delete(Long id);

    /**
     * 删除帖子<物理>
     *
     * @param id
     * @return
     */
    Result<Boolean> relDelete(Long id);

    /**
     * 批量删除帖子<逻辑>
     *
     * @param idList
     * @return
     */
    Result<Integer> batchDelete(List<Long> idList);

    /**
     * 批量获取帖子名称
     *
     * @param idList
     * @return
     */
    // Result<List<String>> batchGetNames(List<Long> idList);

    /**
     * 根据帖子id(postId)描述获取帖子
     *
     * @param postId
     * @return
     */
    Result<PostModel> getLiveById(Long postId);

    // Result<PostModel> getBy
}
