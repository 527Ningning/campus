package com.heart.campus.service.system.user.param;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.heart.campus.common.param.AbstractQueryParam;

/**
 * 用户查询参数
 *
 * @author: heart
 * @date: 2017/11/2
 */
public class UserParam extends AbstractQueryParam {

    /**
     * 用户学号
     */
    private String userId;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 用户手机号
     */
    private String userPhone;

    /**
     * 用户学院
     */
    private String userSchool;

    /**
     * 用户专业
     */
    private String userSubject;

    /**
     * 用户状态
     */
    private Integer status;

    /**
     * 排序参数 需要使用排序的数据均需要该字段
     *
     * @param existParam
     */
    private String orderFiled;
    private String orderType;

    private List<Long> idList = new ArrayList<>();
    private List<String> statusList = new ArrayList<>();

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getUserSchool() {
        return userSchool;
    }

    public void setUserSchool(String userSchool) {
        this.userSchool = userSchool;
    }

    public String getUserSubject() {
        return userSubject;
    }

    public void setUserSubject(String userSubject) {
        this.userSubject = userSubject;
    }

    public String getOrderFiled() {
        return orderFiled;
    }

    public void setOrderFiled(String orderFiled) {
        this.orderFiled = orderFiled;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    protected void addParams(Map<String, Object> existParam) {
        addIfNotEmpty(existParam, "userId", userId);
        addIfNotEmpty(existParam, "userName", userName);
        addIfNotEmpty(existParam, "userSchool", userSchool);
        addIfNotEmpty(existParam, "userSubject", userSubject);
        addIfNotEmpty(existParam, "statusList", statusList);
        addIfNotEmpty(existParam, "idList", idList);
        addIfNotNull(existParam, "status", status);
    }

    @Override
    public void addLikeParams(Map<String, Object> existParam) {
        addIfNotEmpty(existParam, "userPhone", userPhone);
    }

    @Override
    public String getOrderBy() {
        return orderFiled;
    }

    @Override
    public String getOrder() {
        return orderType;
    }
}
