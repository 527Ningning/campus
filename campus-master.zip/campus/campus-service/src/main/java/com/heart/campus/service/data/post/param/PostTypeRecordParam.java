package com.heart.campus.service.data.post.param;

import java.util.Map;

import com.heart.campus.common.param.AbstractQueryParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostTypeRecordParam extends AbstractQueryParam {

    private Integer gender;

    private String  orderFiled;
    private String  orderType;

    @Override
    protected void addParams(Map<String, Object> existParam) {
        addIfNotNull(existParam, "gender", gender);
    }

    @Override
    public void addLikeParams(Map<String, Object> existParam) {

    }

    @Override
    public String getOrderBy() {
        return orderFiled;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    @Override
    public String getOrder() {
        return orderType;
    }
}
