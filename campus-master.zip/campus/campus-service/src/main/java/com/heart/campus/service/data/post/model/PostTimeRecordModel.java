package com.heart.campus.service.data.post.model;

import com.heart.campus.common.domain.AbstractModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostTimeRecordModel extends AbstractModel {

    private Integer hour;
    private Integer week;
    private Integer gender;
    private Integer number;
    private Integer status;

    public Integer getHour() {
        return hour;
    }

    public void setHour(Integer hour) {
        this.hour = hour;
    }

    public Integer getWeek() {
        return week;
    }

    public void setWeek(Integer week) {
        this.week = week;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
