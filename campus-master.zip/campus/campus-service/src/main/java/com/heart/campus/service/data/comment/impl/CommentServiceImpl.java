package com.heart.campus.service.data.comment.impl;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.common.util.StringUtil;
import com.heart.campus.dal.dao.data.CommentDAO;
import com.heart.campus.dal.domain.data.CommentDO;
import com.heart.campus.service.data.comment.CommentService;
import com.heart.campus.service.data.comment.mapper.CommentMapper;
import com.heart.campus.service.data.comment.model.CommentModel;
import com.heart.campus.service.data.comment.param.CommentParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

/**
 * CommentService接口实现类
 *
 * @author: yuwu
 * @date: 2017/11/16
 */
@Service("commentService")
public class CommentServiceImpl extends DefaultService<CommentModel, CommentDO, CommentParam> implements CommentService {

    @Autowired
    CommentDAO    commentDao;

    @Autowired
    CommentMapper commentMapper;

    @Override
    public Result<Boolean> delete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<CommentModel> result = find(id);
        if (result == null || result.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        CommentModel model = result.getContent();
        model.setStatus(CommonStatusEnum.DELETE.getValue());
        return super.update(model);
    }

    @Override
    public Result<Boolean> relDelete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        CommentParam delParam = new CommentParam();
        delParam.setIdList(Arrays.asList(id));
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(true);
    }

    @Override
    public Result<Integer> batchDelete(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        CommentParam delParam = new CommentParam();
        delParam.setIdList(idList);
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(num);
    }

    @Override
    public Result<CommentModel> getByCommentId(String commentId) {
        if (StringUtil.isBlank(commentId)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        CommentParam queryParam = new CommentParam();
        queryParam.setCommentId(commentId);
        Result<PageList<CommentModel>> listResult = super.query(queryParam);
        if (listResult.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PageList<CommentModel> typeList = listResult.getContent();

        return ResultGenerator.genSuccess(typeList.first());
    }

    @Override
    public AbstractMapper<CommentModel, CommentDO> getMapper() {
        return commentMapper;
    }

    @Override
    public AbstractDAO<CommentDO> getDao() {
        return commentDao;
    }
}
