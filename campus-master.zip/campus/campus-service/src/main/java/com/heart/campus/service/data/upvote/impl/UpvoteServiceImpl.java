package com.heart.campus.service.data.upvote.impl;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.dal.dao.data.UpvoteDAO;
import com.heart.campus.dal.domain.data.UpvoteDO;
import com.heart.campus.service.data.upvote.UpvoteService;
import com.heart.campus.service.data.upvote.mapper.UpvoteMapper;
import com.heart.campus.service.data.upvote.model.UpvoteModel;
import com.heart.campus.service.data.upvote.param.UpvoteParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

/**
 * UpvoteService接口实现类
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
@Service("upvoteService")
public class UpvoteServiceImpl extends DefaultService<UpvoteModel, UpvoteDO, UpvoteParam> implements UpvoteService {

    private static final Logger LOG = LoggerFactory.getLogger("CampusLog");

    @Autowired
    private UpvoteDAO           upvoteDAO;

    @Autowired
    private UpvoteMapper        upvoteMapper;

    @Override
    public AbstractMapper<UpvoteModel, UpvoteDO> getMapper() {
        return upvoteMapper;
    }

    @Override
    public AbstractDAO<UpvoteDO> getDao() {
        return upvoteDAO;
    }

    @Override
    public Result<Boolean> delete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<UpvoteModel> byId = find(id);
        if (byId == null || byId.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        UpvoteModel model = byId.getContent();
        model.setStatus(CommonStatusEnum.DELETE.getValue());
        return super.update(model);
    }

    @Override
    public Result<Boolean> relDelete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        UpvoteParam delParam = new UpvoteParam();
        delParam.setIdList(Arrays.asList(id));
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(true);
    }

    @Override
    public Result<Integer> batchDelete(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        UpvoteParam delParam = new UpvoteParam();
        delParam.setIdList(idList);
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(num);
    }
}
