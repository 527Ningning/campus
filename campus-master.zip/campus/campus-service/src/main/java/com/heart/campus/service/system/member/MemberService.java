package com.heart.campus.service.system.member;

import java.util.List;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.system.member.model.MemberModel;
import com.heart.campus.service.system.member.param.MemberParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/5/9
 */
public interface MemberService extends AbstractService<MemberModel, MemberParam> {

    /**
     * 获取团队成员的概要信息列表
     *
     * @return
     */
    Result<List<MemberModel>> loadMemberList();

}
