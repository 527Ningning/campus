package com.heart.campus.service.data.post.model;

import com.heart.campus.common.domain.AbstractModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostTypeRecordModel extends AbstractModel {

    private Integer typeId;
    private Integer gender;
    private Integer number;
    private Integer status;

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
