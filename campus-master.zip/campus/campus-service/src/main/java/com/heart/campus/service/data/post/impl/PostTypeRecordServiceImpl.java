package com.heart.campus.service.data.post.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.dal.dao.data.PostTypeRecordDAO;
import com.heart.campus.dal.domain.data.PostTypeRecordDO;
import com.heart.campus.service.data.post.PostTypeRecordService;
import com.heart.campus.service.data.post.mapper.PostTypeRecordMapper;
import com.heart.campus.service.data.post.model.PostTypeRecordModel;
import com.heart.campus.service.data.post.param.PostTypeRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Service("postTypeRecodeService")
public class PostTypeRecordServiceImpl extends DefaultService<PostTypeRecordModel, PostTypeRecordDO, PostTypeRecordParam> implements PostTypeRecordService {

    @Autowired
    private PostTypeRecordDAO    postTypeRecordDAO;

    @Autowired
    private PostTypeRecordMapper postTypeRecordMapper;

    @Override
    public AbstractMapper<PostTypeRecordModel, PostTypeRecordDO> getMapper() {
        return postTypeRecordMapper;
    }

    @Override
    public AbstractDAO<PostTypeRecordDO> getDao() {
        return postTypeRecordDAO;
    }

}
