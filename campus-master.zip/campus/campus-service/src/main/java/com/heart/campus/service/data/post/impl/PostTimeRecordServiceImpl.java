package com.heart.campus.service.data.post.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.dal.dao.data.PostTimeRecordDAO;
import com.heart.campus.dal.domain.data.PostTimeRecordDO;
import com.heart.campus.service.data.post.PostTimeRecordService;
import com.heart.campus.service.data.post.mapper.PostTimeRecordMapper;
import com.heart.campus.service.data.post.model.PostTimeRecordModel;
import com.heart.campus.service.data.post.param.PostTimeRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Service("postTimeRecordService")
public class PostTimeRecordServiceImpl extends DefaultService<PostTimeRecordModel, PostTimeRecordDO, PostTimeRecordParam> implements PostTimeRecordService {

    @Autowired
    private PostTimeRecordDAO    postTimeRecordDAO;

    @Autowired
    private PostTimeRecordMapper postTimeRecordMapper;

    @Override
    public AbstractMapper<PostTimeRecordModel, PostTimeRecordDO> getMapper() {
        return postTimeRecordMapper;
    }

    @Override
    public AbstractDAO<PostTimeRecordDO> getDao() {
        return postTimeRecordDAO;
    }

}
