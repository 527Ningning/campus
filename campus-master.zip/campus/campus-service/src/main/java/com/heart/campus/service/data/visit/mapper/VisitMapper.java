package com.heart.campus.service.data.visit.mapper;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.VisitDO;
import com.heart.campus.service.data.visit.model.VisitModel;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

/**
 * Visit 映射类
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
@Repository("visitMapper")
public class VisitMapper implements AbstractMapper<VisitModel, VisitDO> {

    @Override
    public VisitModel toModel(VisitDO data) {
        if (data == null) {
            return null;
        }
        VisitModel model = new VisitModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public VisitDO toDO(VisitModel model) {
        if (model == null) {
            return null;
        }
        VisitDO data = new VisitDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
