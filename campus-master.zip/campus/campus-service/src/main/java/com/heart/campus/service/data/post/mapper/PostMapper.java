package com.heart.campus.service.data.post.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.PostDO;
import com.heart.campus.service.data.post.model.PostModel;

/**
 * Post映射类
 *
 * @author: yuwu
 * @date: 2017/11/14
 */
@Repository("postMapper")
public class PostMapper implements AbstractMapper<PostModel, PostDO> {

    @Override
    public PostModel toModel(PostDO data) {
        if (data == null) {
            return null;
        }
        PostModel model = new PostModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public PostDO toDO(PostModel model) {
        if (model == null) {
            return null;
        }
        PostDO data = new PostDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
