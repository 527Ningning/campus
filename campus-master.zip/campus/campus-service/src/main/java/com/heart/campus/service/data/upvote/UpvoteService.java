package com.heart.campus.service.data.upvote;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.upvote.model.UpvoteModel;
import com.heart.campus.service.data.upvote.param.UpvoteParam;
import java.util.List;

/**
 * 点赞服务接口
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
public interface UpvoteService extends AbstractService<UpvoteModel, UpvoteParam> {

    /**
     * 删除用户点赞记录<逻辑>
     *
     * @param id
     * @return
     */
    Result<Boolean> delete(Long id);

    /**
     * 删除用户点赞记录<物理>
     *
     * @param id
     * @return
     */
    Result<Boolean> relDelete(Long id);

    /**
     * 批量删除用户点赞记录<逻辑>
     *
     * @param idList
     * @return
     */
    Result<Integer> batchDelete(List<Long> idList);

}
