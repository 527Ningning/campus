package com.heart.campus.service.system.member.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.dal.dao.system.MemberDAO;
import com.heart.campus.dal.domain.system.MemberDO;
import com.heart.campus.service.system.member.MemberService;
import com.heart.campus.service.system.member.mapper.MemberMapper;
import com.heart.campus.service.system.member.model.MemberModel;
import com.heart.campus.service.system.member.param.MemberParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/5/9
 */
@Service("memberService")
public class MemberServiceImpl extends DefaultService<MemberModel, MemberDO, MemberParam> implements MemberService {

    @Autowired
    private MemberDAO    memberDAO;

    @Autowired
    private MemberMapper memberMapper;

    @Override
    public Result<List<MemberModel>> loadMemberList() {
        List<MemberModel> memberModels = new ArrayList<>();
        List<MemberDO> memberDOS = memberDAO.loadMemberList();
        for (MemberDO data : memberDOS) {
            MemberModel model = new MemberModel();
            BeanUtils.copyProperties(data, model);
            memberModels.add(model);
        }
        return ResultGenerator.genSuccess(memberModels);
    }

    @Override
    public AbstractMapper<MemberModel, MemberDO> getMapper() {
        return memberMapper;
    }

    @Override
    public AbstractDAO<MemberDO> getDao() {
        return memberDAO;
    }
}
