package com.heart.campus.service.data.visit.impl;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.dal.dao.data.VisitDAO;
import com.heart.campus.dal.domain.data.VisitDO;
import com.heart.campus.service.data.visit.VisitService;
import com.heart.campus.service.data.visit.mapper.VisitMapper;
import com.heart.campus.service.data.visit.model.VisitModel;
import com.heart.campus.service.data.visit.param.VisitParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

/**
 * visitService接口实现类
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
@Service("visitService")
public class VisitServiceImpl extends DefaultService<VisitModel, VisitDO, VisitParam> implements VisitService {

    private static final Logger LOG = LoggerFactory.getLogger("CampusLog");

    @Autowired
    private VisitDAO            visitDAO;

    @Autowired
    private VisitMapper         visitMapper;

    @Override
    public AbstractMapper<VisitModel, VisitDO> getMapper() {
        return visitMapper;
    }

    @Override
    public AbstractDAO<VisitDO> getDao() {
        return visitDAO;
    }

    @Override
    public Result<Boolean> delete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<VisitModel> typeById = find(id);
        if (typeById == null || typeById.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        VisitModel model = typeById.getContent();
        model.setStatus(CommonStatusEnum.DELETE.getValue());
        return super.update(model);
    }

    @Override
    public Result<Boolean> relDelete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        VisitParam delParam = new VisitParam();
        delParam.setIdList(Arrays.asList(id));
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(true);
    }

    @Override
    public Result<Integer> batchDelete(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        VisitParam delParam = new VisitParam();
        delParam.setIdList(idList);
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(num);
    }
}
