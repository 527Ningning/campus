package com.heart.campus.service.data.visit;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.visit.model.VisitModel;
import com.heart.campus.service.data.visit.param.VisitParam;

import java.util.List;

/**
 * Viist服务接口
 * 
 * @author: yuwu
 * @date: 2017/11/29
 */
public interface VisitService extends AbstractService<VisitModel, VisitParam> {

    /**
     * 删除用户浏览记录<逻辑>
     *
     * @param id
     * @return
     */
    Result<Boolean> delete(Long id);

    /**
     * 删除用户浏览记录<物理>
     *
     * @param id
     * @return
     */
    Result<Boolean> relDelete(Long id);

    /**
     * 批量删除用户浏览记录<逻辑>
     *
     * @param idList
     * @return
     */
    Result<Integer> batchDelete(List<Long> idList);

}
