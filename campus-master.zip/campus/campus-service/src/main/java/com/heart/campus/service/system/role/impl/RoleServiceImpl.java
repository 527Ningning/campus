package com.heart.campus.service.system.role.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.common.util.StringUtil;
import com.heart.campus.dal.dao.system.RoleDAO;
import com.heart.campus.dal.domain.system.RoleDO;
import com.heart.campus.service.system.role.RoleService;
import com.heart.campus.service.system.role.mapper.RoleMapper;
import com.heart.campus.service.system.role.model.RoleModel;
import com.heart.campus.service.system.role.param.RoleParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 用户角色服务实现类
 *
 * @author: heart
 * @date: 2017/11/12
 */
@Service("roleService")
public class RoleServiceImpl extends DefaultService<RoleModel, RoleDO, RoleParam> implements RoleService {

    @Autowired
    private RoleDAO    roleDAO;

    @Autowired
    private RoleMapper roleMapper;

    @Override
    public AbstractMapper<RoleModel, RoleDO> getMapper() {
        return roleMapper;
    }

    @Override
    public AbstractDAO<RoleDO> getDao() {
        return roleDAO;
    }

    @Override
    public Result<Boolean> delete(Long id) {

        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<RoleModel> roleById = find(id);
        if (roleById == null || roleById.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        RoleModel roleModel = roleById.getContent();
        roleModel.setStatus(CommonStatusEnum.DELETE.getValue());
        return super.update(roleModel);
    }

    @Override
    public Result<Boolean> relDelete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        RoleParam delParam = new RoleParam();
        delParam.setIdList(Arrays.asList(id));
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(true);
    }

    @Override
    public Result<Integer> batchDelete(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        RoleParam delParam = new RoleParam();
        delParam.setIdList(idList);
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(num);
    }

    @Override
    public Result<List<String>> batchGetNames(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        RoleParam queryParam = new RoleParam();
        queryParam.setIdList(idList);
        Result<PageList<RoleModel>> result = super.query(queryParam);
        if (result.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        List<RoleModel> roleList = result.getContent().getDataList();
        if (CollectionUtil.isEmpty(roleList)) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        List<String> roleNames = new ArrayList<>();
        for (RoleModel role : roleList) {
            roleNames.add(role.getName());
        }
        return ResultGenerator.genSuccess(roleNames);
    }

    @Override
    public Result<RoleModel> getByName(String roleName) {
        if (StringUtil.isBlank(roleName)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        RoleParam queryParam = new RoleParam();
        queryParam.setName(roleName);
        Result<PageList<RoleModel>> listResult = super.query(queryParam);
        if (listResult.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PageList<RoleModel> roleList = listResult.getContent();

        return ResultGenerator.genSuccess(roleList.first());
    }

}
