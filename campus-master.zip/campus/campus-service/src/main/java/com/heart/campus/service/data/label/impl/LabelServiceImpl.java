package com.heart.campus.service.data.label.impl;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.common.util.StringUtil;
import com.heart.campus.dal.dao.data.LabelDAO;
import com.heart.campus.dal.domain.data.LabelDO;
import com.heart.campus.service.data.label.LabelService;
import com.heart.campus.service.data.label.mapper.LabelMapper;
import com.heart.campus.service.data.label.model.LabelModel;
import com.heart.campus.service.data.label.param.LabelParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Label服务实现接口
 *
 * @author: yuwu
 * @date: 2017/12/23
 */
@Service("labelService")
public class LabelServiceImpl extends DefaultService<LabelModel, LabelDO, LabelParam> implements LabelService {

    @Autowired
    private LabelDAO    labelDAO;

    @Autowired
    private LabelMapper labelMapper;

    @Override
    public AbstractMapper<LabelModel, LabelDO> getMapper() {
        return labelMapper;
    }

    @Override
    public AbstractDAO<LabelDO> getDao() {
        return labelDAO;
    }

    @Override
    public Result<Boolean> delete(Long id) {

        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<LabelModel> byId = find(id);
        if (byId == null || byId.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        LabelModel model = byId.getContent();
        model.setStatus(CommonStatusEnum.DELETE.getValue());
        return super.update(model);
    }

    @Override
    public Result<Boolean> relDelete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        LabelParam delParam = new LabelParam();
        delParam.setIdList(Arrays.asList(id));
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(true);
    }

    @Override
    public Result<Integer> batchDelete(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        LabelParam delParam = new LabelParam();
        delParam.setIdList(idList);
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(num);
    }

    @Override
    public Result<List<String>> batchGetNames(List<Long> idList) {
        if (CollectionUtil.isEmpty(idList)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        LabelParam queryParam = new LabelParam();
        queryParam.setIdList(idList);
        Result<PageList<LabelModel>> result = super.query(queryParam);
        if (result.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        List<LabelModel> list = result.getContent().getDataList();
        if (CollectionUtil.isEmpty(list)) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        List<String> roleNames = new ArrayList<>();
        for (LabelModel model : list) {
            roleNames.add(model.getLabel());
        }
        return ResultGenerator.genSuccess(roleNames);
    }

    @Override
    public Result<LabelModel> getByLabel(String label) {
        if (StringUtil.isBlank(label)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        LabelParam queryParam = new LabelParam();
        queryParam.setLabel(label);
        Result<PageList<LabelModel>> listResult = super.query(queryParam);
        if (listResult.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PageList<LabelModel> roleList = listResult.getContent();

        return ResultGenerator.genSuccess(roleList.first());
    }
}
