package com.heart.campus.service.data.comment;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.comment.model.CommentModel;
import com.heart.campus.service.data.comment.param.CommentParam;
import java.util.List;

/**
 * Comment服务接口类
 *
 * @author: yuwu
 * @date: 2017/11/16
 */
public interface CommentService extends AbstractService<CommentModel, CommentParam> {

    /**
     * 删除评论<逻辑>
     *
     * @param id
     * @return
     */
    Result<Boolean> delete(Long id);

    /**
     * 删除评论<物理>
     *
     * @param id
     * @return
     */
    Result<Boolean> relDelete(Long id);

    /**
     * 批量删除评论<逻辑>
     *
     * @param idList
     * @return
     */
    Result<Integer> batchDelete(List<Long> idList);

    /**
     * 批量获取评论名称
     *
     * @param idList
     * @return
     */
//    Result<List<String>> batchGetNames(List<Long> idList);

    /**
     * 根据评论id(commentId)描述获取评论
     *
     * @param commentId
     * @return
     */
    Result<CommentModel> getByCommentId(String commentId);


}
