package com.heart.campus.service.system.role.mapper;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.system.RoleDO;
import com.heart.campus.service.system.role.model.RoleModel;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

/**
 * 用户角色映射类
 *
 * @author: heart
 * @date: 2017/11/12
 */
@Repository("roleMapper")
public class RoleMapper implements AbstractMapper<RoleModel, RoleDO> {

    @Override
    public RoleModel toModel(RoleDO data) {
        if (data == null) {
            return null;
        }
        RoleModel model = new RoleModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public RoleDO toDO(RoleModel model) {
        if (model == null) {
            return null;
        }
        RoleDO data = new RoleDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
