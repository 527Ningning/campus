package com.heart.campus.service.data.post.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.PostTypeRecordDO;
import com.heart.campus.service.data.post.model.PostTypeRecordModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Repository("postTypeRecordMapper")
public class PostTypeRecordMapper implements AbstractMapper<PostTypeRecordModel, PostTypeRecordDO> {

    @Override
    public PostTypeRecordModel toModel(PostTypeRecordDO data) {
        if (data == null) {
            return null;
        }
        PostTypeRecordModel model = new PostTypeRecordModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public PostTypeRecordDO toDO(PostTypeRecordModel model) {
        if (model == null) {
            return null;
        }
        PostTypeRecordDO data = new PostTypeRecordDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
