package com.heart.campus.service.system.member.param;

import java.util.Map;

import com.heart.campus.common.param.AbstractQueryParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/5/9
 */
public class MemberParam extends AbstractQueryParam {

    /**
     * 删除标志位
     */
    private Integer status;

    /**
     * 排序参数 需要使用排序的数据均需要该字段
     *
     * @param existParam
     */
    private String  orderFiled;
    private String  orderType;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public void addLikeParams(Map<String, Object> existParam) {

    }

    @Override
    public String getOrderBy() {
        return orderFiled;
    }

    @Override
    public String getOrder() {
        return orderType;
    }

    @Override
    protected void addParams(Map<String, Object> existParam) {
        addIfNotNull(existParam, "status", status);
    }
}
