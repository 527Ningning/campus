package com.heart.campus.service.data.analysis;/**
 * Created by Administrator on 2018/3/23.
 */

import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.domain.ItemCluster;

import java.util.List;

/**
 * @Description: 数据分析服务接口
 * @Author: heart
 * @Date: 2018/3/23
 */
public interface DataAnalysisService {

    /**
     * K-means数据分析接口
     *
     * @param dataItems
     * @return
     */
    List<ItemCluster> doClusterAnalysis(List<DataItem> dataItems);

}
