package com.heart.campus.service.data.upvote.mapper;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.UpvoteDO;
import com.heart.campus.service.data.upvote.model.UpvoteModel;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

/**
 * Upvote 映射类
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
@Repository("upvoteMapper")
public class UpvoteMapper implements AbstractMapper<UpvoteModel, UpvoteDO> {

    @Override
    public UpvoteModel toModel(UpvoteDO data) {
        if (data == null) {
            return null;
        }
        UpvoteModel model = new UpvoteModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public UpvoteDO toDO(UpvoteModel model) {
        if (model == null) {
            return null;
        }
        UpvoteDO data = new UpvoteDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
