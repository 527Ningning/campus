package com.heart.campus.service.data.label.mapper;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.LabelDO;
import com.heart.campus.service.data.label.model.LabelModel;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

/**
 * 标签映射类
 *
 * @author: yuwu
 * @date: 2017/12/23
 */
@Repository("labelMapper")
public class LabelMapper implements AbstractMapper<LabelModel, LabelDO> {

    @Override
    public LabelModel toModel(LabelDO data) {
        if (data == null) {
            return null;
        }
        LabelModel model = new LabelModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public LabelDO toDO(LabelModel model) {
        if (model == null) {
            return null;
        }
        LabelDO data = new LabelDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
