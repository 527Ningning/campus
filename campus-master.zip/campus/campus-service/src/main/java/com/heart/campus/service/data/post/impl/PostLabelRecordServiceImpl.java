package com.heart.campus.service.data.post.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.dal.dao.data.PostLabelRecordDAO;
import com.heart.campus.dal.domain.data.PostLabelRecordDO;
import com.heart.campus.service.data.post.PostLabelRecordService;
import com.heart.campus.service.data.post.mapper.PostLabelRecordMapper;
import com.heart.campus.service.data.post.model.PostLabelRecordModel;
import com.heart.campus.service.data.post.param.PostLabelRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Service("PostLabelRecodeService")
public class PostLabelRecordServiceImpl extends DefaultService<PostLabelRecordModel, PostLabelRecordDO, PostLabelRecordParam> implements PostLabelRecordService {

    @Autowired
    private PostLabelRecordDAO    PostLabelRecordDAO;

    @Autowired
    private PostLabelRecordMapper PostLabelRecordMapper;

    @Override
    public AbstractMapper<PostLabelRecordModel, PostLabelRecordDO> getMapper() {
        return PostLabelRecordMapper;
    }

    @Override
    public AbstractDAO<PostLabelRecordDO> getDao() {
        return PostLabelRecordDAO;
    }

}
