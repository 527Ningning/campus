package com.heart.campus.service.system.member.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.system.MemberDO;
import com.heart.campus.service.system.member.model.MemberModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/5/9
 */
@Repository("memberMapper")
public class MemberMapper implements AbstractMapper<MemberModel, MemberDO> {

    @Override
    public MemberModel toModel(MemberDO data) {
        if (data == null) {
            return null;
        }
        MemberModel model = new MemberModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public MemberDO toDO(MemberModel model) {
        if (model == null) {
            return null;
        }
        MemberDO data = new MemberDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
