package com.heart.campus.service.system.user.mapper;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.system.UserDO;
import com.heart.campus.service.system.user.model.UserModel;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

/**
 * 用户映射类
 *
 * @author: heart
 * @date: 2017/11/2
 */
@Repository("userMapper")
public class UserMapper implements AbstractMapper<UserModel, UserDO> {

    @Override
    public UserModel toModel(UserDO data) {
        if (data == null) {
            return null;
        }
        UserModel model = new UserModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public UserDO toDO(UserModel model) {
        if (model == null) {
            return null;
        }
        UserDO data = new UserDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
