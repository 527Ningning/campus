package com.heart.campus.service.data.post;

import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.post.model.PostLabelRecordModel;
import com.heart.campus.service.data.post.param.PostLabelRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public interface PostLabelRecordService extends AbstractService<PostLabelRecordModel, PostLabelRecordParam> {

}
