package com.heart.campus.service.data.label.enums;/**
 * Created by Administrator on 2018/3/22.
 */

import com.heart.campus.common.util.StringUtil;

/**
 * @Description: 标签类型枚举
 * @Author: heart
 * @Date: 2018/3/22
 */
public enum LabelEnum {

    /**
     * 日常
     */
    DAILY(1, "日常"),

    /**
     * 心情
     */
    MOOD(2, "心情"),

    /**
     * 美食
     */
    FOOD(3, "美食"),

    /**
     * 广告
     */
    ADVERT(4, "广告"),

    /**
     * 学习
     */
    STUDY(5, "学习"),

    /**
     * 推荐
     */
    RECOMMEND(6, "推荐"),
    /**
     * 出行
     */
    TRAVEL(7, "出行"),
    /**
     * 娱乐
     */
    HAPPY(8, "娱乐"),
    /**
     * 科技
     */
    TECHNOLOGY(9, "科技");


    int code;
    String message;

    LabelEnum(int code) {
        this.code = code;
    }

    LabelEnum(String message) {
        this.message = message;
    }

    LabelEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public static LabelEnum parseCode(int code) {
        for (LabelEnum e : LabelEnum.values()) {
            if (e.getCode() == code) {
                return e;
            }
        }
        return null;
    }

    public static LabelEnum parseName(String name) {
        if (StringUtil.isBlank(name)) {
            return null;
        }
        for (LabelEnum e : LabelEnum.values()) {
            if (e.name().equalsIgnoreCase(name)) {
                return e;
            }
        }
        return null;
    }


}

