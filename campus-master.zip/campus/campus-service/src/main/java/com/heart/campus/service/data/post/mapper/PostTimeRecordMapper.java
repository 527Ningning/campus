package com.heart.campus.service.data.post.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.PostTimeRecordDO;
import com.heart.campus.service.data.post.model.PostTimeRecordModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Repository("postTimeRecordMapper")
public class PostTimeRecordMapper implements AbstractMapper<PostTimeRecordModel, PostTimeRecordDO> {

    @Override
    public PostTimeRecordModel toModel(PostTimeRecordDO data) {
        if (data == null) {
            return null;
        }
        PostTimeRecordModel model = new PostTimeRecordModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public PostTimeRecordDO toDO(PostTimeRecordModel model) {
        if (model == null) {
            return null;
        }
        PostTimeRecordDO data = new PostTimeRecordDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
