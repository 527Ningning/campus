package com.heart.campus.service.data.post.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.UserPostRateRecordDO;
import com.heart.campus.service.data.post.model.UserPostRateRecordModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Repository("userPostRateRecordMapper")
public class UserPostRateRecordMapper implements AbstractMapper<UserPostRateRecordModel, UserPostRateRecordDO> {

    @Override
    public UserPostRateRecordModel toModel(UserPostRateRecordDO data) {
        if (data == null) {
            return null;
        }
        UserPostRateRecordModel model = new UserPostRateRecordModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public UserPostRateRecordDO toDO(UserPostRateRecordModel model) {
        if (model == null) {
            return null;
        }
        UserPostRateRecordDO data = new UserPostRateRecordDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
