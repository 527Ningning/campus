package com.heart.campus.service.data.post.mapper;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.PostLabelRecordDO;
import com.heart.campus.service.data.post.model.PostLabelRecordModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
@Repository("postLabelRecordMapper")
public class PostLabelRecordMapper implements AbstractMapper<PostLabelRecordModel, PostLabelRecordDO> {

    @Override
    public PostLabelRecordModel toModel(PostLabelRecordDO data) {
        if (data == null) {
            return null;
        }
        PostLabelRecordModel model = new PostLabelRecordModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public PostLabelRecordDO toDO(PostLabelRecordModel model) {
        if (model == null) {
            return null;
        }
        PostLabelRecordDO data = new PostLabelRecordDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
