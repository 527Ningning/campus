package com.heart.campus.service.data.label;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.label.model.LabelModel;
import com.heart.campus.service.data.label.param.LabelParam;

import java.util.List;

/**
 * 标签服务接口
 *
 * @author: yuwu
 * @date: 2017/12/23
 */

public interface LabelService extends AbstractService<LabelModel, LabelParam> {

    /**
     * 删除标签<逻辑>
     *
     * @param id
     * @return
     */
    Result<Boolean> delete(Long id);

    /**
     * 删除标签<物理>
     *
     * @param id
     * @return
     */
    Result<Boolean> relDelete(Long id);

    /**
     * 批量删除标签<逻辑>
     *
     * @param idList
     * @return
     */
    Result<Integer> batchDelete(List<Long> idList);

    /**
     * 批量获取标签名称
     *
     * @param idList
     * @return
     */
    Result<List<String>> batchGetNames(List<Long> idList);

    /**
     * 根据标签名称获取标签整体
     *
     * @param label
     * @return
     */
    Result<LabelModel> getByLabel(String label);
}
