package com.heart.campus.service.data.label.model;

import com.heart.campus.common.domain.AbstractModel;

/**
 * 标签Model层
 *
 * @author: yuwu
 * @date: 2017/12/23
 */
public class LabelModel extends AbstractModel {

    /**
     * 标签名字
     */
    private String  label;

    /**
     * 删除标志位
     */
    private Integer status;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "LabelModel{" +
                "label='" + label + '\'' +
                ", status=" + status +
                '}';
    }
}
