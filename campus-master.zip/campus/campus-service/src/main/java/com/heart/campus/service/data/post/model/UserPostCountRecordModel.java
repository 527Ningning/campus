package com.heart.campus.service.data.post.model;

import com.heart.campus.common.domain.AbstractModel;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class UserPostCountRecordModel extends AbstractModel {

    private String  userId;
    private Integer talkCount;
    private Integer playCount;
    private Integer marketCount;
    private Integer partTimeCount;
    private Integer workCount;
    private Integer studyCount;
    private Integer lostCount;
    private Integer campusCount;
    private Integer status;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getTalkCount() {
        return talkCount;
    }

    public void setTalkCount(Integer talkCount) {
        this.talkCount = talkCount;
    }

    public Integer getPlayCount() {
        return playCount;
    }

    public void setPlayCount(Integer playCount) {
        this.playCount = playCount;
    }

    public Integer getMarketCount() {
        return marketCount;
    }

    public void setMarketCount(Integer marketCount) {
        this.marketCount = marketCount;
    }

    public Integer getPartTimeCount() {
        return partTimeCount;
    }

    public void setPartTimeCount(Integer partTimeCount) {
        this.partTimeCount = partTimeCount;
    }

    public Integer getWorkCount() {
        return workCount;
    }

    public void setWorkCount(Integer workCount) {
        this.workCount = workCount;
    }

    public Integer getStudyCount() {
        return studyCount;
    }

    public void setStudyCount(Integer studyCount) {
        this.studyCount = studyCount;
    }

    public Integer getLostCount() {
        return lostCount;
    }

    public void setLostCount(Integer lostCount) {
        this.lostCount = lostCount;
    }

    public Integer getCampusCount() {
        return campusCount;
    }

    public void setCampusCount(Integer campusCount) {
        this.campusCount = campusCount;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
