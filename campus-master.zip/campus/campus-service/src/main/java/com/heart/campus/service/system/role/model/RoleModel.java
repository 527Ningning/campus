package com.heart.campus.service.system.role.model;

import com.heart.campus.common.domain.AbstractModel;

/**
 * 用户角色模型
 *
 * @author: heart
 * @date: 2017/11/12
 */
public class RoleModel extends AbstractModel {

    /**
     * 角色名称
     */
    private String  name;

    /**
     * 角色描述
     */
    private String desc;

    /**
     * 删除标志位
     */
    private Integer status;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "RoleDO{" + "name='" + name + '\'' + ", status=" + status + '}';
    }

}
