package com.heart.campus.service.data.posttype.mapper;

import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.dal.domain.data.PostTypeDO;
import com.heart.campus.service.data.posttype.model.PostTypeModel;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

/**
 * 帖子类型映射类
 *
 * @author: yuwu
 * @date: 2017/11/13
 */
@Repository("postTypeMapper")
public class PostTypeMapper implements AbstractMapper<PostTypeModel, PostTypeDO> {

    @Override
    public PostTypeModel toModel(PostTypeDO data) {
        if (data == null) {
            return null;
        }
        PostTypeModel model = new PostTypeModel();
        BeanUtils.copyProperties(data, model);
        return model;
    }

    @Override
    public PostTypeDO toDO(PostTypeModel model) {
        if (model == null) {
            return null;
        }
        PostTypeDO data = new PostTypeDO();
        BeanUtils.copyProperties(model, data);
        return data;
    }
}
