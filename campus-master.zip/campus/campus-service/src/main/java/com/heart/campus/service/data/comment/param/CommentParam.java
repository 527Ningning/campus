package com.heart.campus.service.data.comment.param;

import com.heart.campus.common.param.AbstractQueryParam;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Comment查询类
 * 
 * @author: yuwu
 * @date: 2017/11/16
 */
public class CommentParam extends AbstractQueryParam {

    /**
     * 评论ID
     */
    private String       commentId;

    /**
     * 帖子ID
     */
    private String       postId;

    /**
     * 用户ID
     */
    private String       userId;

    /**
     * 评论内容
     */
    private String       content;

    /**
     * 黑白名单标志位
     */
    private Integer      blackWhiteState;

    /**
     * 删除标志位
     */
    private Integer      status;

    /**
     * 排序参数 需要使用排序的数据均需要该字段
     *
     * @param existParam
     */
    private String       orderFiled;
    private String       orderType;

    private List<Long>   idList     = new ArrayList<>();
    private List<String> statusList = new ArrayList<>();

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getBlackWhiteState() {
        return blackWhiteState;
    }

    public void setBlackWhiteState(Integer blackWhiteState) {
        this.blackWhiteState = blackWhiteState;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getOrderFiled() {
        return orderFiled;
    }

    public void setOrderFiled(String orderFiled) {
        this.orderFiled = orderFiled;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }


    public String getCommentId() {
        return commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }


    @Override
    protected void addParams(Map<String, Object> existParam) {
        addIfNotEmpty(existParam, "postId", postId);
        addIfNotEmpty(existParam, "commentId", commentId);
        addIfNotEmpty(existParam, "userId", userId);
        addIfNotEmpty(existParam, "content", content);
        addIfNotNull(existParam, "blackWhiteState", blackWhiteState);
        addIfNotNull(existParam, "status", status);
        addIfNotEmpty(existParam, "statusList", statusList);
        addIfNotEmpty(existParam, "idList", idList);
    }

    @Override
    public void addLikeParams(Map<String, Object> existParam) {

    }

    @Override
    public String getOrderBy() {
        return orderFiled;
    }

    @Override
    public String getOrder() {
        return orderType;
    }
}
