package com.heart.campus.service.data.post.param;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.heart.campus.common.param.AbstractQueryParam;

/**
 * Post查询参数类
 *
 * @author: yuwu
 * @date: 2017/11/14
 */
public class PostParam extends AbstractQueryParam {

    /**
     * 帖子ID
     */
    private String  postId;

    /**
     * 帖子类型ID
     */
    private Integer typeId;

    /**
     * 帖子标题
     */
    private String  title;

    /**
     * 用户学号
     */
    private String  userId;

    /**
     * 帖子内容
     */
    private String  content;

    /**
     * 帖子优先级
     */
    private Integer priority;

    /**
     * 帖子点赞数
     */
    private Integer upvoteCount;

    /**
     * 帖子浏览次数
     */
    private Integer visitCount;

    /**
     * 黑白名单标志位
     */
    private Integer blackWhiteState;

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Integer getUpvoteCount() {
        return upvoteCount;
    }

    public void setUpvoteCount(Integer upvoteCount) {
        this.upvoteCount = upvoteCount;
    }

    public Integer getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(Integer visitCount) {
        this.visitCount = visitCount;
    }

    public Integer getBlackWhiteState() {
        return blackWhiteState;
    }

    public void setBlackWhiteState(Integer blackWhiteState) {
        this.blackWhiteState = blackWhiteState;
    }

    /**
     * 删除标志位
     */
    private Integer      status;

    /**
     * 排序参数 需要使用排序的数据均需要该字段
     *
     * @param existParam
     */
    private String       orderFiled;
    private String       orderType;

    private List<Long>   idList     = new ArrayList<>();
    private List<String> statusList = new ArrayList<>();

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getOrderFiled() {
        return orderFiled;
    }

    public void setOrderFiled(String orderFiled) {
        this.orderFiled = orderFiled;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }

    public List<String> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<String> statusList) {
        this.statusList = statusList;
    }

    @Override
    protected void addParams(Map<String, Object> existParam) {
        addIfNotEmpty(existParam, "postId", postId);
        addIfNotEmpty(existParam, "userId", userId);
        addIfNotNull(existParam, "typeId", typeId);
        addIfNotEmpty(existParam, "title", title);
        addIfNotEmpty(existParam, "content", content);
        addIfNotNull(existParam, "upvoteCount", upvoteCount);
        addIfNotNull(existParam, "priority", priority);
        addIfNotNull(existParam, "visitCount", visitCount);
        addIfNotNull(existParam, "blackWhiteState", blackWhiteState);
        addIfNotNull(existParam, "status", status);
        addIfNotEmpty(existParam, "statusList", statusList);
        addIfNotEmpty(existParam, "idList", idList);
    }

    @Override
    public void addLikeParams(Map<String, Object> existParam) {

    }

    @Override
    public String getOrderBy() {
        return orderFiled;
    }

    @Override
    public String getOrder() {
        return orderType;
    }
}
