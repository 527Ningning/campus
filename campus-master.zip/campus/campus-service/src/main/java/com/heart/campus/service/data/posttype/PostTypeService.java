package com.heart.campus.service.data.posttype;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.posttype.model.PostTypeModel;
import com.heart.campus.service.data.posttype.param.PostTypeParam;

import java.util.List;

/**
 * @author: yuwu
 * @date: 2017/11/13
 */
public interface PostTypeService extends AbstractService<PostTypeModel, PostTypeParam> {


    /**
     * 删除帖子类型<逻辑>
     *
     * @param id
     * @return
     */
    Result<Boolean> delete(Long id);

    /**
     * 删除帖子类型<物理>
     *
     * @param id
     * @return
     */
    Result<Boolean> relDelete(Long id);

    /**
     * 批量删除帖子类型<逻辑>
     *
     * @param idList
     * @return
     */
    Result<Integer> batchDelete(List<Long> idList);

    /**
     * 批量获取帖子类型名称
     *
     * @param idList
     * @return
     */
    Result<List<String>> batchGetNames(List<Long> idList);

    /**
     * 根据帖子描述获取帖子类型
     *
     * @param desc
     * @return
     */
    Result<PostTypeModel> getByName(String desc);

}
