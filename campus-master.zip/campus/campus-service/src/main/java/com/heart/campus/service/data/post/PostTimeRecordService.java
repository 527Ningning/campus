package com.heart.campus.service.data.post;

import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.data.post.model.PostTimeRecordModel;
import com.heart.campus.service.data.post.param.PostTimeRecordParam;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public interface PostTimeRecordService extends AbstractService<PostTimeRecordModel, PostTimeRecordParam> {

}

