package com.heart.campus.service.system.user.impl;

import java.util.Arrays;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.DefaultService;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.common.util.StringUtil;
import com.heart.campus.dal.dao.system.UserDAO;
import com.heart.campus.dal.domain.system.UserDO;
import com.heart.campus.service.system.user.UserService;
import com.heart.campus.service.system.user.mapper.UserMapper;
import com.heart.campus.service.system.user.model.UserModel;
import com.heart.campus.service.system.user.param.UserParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * User服务实现类
 *
 * @author: heart
 * @date: 2017/11/2
 */
@Service("userService")
public class UserServiceImpl extends DefaultService<UserModel, UserDO, UserParam> implements UserService {

    private static final Logger LOG = LoggerFactory.getLogger("CampusLog");

    @Autowired
    private UserDAO             userDAO;

    @Autowired
    private UserMapper          userMapper;

    @Override
    public AbstractMapper<UserModel, UserDO> getMapper() {
        return userMapper;
    }

    @Override
    public AbstractDAO<UserDO> getDao() {
        return userDAO;
    }

    @Override
    public Result<Boolean> delete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<UserModel> userResult = find(id);
        if (userResult.isSuccess() && userResult.getContent() != null) {
            UserModel user = userResult.getContent();
            user.setStatus(1);
            return update(user);
        }
        return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
    }

    @Override
    public Result<Boolean> relDelete(Long id) {
        if (id == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        UserParam delParam = new UserParam();
        delParam.setIdList(Arrays.asList(id));
        Integer num = super.delete(delParam);
        if (num == null || num <= 0) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        return ResultGenerator.genSuccess(true);
    }

    @Override
    public Result<UserModel> getByUserId(String userId) {

        if (StringUtil.isBlank(userId)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        UserParam param = new UserParam();
        param.setUserId(userId);
        Result<PageList<UserModel>> userListResult = super.query(param);
        if (userListResult.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PageList<UserModel> userList = userListResult.getContent();
        return ResultGenerator.genSuccess(userList.first());
    }

    @Override
    public Result<UserModel> getByName(String userName) {
        if (StringUtil.isBlank(userName)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        UserParam param = new UserParam();
        param.setUserName(userName);
        Result<PageList<UserModel>> userListResult = query(param);
        if (userListResult.getContent() == null) {
            return ResultGenerator.genError(ErrorCodeEnum.RESULT_IS_NULL);
        }
        PageList<UserModel> userList = userListResult.getContent();
        return ResultGenerator.genSuccess(userList.first());
    }

}
