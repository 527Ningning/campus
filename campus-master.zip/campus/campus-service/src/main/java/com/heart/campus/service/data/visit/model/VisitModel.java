package com.heart.campus.service.data.visit.model;

import com.heart.campus.common.domain.AbstractModel;

/**
 * VisitModel模型类
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
public class VisitModel extends AbstractModel {

    /**
     * 学号
     */
    private String  userId;

    /**
     * 帖子id
     */
    private Long    postId;

    /**
     * 逻辑删除位
     */
    private Integer status;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    @Override
    public String toString() {
        return "VisitModel{" +
                "userId='" + userId + '\'' +
                ", postId=" + postId +
                ", status=" + status +
                '}';
    }
}
