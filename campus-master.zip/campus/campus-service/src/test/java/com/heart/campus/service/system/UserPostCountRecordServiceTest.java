package com.heart.campus.service.system;

import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.domain.ItemCluster;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.post.UserPostCountRecordService;
import com.heart.campus.service.data.post.model.UserPostCountRecordModel;
import com.heart.campus.service.data.post.param.UserPostCountRecordParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class UserPostCountRecordServiceTest extends BaseServiceTest<UserPostCountRecordService, UserPostCountRecordModel> {

    @Autowired
    private UserPostCountRecordService userPostCountRecordService;

    @Override
    public UserPostCountRecordModel initExample() {
        return null;
    }

    @Test
    public void test_query() {
        UserPostCountRecordParam param = new UserPostCountRecordParam();
        param.setStatus(0);
        Result<PageList<UserPostCountRecordModel>> query = userPostCountRecordService.query(param);
        TestCase.assertNotNull(query);
    }

    @Override
    public void test_delete() {

    }

    @Override
    public void test_relDelete() {

    }

    @Test
    public void test_doAnalysis() {
        UserPostCountRecordParam param = new UserPostCountRecordParam();
        param.setStatus(0);
        param.setPageSize(100);
        Result<PageList<UserPostCountRecordModel>> listResult = userPostCountRecordService.query(param);
        List<UserPostCountRecordModel> dataList = listResult.getContent().getDataList();
        List<DataItem> dataItems = new ArrayList<>();
        for (UserPostCountRecordModel model : dataList) {
            DataItem dataItem = new DataItem();
            dataItem.setName(model.getUserId());
            List items = new ArrayList<>();
            dataItem.setItems(items);
            items.add(model.getTalkCount());
            items.add(model.getPlayCount());
            items.add(model.getPartTimeCount());
            items.add(model.getMarketCount());
            dataItems.add(dataItem);
        }
        long start = System.nanoTime();
        List<ItemCluster> itemClusters = userPostCountRecordService.doAnalysis(dataItems);
        long spend_time = System.nanoTime() - start;
        System.out.println("执行耗时："+(spend_time/1000000)+" 毫秒");
        for (ItemCluster itemCluster : itemClusters) {
            System.out.println("==簇序号：" + itemCluster.getOrder() + "==");
            System.out.println("簇成员个数：" + itemCluster.getNumber());
            System.out.println("簇中心：" + itemCluster.getCenterItem().getItems());
            StringBuilder sb = new StringBuilder();
            for (DataItem dataItem : itemCluster.getDataItems()) {
                sb.append(dataItem.getName() + " ");
            }
            System.out.println(sb.toString());
            System.out.println("-------------------------------");
        }
    }

}
