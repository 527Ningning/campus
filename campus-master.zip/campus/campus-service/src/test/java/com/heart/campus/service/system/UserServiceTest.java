package com.heart.campus.service.system;

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.system.user.UserService;
import com.heart.campus.service.system.user.model.UserModel;
import com.heart.campus.service.system.user.param.UserParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 用户服务测试类
 *
 * @author: heart
 * @date: 2017/11/3
 */
public class UserServiceTest extends BaseServiceTest<UserService, UserModel> {

    @Autowired
    private UserService userService;

    @Test
    public void test_insert() {
        // UserModel user = genUserModel();
        // Result<Long> result = userService.insert(user);
        // TestCase.assertNotNull(result.getContent());
    }

    @Test
    public void test_find() {
        long id = 1L;
        Result<UserModel> result = userService.find(id);
        TestCase.assertEquals(id, result.getContent().getId().longValue());
    }

    @Test
    public void test_getUserByName() {
        String userName = "heart";
        Result<UserModel> result = userService.getByName(userName);
        // TestCase.assertEquals(userName, result.getContent().getUserName());
    }

    @Test
    public void test_getUserByUserId() {
        String userId = "112016321030905";
        Result<UserModel> result = userService.getByUserId(userId);
        // TestCase.assertEquals(userId, result.getContent().getUserId());
    }

    @Test
    public void test_getUserList() {
        UserParam param = new UserParam();
        param.setUserSubject("软件工程");
        param.setPage(1);
        param.setPageSize(5);
        param.setCountNeeded(true);
        Result<PageList<UserModel>> result = userService.query(param);
        // TestCase.assertNotNull(result.getContent());
    }

    @Test
    public void test_update() {
        Result<UserModel> userById = userService.find(1L);
        TestCase.assertNotNull(userById.getContent());
        UserModel user = userById.getContent();
        user.setUserPhone("18883383226");
        Result<Boolean> result = userService.update(user);
        // TestCase.assertEquals(true, result.isSuccess());
    }

    @Test
    public void test_delete() {
        Result<Boolean> result = userService.delete(19L);
        TestCase.assertEquals(true, result.isSuccess());
    }

    @Test
    public void test_relDelete() {
        Result<Boolean> result = userService.relDelete(9L);
        // TestCase.assertEquals(true, result.isSuccess());
    }

    private UserModel genUserModel() {
        UserModel user = new UserModel();
        user.setUserId("112016321030908");
        user.setUserName("小ke");
        user.setUserPassword("123");
        user.setRoles("1");
        user.setUserGender(1);
        user.setUserPhone("18883383221");
        user.setUserSchool("软件学院");
        user.setUserSubject("计算机与科学");
        user.setUserAddress("梅园12舍321");
        return user;
    }

    @Override
    public UserModel initExample() {
        return null;
    }
}
