package com.heart.campus.service.base;

import com.heart.campus.common.domain.AbstractModel;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.service.AbstractService;
import com.heart.campus.service.ServiceTestApplication;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

/**
 * 基础测试类
 *
 * @author: heart
 * @date: 2017/11/13
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { ServiceTestApplication.class })
public abstract class BaseServiceTest<S extends AbstractService, M extends AbstractModel> {

    /**
     * 服务类接口
     */
    @Autowired
    private S service;

    /**
     * 模型类接口
     */
    private M m;

    /**
     * 初始化测试模型
     * 
     * @return
     */
    public abstract M initExample();

    /**
     * 获得测试模型
     * 
     * @return
     */
    public M getExample() {
        this.m = (this.m == null ? initExample() : this.m);
        return this.m;
    }

    /**
     * 设置测试模型
     * 
     * @param model
     */
    public void setExample(M model) {
        this.m = model;
    }

    /**
     * 获得服务接口
     * 
     * @return
     */
    public S getService() {
        return this.service;
    }

    /**
     * 单元测试 - 插入
     */
    @Test
    public void test_insert() {
        Result<Long> result = service.insert(getExample());
        TestCase.assertNotNull(result.getContent());
    }

    /**
     * 单元测试 - 查找
     */
    @Test
    public void test_find() {
        Result<Long> result = service.find(getExample().getId());
        TestCase.assertNotNull(result.getContent());
    }

    /**
     * 单元测试 - 更新
     */
    @Test
    public void test_update() {
        /**
         * update测试模型
         */
        Date date = new Date();
        getExample().setGmtModified(date);
        Result<Boolean> result = service.update(getExample());
        TestCase.assertEquals(true, result.isSuccess());
    }

    /**
     * 单元测试 - 删除(逻辑)
     */
    @Test
    public abstract void test_delete();

    /**
     * 单元测试 - 删除(物理)
     */
    @Test
    public abstract void test_relDelete();

}
