package com.heart.campus.service.system;

import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.visit.VisitService;
import com.heart.campus.service.data.visit.model.VisitModel;
import com.heart.campus.service.testmodel.CommonTestModel;

/**
 * VisitService单元测试
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
public class VisitServiceTest extends BaseServiceTest<VisitService, VisitModel> {

    @Override
    public VisitModel initExample() {
        return CommonTestModel.genVisitModel();
    }

    @Override
    public void test_insert() {
        super.test_insert();
    }

    @Override
    public void test_find() {
        super.test_find();
    }

    @Override
    public void test_update() {
        super.test_update();
    }

    @Override
    public void test_delete() {
       getService().delete(getExample().getId());
    }

    @Override
    public void test_relDelete() {

    }
}
