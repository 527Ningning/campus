package com.heart.campus.service.system;

import java.util.ArrayList;
import java.util.List;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.system.role.RoleService;
import com.heart.campus.service.system.role.model.RoleModel;
import com.heart.campus.service.system.role.param.RoleParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 用户角色单元测试
 *
 * @author: heart
 * @date: 2017/11/12
 */
public class RoleServiceTest extends BaseServiceTest<RoleService,RoleModel> {

    @Autowired
    private RoleService roleService;

    @Override
    public void test_insert() {
        RoleModel roleModel = genRoleModel();
        Result<Long> result = roleService.insert(roleModel);
        //TestCase.assertNotNull(result.getContent());
    }

    @Override
    public void test_find() {
        Result<RoleModel> roleById = roleService.find(1L);
        TestCase.assertNotNull(roleById.getContent());
    }

    @Test
    public void test_update() {
        Result<RoleModel> roleById = roleService.find(6L);
        TestCase.assertNotNull(roleById.getContent());
        RoleModel roleModel = roleById.getContent();
        roleModel.setStatus(CommonStatusEnum.DELETE.getValue());
        Result<Boolean> result = roleService.update(roleModel);
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Test
    public void test_delete() {
        Result<Boolean> result = roleService.delete(8L);
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Test
    public void test_relDelete() {
        Result<Boolean> result = roleService.relDelete(3L);
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Test
    public void test_getRoleByName() {
        Result<RoleModel> result = roleService.getByName("ROLES_USER");
        TestCase.assertNotNull(result);
        //TestCase.assertNotNull(result.getContent());
    }

    @Test
    public void test_batchGetRoleNames() {
        List<Long> idList = new ArrayList<>();
        idList.add(1L);
        idList.add(2L);
        Result<List<String>> result = roleService.batchGetNames(idList);
        //TestCase.assertEquals(true, result.isSuccess());
        //TestCase.assertNotSame(0, result.getContent().size());
    }

    @Test
    public void test_getRoleList() {
        RoleParam param = new RoleParam();
        param.setStatus(0);
        Result<PageList<RoleModel>> result = roleService.query(param);
        //TestCase.assertNotNull(result.getContent().first());
    }

    private RoleModel genRoleModel() {
        RoleModel roleModel = new RoleModel();
        roleModel.setName("ROLE_TEST_2");
        roleModel.setStatus(CommonStatusEnum.DELETE.getValue());
        return roleModel;
    }

    @Override
    public RoleModel initExample() {
        return null;
    }
}
