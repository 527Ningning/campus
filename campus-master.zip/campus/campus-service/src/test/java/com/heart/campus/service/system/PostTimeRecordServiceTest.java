package com.heart.campus.service.system;

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.post.PostTimeRecordService;
import com.heart.campus.service.data.post.model.PostTimeRecordModel;
import com.heart.campus.service.data.post.param.PostTimeRecordParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostTimeRecordServiceTest extends BaseServiceTest<PostTimeRecordService, PostTimeRecordModel> {

    @Autowired
    private PostTimeRecordService postTimeRecordService;

    @Override
    public PostTimeRecordModel initExample() {
        PostTimeRecordModel model = new PostTimeRecordModel();
        model.setHour(0);
        model.setWeek(1);
        model.setNumber(1);
        model.setGender(1);
        model.setStatus(0);
        return model;
    }

    @Test
    public void test_query() {
        PostTimeRecordParam param = new PostTimeRecordParam();
        param.setGender(0);
        Result<PageList<PostTimeRecordModel>> query = postTimeRecordService.query(param);
        TestCase.assertNotNull(query);
    }

    @Override
    public void test_delete() {

    }

    @Override
    public void test_relDelete() {

    }


}

