package com.heart.campus.service.system;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.posttype.PostTypeService;
import com.heart.campus.service.data.posttype.model.PostTypeModel;
import com.heart.campus.service.data.posttype.param.PostTypeParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;

/**
 * PostTypeService单元测试
 *
 * @author: yuwu
 * @date: 2017/11/13
 */
public class PostTypeServiceTest extends BaseServiceTest<PostTypeService, PostTypeModel> {

    @Autowired
    PostTypeService postTypeService;

    @Override
    public void test_insert() {
        PostTypeModel model = genModel();
        Result<Long> result = postTypeService.insert(genModel());
        // TestCase.assertNotNull(result.getContent());
    }

    @Override
    public void test_find() {
        Result<PostTypeModel> result = postTypeService.find(2L);
        System.out.println("getById" + result.getContent().toString());
        // TestCase.assertNotNull(result.getContent());
    }

    @Override
    public void test_update() {
        Result<PostTypeModel> result1 = postTypeService.find(10L);
        TestCase.assertNotNull(result1.getContent());
        PostTypeModel model = result1.getContent();
        model.setStatus(CommonStatusEnum.DELETE.getValue());
        Result<Boolean> result = postTypeService.update(model);
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Override
    public void test_delete() {
        Result<Boolean> result = postTypeService.delete(9L);
       // TestCase.assertEquals(true, result.isSuccess());
    }

    @Override
    public void test_relDelete() {
        Result<Boolean> result = postTypeService.relDelete(9L);
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Test
    public void test_getByName() {
        Result<PostTypeModel> result = postTypeService.getByName("一般帖子");
        System.out.println(result.getContent().toString());
        //TestCase.assertNotNull(result);
       // TestCase.assertNotNull(result.getContent());
    }

    @Test
    public void test_batchGet() {
        List<Long> idList = new ArrayList<>();
        idList.add(1L);
        idList.add(2L);
        Result<List<String>> result = postTypeService.batchGetNames(idList);
        System.out.println(result.getContent().size());
        //TestCase.assertEquals(true, result.isSuccess());
        //TestCase.assertNotSame(0, result.getContent().size());
    }

    @Test
    public void test_getList() {
        PostTypeParam param = new PostTypeParam();
        param.setStatus(0);
        Result<PageList<PostTypeModel>> result = postTypeService.query(param);
        //TestCase.assertNotNull(result.getContent().first());
    }

    private PostTypeModel genModel() {
        PostTypeModel model = new PostTypeModel();
        model.setDesc("资源贡献");
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        return model;
    }

    @Override
    public PostTypeModel initExample() {
        return null;
    }
}
