package com.heart.campus.service.system;

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.post.PostService;
import com.heart.campus.service.data.post.model.PostModel;
import com.heart.campus.service.data.post.param.PostParam;
import com.heart.campus.service.testmodel.CommonTestModel;
import junit.framework.TestCase;
import org.junit.Test;

/**
 * PostService单元测试
 *
 * @author: yuwu
 * @date: 2017/11/14
 */
public class PostServiceTest extends BaseServiceTest<PostService, PostModel> {

    @Override
    public PostModel initExample() {
        return CommonTestModel.genPostModel();
    }

    @Override
    public PostService getService() {
        return super.getService();
    }

    @Override
    public void test_insert() {
        super.test_insert();
    }

    @Override
    public void test_find() {
        super.test_find();
    }

    @Override
    public void test_update() {
        super.test_update();
    }

    @Override
    public void test_delete() {
        Result<Boolean> result = getService().delete(getExample().getId());
        System.out.println(getExample().getId());
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Override
    public void test_relDelete() {
        Result<Boolean> result = getService().relDelete(getExample().getId());
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Test
    public void test_getByPostId() {
        // Result<PostModel> result =
        // getService().getByPostId(getExample().getPostId());
        // System.out.println(result.getContent());
        //TestCase.assertNotNull(result.getContent());
    }

    @Test
    public void test_count() {
        PostParam param = new PostParam();
        param.setTypeId(1);
//        param.setStatus(0);
        Integer count = getService().count(param);
        TestCase.assertNotNull(count);
    }


    @Test
    public void test_getListsByUserId() {
        PostParam param = new PostParam();
        param.setUserId("112016321030905");
        param.setPage(1);
        param.setPageSize(5);
        param.setCountNeeded(true);
        Result<PageList<PostModel>> result = getService().query(param);
        System.out.println(result.getContent().getDataList().size());
        //TestCase.assertNotNull(result.getContent());
    }
}
