package com.heart.campus.service.system;

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.post.PostLabelRecordService;
import com.heart.campus.service.data.post.PostTimeRecordService;
import com.heart.campus.service.data.post.model.PostLabelRecordModel;
import com.heart.campus.service.data.post.model.PostTimeRecordModel;
import com.heart.campus.service.data.post.param.PostLabelRecordParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostLabelRecordServiceTest extends BaseServiceTest<PostTimeRecordService, PostTimeRecordModel> {

    @Autowired
    private PostLabelRecordService postLabelRecordService;

    @Override
    public PostTimeRecordModel initExample() {
        return null;
    }

    @Test
    public void test_query() {
        PostLabelRecordParam param = new PostLabelRecordParam();
        param.setGender(0);
        Result<PageList<PostLabelRecordModel>> query = postLabelRecordService.query(param);
        TestCase.assertNotNull(query);
    }

    @Override
    public void test_delete() {

    }

    @Override
    public void test_relDelete() {

    }


}

