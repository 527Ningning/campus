package com.heart.campus.service.system;

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.system.member.MemberService;
import com.heart.campus.service.system.member.model.MemberModel;
import com.heart.campus.service.system.member.param.MemberParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/5/9
 */
public class MemberServiceTest extends BaseServiceTest<MemberService, MemberModel> {

    @Autowired
    private MemberService memberService;

    @Test
    public void test_query() {
        MemberParam param = new MemberParam();
        Result<PageList<MemberModel>> listResult = memberService.query(param);
        TestCase.assertNotNull(listResult);
    }

    @Test
    public void test_loadMemberList() {
        Result<List<MemberModel>> listResult = memberService.loadMemberList();
        TestCase.assertNotNull(listResult);
    }

    @Override
    public MemberModel initExample() {
        return null;
    }

    @Override
    public void test_delete() {

    }

    @Override
    public void test_relDelete() {

    }
}

