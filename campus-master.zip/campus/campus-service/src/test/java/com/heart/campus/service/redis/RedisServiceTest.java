package com.heart.campus.service.redis;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.heart.campus.service.ServiceTestApplication;

/**
 * Redis缓存服务测试
 *
 * @author: heart
 * @date: 2018/5/10
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { ServiceTestApplication.class })
public class RedisServiceTest {

    @Autowired
    private RedisService redisService;

    @Test
    public void test_expire() {
        //redisService.remove("asyn_data_genderPostType");
        redisService.remove("asyn_data_postList");
        redisService.remove("asyn_data_commentList");
    }

}
