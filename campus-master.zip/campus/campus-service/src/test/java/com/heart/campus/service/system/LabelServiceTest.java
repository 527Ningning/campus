package com.heart.campus.service.system;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.label.LabelService;
import com.heart.campus.service.data.label.model.LabelModel;

/**
 * LabelService单元测试
 *
 * @author: yuwu
 * @date: 2017/12/23
 */
public class LabelServiceTest extends BaseServiceTest<LabelService, LabelModel> {

    @Override
    public LabelModel initExample() {
        LabelModel model = new LabelModel();
        model.setLabel("测试1");
        model.setId(12L);
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        return model;
    }

    @Override
    public void setExample(LabelModel model) {
        super.setExample(model);
    }

    @Override
    public LabelService getService() {
        return super.getService();
    }

    @Override
    public void test_insert() {
        super.test_insert();
    }

    @Override
    public void test_find() {
        System.out.println(getExample().getId());
        super.test_find();
    }

    @Override
    public void test_update() {
        super.test_update();
    }

    @Override
    public void test_delete() {
        getService().delete(getExample().getId());
    }

    @Override
    public void test_relDelete() {
        getService().relDelete(getExample().getId());
    }
}
