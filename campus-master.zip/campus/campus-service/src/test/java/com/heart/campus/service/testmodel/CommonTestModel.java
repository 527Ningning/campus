package com.heart.campus.service.testmodel;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.service.data.comment.model.CommentModel;
import com.heart.campus.service.data.post.model.PostModel;
import com.heart.campus.service.data.posttype.model.PostTypeModel;
import com.heart.campus.service.data.upvote.model.UpvoteModel;
import com.heart.campus.service.data.visit.model.VisitModel;

/**
 * 测试Model类
 *
 * @author: yuwu
 * @date: 2017/11/14
 */
public class CommonTestModel {

    public static PostTypeModel genPostTypeModel() {
        PostTypeModel model = new PostTypeModel();
        model.setId(1000L);
        model.setDesc("例子");
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        return model;
    }

    public static PostModel genPostModel() {
        PostModel model = new PostModel();
        model.setId(1000L);
        model.setPostId("1000");
        model.setTypeId(1);
        model.setUserId("112016321030905");
        model.setTitle("测试帖子标题");
        model.setContent("这是内容啊");
        model.setPriority(3);
        model.setUpvoteCount(12);
        model.setVisitCount(10);
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        model.setBlackWhiteState(0);
        return model;
    }

    public static CommentModel genCommentModel() {
        CommentModel model = new CommentModel();
        model.setCommentId("1000");
        model.setId(1000L);
        model.setPostId("1000");
        model.setUserId("112016321030905");
        model.setContent("测试评论");
        model.setBlackWhiteState(0);
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        return model;
    }

    public static VisitModel genVisitModel() {
        VisitModel model = new VisitModel();
        model.setId(1000L);
        model.setPostId(1L);
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        model.setUserId("112016321030905");
        return model;
    }

    public static UpvoteModel genUpvoteModel() {
        UpvoteModel model = new UpvoteModel();
        model.setId(1000L);
        model.setPostId(1L);
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        model.setUserId("112016321030905");
        return model;
    }

}
