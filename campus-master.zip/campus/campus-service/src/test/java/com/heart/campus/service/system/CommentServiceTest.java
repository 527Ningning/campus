package com.heart.campus.service.system;

import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.comment.CommentService;
import com.heart.campus.service.data.comment.model.CommentModel;
import com.heart.campus.service.testmodel.CommonTestModel;
import org.junit.Test;

/**
 * CommentService服务单元测试
 * 
 * @author: yuwu
 * @date: 2017/11/16
 */
public class CommentServiceTest extends BaseServiceTest<CommentService,CommentModel>{

    @Override
    public CommentModel initExample() {
        return CommonTestModel.genCommentModel();
    }

    @Override
    public void test_insert() {
        super.test_insert();
    }

    @Override
    public void test_find() {
        super.test_find();
    }

    @Override
    public void test_update() {
        super.test_update();
    }

    @Override
    public void test_delete() {
        Result<Boolean> result = getService().delete(getExample().getId());
        System.out.println(getExample().getId());
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Override
    public void test_relDelete() {
        Result<Boolean> result = getService().relDelete(getExample().getId());
        //TestCase.assertEquals(true, result.isSuccess());
    }

    @Test
    public void test_getByPostId() {
        Result<CommentModel> result = getService().getByCommentId(getExample().getCommentId());
        System.out.println(result.getContent());
        //TestCase.assertNotNull(result.getContent());
    }


}
