package com.heart.campus.service.system;

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.post.UserPostRateRecordService;
import com.heart.campus.service.data.post.model.UserPostRateRecordModel;
import com.heart.campus.service.data.post.param.UserPostRateRecordParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class UserPostRateRecordServiceTest extends BaseServiceTest<UserPostRateRecordService, UserPostRateRecordModel> {

    @Autowired
    private UserPostRateRecordService userPostRateRecordService;

    @Override
    public UserPostRateRecordModel initExample() {
        return null;
    }

    @Test
    public void test_query() {
        UserPostRateRecordParam param = new UserPostRateRecordParam();
        param.setStatus(0);
        Result<PageList<UserPostRateRecordModel>> query = userPostRateRecordService.query(param);
        TestCase.assertNotNull(query);
    }

    @Override
    public void test_delete() {

    }

    @Override
    public void test_relDelete() {

    }


}

