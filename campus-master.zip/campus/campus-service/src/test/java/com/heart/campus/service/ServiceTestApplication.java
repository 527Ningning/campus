package com.heart.campus.service;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;

/**
 * Service测试启动入口
 *
 * @author: heart
 * @date: 2017/10/24
 */
@SpringBootApplication
@PropertySource("classpath:application-test.properties")
@MapperScan(basePackages = "com.heart.campus.dal")
@ComponentScan(basePackages = "com.heart.campus.service")
public class ServiceTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServiceTestApplication.class, args);
    }
}
