package com.heart.campus.service.system;

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.post.PostTimeRecordService;
import com.heart.campus.service.data.post.PostTypeRecordService;
import com.heart.campus.service.data.post.model.PostTimeRecordModel;
import com.heart.campus.service.data.post.model.PostTypeRecordModel;
import com.heart.campus.service.data.post.param.PostTypeRecordParam;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostTypeRecordServiceTest extends BaseServiceTest<PostTimeRecordService, PostTimeRecordModel> {

    @Autowired
    private PostTypeRecordService postTypeRecordService;

    @Override
    public PostTimeRecordModel initExample() {
        return null;
    }

    @Test
    public void test_query() {
        PostTypeRecordParam param = new PostTypeRecordParam();
        param.setGender(0);
        Result<PageList<PostTypeRecordModel>> query = postTypeRecordService.query(param);
        TestCase.assertNotNull(query);
    }

    @Override
    public void test_delete() {

    }

    @Override
    public void test_relDelete() {

    }


}

