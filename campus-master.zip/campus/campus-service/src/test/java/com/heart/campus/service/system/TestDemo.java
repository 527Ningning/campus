package com.heart.campus.service.system;

import com.heart.campus.service.base.BaseServiceTest;
import com.heart.campus.service.data.posttype.PostTypeService;
import com.heart.campus.service.data.posttype.model.PostTypeModel;
import com.heart.campus.service.testmodel.CommonTestModel;

/**
 * BaseService使用Demo
 *
 * @author: yuwu
 * @date: 2017/11/14
 */
public class TestDemo extends BaseServiceTest<PostTypeService, PostTypeModel> {

    @Override
    public PostTypeModel initExample() {
        return CommonTestModel.genPostTypeModel();
    }

    @Override
    public void test_insert() {
       // super.test_insert();
    }

    @Override
    public void test_find() {
        super.test_find();
    }

    @Override
    public void test_update() {
        super.test_update();
    }

    @Override
    public void test_delete() {

    }

    @Override
    public void test_relDelete() {

    }
}
