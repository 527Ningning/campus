package com.heart.campus.start.config;

import java.util.ArrayList;
import java.util.List;

import com.heart.campus.common.result.Result;
import com.heart.campus.common.util.StringUtil;
import com.heart.campus.service.system.role.RoleService;
import com.heart.campus.service.system.user.UserService;
import com.heart.campus.service.system.user.model.UserModel;
import com.heart.campus.web.vo.SystemUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 * 自定义UserDetailService
 *
 * @author: heart
 * @date: 2017/10/30
 */
@Service("customUserDetailService")
public class CustomUserDetailService implements UserDetailsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomUserDetailService.class);

    @Autowired
    UserService userService;

    @Autowired
    RoleService roleService;

    @Autowired
    HttpServletRequest request;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if (username == null) {
            return null;
        }
        Result<UserModel> result = userService.getByName(username);
        if (result.getContent() == null) {
            return null;
        }

        UserModel user = result.getContent();
        SystemUser systemUser = new SystemUser();
        systemUser.setUsername(user.getUserName());
        systemUser.setPassword(user.getUserPassword());
        String roles = user.getRoles();
        List<Long> roleIdList = convertStringToList(roles);
        Result<List<String>> roleNamesResult = roleService.batchGetNames(roleIdList);
        if (roleNamesResult.getContent() != null) {
            systemUser.setRoles(roleNamesResult.getContent());
        }
        // 登陆成功存Session
        HttpSession session = request.getSession();
        session.setAttribute("userInfo", user);
        return systemUser;
    }

    /**
     * 将String转化为List
     *
     * @param text
     * @return
     */
    private List<Long> convertStringToList(String text) {
        if (StringUtil.isBlank(text)) {
            return null;
        }
        List<Long> list = new ArrayList<>();
        String[] arr = text.split(",");
        for (String str : arr) {
            list.add(Long.valueOf(str));
        }
        return list;
    }

}
