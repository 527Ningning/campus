package com.heart.campus.start.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

/**
 * @author: heart
 * @date: 2018/5/18
 */
public class XsslHttpServletRequestWrapper extends HttpServletRequestWrapper {

    HttpServletRequest xssRequest = null;

    public XsslHttpServletRequestWrapper(HttpServletRequest request){
        super(request);
        xssRequest = request;
    }

    @Override
    public String getParameter(String name) {
        String value = super.getParameter(replaceXSS(name));
        if (value != null) {
            value = replaceXSS(value);
        }
        return value;
    }

    @Override
    public String[] getParameterValues(String name) {
        String[] values = super.getParameterValues(replaceXSS(name));
        if (values != null && values.length > 0) {
            for (int i = 0; i < values.length; i++) {
                values[i] = replaceXSS(values[i]);
            }
        }
        return values;
    }

    @Override
    public String getHeader(String name) {

        String value = super.getHeader(replaceXSS(name));
        if (value != null) {
            value = replaceXSS(value);
        }
        return value;
    }

    /**
     * 去除待带script、src的语句，转义替换后的value值
     */
    public static String replaceXSS(String value) {
        // if (value != null) {
        // try {
        // value = value.replace("Script|script", "scr&ipt").replaceAll("src", "s&rc");
        // value = URLDecoder.decode(value, "utf-8");
        // } catch (UnsupportedEncodingException e) {
        // } catch (IllegalArgumentException e) {
        // }
        // }
        return filter(value);
    }

    /**
     * 过滤特殊字符
     */
    public static String filter(String value) {
        if (value == null) {
            return null;
        }
        StringBuffer result = new StringBuffer(value.length());
        for (int i = 0; i < value.length(); ++i) {
            switch (value.charAt(i)) {
                case '<':
                    result.append("&lt;");
                    break;
                case '>':
                    result.append("&gt;");
                    break;
                default:
                    result.append(value.charAt(i));
                    break;
            }
        }
        return result.toString();
    }

//    public static void main(String[] args) {
//        String s = "<橘园+哈哈&<Script> alert(\"XSS\"); </Script>13舍+";
//        replaceXSS(s);
//    }
}
