package com.heart.campus.start.config;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * Web安全配置
 *
 * @author: heart
 * @date: 2017/10/28
 */
@EnableWebSecurity
@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private CustomAuthenticationProvider provider;

    /**
     * 匹配"/"路径，不需要权限即可访问<br>
     * 匹配"/user"及其以下所有路径，都需要"USER"权限<br>
     * 登录地址为"/login"，登录成功默认跳转到页面"/user"<br>
     * 退出登录地址为"/logout"，退出成功后跳转到页面"/login"<br>
     * 默认启用CSRF<br>
     *
     * @param http
     * @throws Exception
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
            .antMatchers("/")
            .permitAll()
            .antMatchers("/user/**", "/users/**")
            .hasAnyRole("USER", "ADMIN")
            .and()
            .formLogin()
            .loginPage("/login")
            .defaultSuccessUrl("/user/admin")
            .and()
            .headers()
            .frameOptions()
            .disable()
            .and()
            .logout()
            .logoutUrl("/logout")
            .logoutSuccessUrl("/login");
    }

    /**
     * 定义认证用户信息获取来源，密码校验规则等
     */
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        /**
         * 自定义登录认证
         */
        auth.authenticationProvider(provider);

    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/assets/**", "images/**", "**/*.js");
    }
}
