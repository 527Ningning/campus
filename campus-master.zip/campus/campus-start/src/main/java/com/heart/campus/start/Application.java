package com.heart.campus.start;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

/**
 * Spring Boot应用入口类
 *
 * @author: heart
 * @date: 2017/10/21
 */
@SpringBootApplication
@ImportResource("campus-application.xml")
@ComponentScan(basePackages = { "com.heart.campus.start", "com.heart.campus.web", "com.heart.campus.app",
                                "com.heart.campus.service", "com.heart.campus.dal" })
@PropertySource("classpath:application.properties")
@MapperScan(basePackages = "com.heart.campus.dal")
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }
}
