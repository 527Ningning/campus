package com.heart.campus.web.vo;

import java.io.Serializable;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/1/18
 */
public class ModuleItemVO implements Serializable {

    private static final long serialVersionUID = 8180465085921972196L;

    /**
     * 数值
     */
    private Number value;

    /**
     * 名称
     */
    private String name;

    public Number getValue() {
        return value;
    }

    public void setValue(Number value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
