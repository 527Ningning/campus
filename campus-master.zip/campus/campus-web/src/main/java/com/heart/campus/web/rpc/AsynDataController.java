package com.heart.campus.web.rpc;

import static com.heart.campus.common.util.DataUtil.TIME_FORMAT;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.heart.campus.service.data.comment.CommentService;
import com.heart.campus.service.data.comment.model.CommentModel;
import com.heart.campus.service.data.comment.param.CommentParam;
import com.heart.campus.service.redis.RedisService;
import com.heart.campus.web.vo.CommentVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;

import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.domain.ItemCluster;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.GenderEnum;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.util.DataUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.service.data.label.enums.LabelEnum;
import com.heart.campus.service.data.post.PostLabelRecordService;
import com.heart.campus.service.data.post.PostService;
import com.heart.campus.service.data.post.PostTimeRecordService;
import com.heart.campus.service.data.post.PostTypeRecordService;
import com.heart.campus.service.data.post.UserPostCountRecordService;
import com.heart.campus.service.data.post.UserPostRateRecordService;
import com.heart.campus.service.data.post.model.PostLabelRecordModel;
import com.heart.campus.service.data.post.model.PostModel;
import com.heart.campus.service.data.post.model.PostTimeRecordModel;
import com.heart.campus.service.data.post.model.PostTypeRecordModel;
import com.heart.campus.service.data.post.model.UserPostCountRecordModel;
import com.heart.campus.service.data.post.model.UserPostRateRecordModel;
import com.heart.campus.service.data.post.param.PostLabelRecordParam;
import com.heart.campus.service.data.post.param.PostParam;
import com.heart.campus.service.data.post.param.PostTimeRecordParam;
import com.heart.campus.service.data.post.param.PostTypeRecordParam;
import com.heart.campus.service.data.post.param.UserPostCountRecordParam;
import com.heart.campus.service.data.post.param.UserPostRateRecordParam;
import com.heart.campus.service.data.posttype.enums.PostTypeEnums;
import com.heart.campus.web.vo.CommonRecordVO;
import com.heart.campus.web.vo.GenderPostVO;
import com.heart.campus.web.vo.ModuleDataVO;
import com.heart.campus.web.vo.ModuleItemVO;
import com.heart.campus.web.vo.PostVO;

/**
 * 异步获取数据Controller
 * 
 * @author: heart
 * @date: 2018/01/18
 */
@RestController
@RequestMapping("/user/data")
public class AsynDataController {

    private static final int           DEFAULT_PAGE_SIZE = 9999;
    private static final String        DEFAULT_KEY       = "data";

    private static final String        MALE              = "男性";
    private static final String        FAMALE            = "女性";
    private static final String        REDIS_KEY         = "asyn_data_";
    private static final Long          REDIS_EXIT_TIME   = 3600L;

    @Autowired
    private PostService                postService;

    @Autowired
    private CommentService             commentService;

    @Autowired
    private RedisService               redisService;

    @Autowired
    private PostTimeRecordService      postTimeRecordService;

    @Autowired
    private PostTypeRecordService      postTypeRecordService;

    @Autowired
    private PostLabelRecordService     postLabelRecordService;

    @Autowired
    private UserPostRateRecordService  userPostRateRecordService;

    @Autowired
    private UserPostCountRecordService userPostCountRecordService;

    @PostMapping("/moduleData.json")
    public Result<ModuleDataVO> getModuleData() {
        String key = REDIS_KEY + "moduleData";
        if (redisService.exists(key)) {
            return ResultGenerator.genSuccess((ModuleDataVO) redisService.get(key));
        }
        ModuleDataVO dataVO = new ModuleDataVO();
        dataVO.setTitle("帖子类型占比率");
        List<ModuleItemVO> items = new ArrayList<>();
        genModuleItem(items);
        dataVO.setData(items);
        // 放入Redis缓存
        redisService.set(key, dataVO, REDIS_EXIT_TIME);
        return ResultGenerator.genSuccess(dataVO);
    }

    @PostMapping("/genderModule.json")
    public Result<List<GenderPostVO>> getGenderModule() {
        String key = REDIS_KEY + "genderModule";
        if (redisService.exists(key)) {
            return ResultGenerator.genSuccess((List<GenderPostVO>) redisService.get(key));
        }
        List<GenderPostVO> items = new ArrayList<>();
        genGenderPostTypeRecode(items);
        // 放入Redis缓存
        redisService.set(key, items, REDIS_EXIT_TIME);
        return ResultGenerator.genSuccess(items);
    }

    @PostMapping("/genderPostType.json")
    public Result<List<GenderPostVO>> getGenderPostType() {
        String key = REDIS_KEY + "genderPostType";
        if (redisService.exists(key)) {
            return ResultGenerator.genSuccess((List<GenderPostVO>) redisService.get(key));
        }
        List<GenderPostVO> items = new ArrayList<>();
        genGenderPostType(items);
        // 放入Redis缓存
        redisService.set(key, items, REDIS_EXIT_TIME);
        return ResultGenerator.genSuccess(items);
    }

    @PostMapping("/genderPostTime.json")
    public Result<List<CommonRecordVO>> getGenderPostTime() {
        String key = REDIS_KEY + "genderPostTime";
        if (redisService.exists(key)) {
            return ResultGenerator.genSuccess((List<CommonRecordVO>) redisService.get(key));
        }
        List<CommonRecordVO> items = new ArrayList<>();
        genGenderPostTime(items);
        // 放入Redis缓存
        redisService.set(key, items, REDIS_EXIT_TIME);
        return ResultGenerator.genSuccess(items);
    }

    @RequestMapping("/postList.json")
    public Map listPost() {
        Map<String, List<PostVO>> content = new HashMap<>();
        String key = REDIS_KEY + "postList";
        if (redisService.exists(key)) {
            content.put(DEFAULT_KEY, (List<PostVO>) redisService.get(key));
            return content;
        }
        PostParam param = new PostParam();
        param.setStatus(CommonStatusEnum.NORMAL.getValue());
        param.setPageSize(DEFAULT_PAGE_SIZE);
        Result<PageList<PostModel>> listResult = postService.query(param);
        if (!listResult.isSuccess() || listResult.getContent() == null) {
            content.put(DEFAULT_KEY, null);
            return content;
        }
        List<PostModel> dataList = listResult.getContent().getDataList();
        List<PostVO> postList = new ArrayList<>();
        genPostList(dataList, postList);
        // 放入Redis缓存
        redisService.set(key, postList, REDIS_EXIT_TIME);
        content.put(DEFAULT_KEY, postList);
        return content;
    }

    @RequestMapping("commentList.json")
    public Map listComment() {
        Map<String, List<CommentVO>> content = new HashMap<>();
        String key = REDIS_KEY + "commentList";
        if (redisService.exists(key)) {
            content.put(DEFAULT_KEY, (List<CommentVO>) redisService.get(key));
            return content;
        }
        CommentParam param = new CommentParam();
        param.setPageSize(DEFAULT_PAGE_SIZE);
        Result<PageList<CommentModel>> listResult = commentService.query(param);
        if (!listResult.isSuccess() || listResult.getContent() == null) {
            content.put(DEFAULT_KEY, null);
            return content;
        }
        List<CommentModel> dataList = listResult.getContent().getDataList();
        List<CommentVO> commentList = new ArrayList<>();
        genCommentList(dataList, commentList);
        // 放入Redis缓存
        redisService.set(key, commentList, REDIS_EXIT_TIME);
        content.put(DEFAULT_KEY, commentList);
        return content;
    }

    @RequestMapping("/userPostCount.json")
    public Map listUserPostCount(@RequestParam(value = "postTypeIds", required = false) String postTypeIds) {
        Map<String, CommonRecordVO> content = new HashMap<>();
        String key = REDIS_KEY + "userPostCount" + postTypeIds;
        if (redisService.exists(key)) {
            content.put(DEFAULT_KEY, (CommonRecordVO) redisService.get(key));
            return content;
        }
        UserPostCountRecordParam param = new UserPostCountRecordParam();
        param.setStatus(0);
        param.setPageSize(DEFAULT_PAGE_SIZE);
        Result<PageList<UserPostCountRecordModel>> listResult = userPostCountRecordService.query(param);
        if (!listResult.isSuccess() || listResult.getContent() == null) {
            content.put(DEFAULT_KEY, null);
            return content;
        }
        List<UserPostCountRecordModel> dataList = listResult.getContent().getDataList();
        CommonRecordVO VO = new CommonRecordVO("用户行为数量记录数据");
        List recordDataList = new ArrayList<>();
        List<String> labelList = new ArrayList<>();
        VO.setDataList(recordDataList);
        VO.setLabelList(labelList);
        JSONArray postTypeIdArr = JSONArray.parseArray(postTypeIds);
        for (UserPostCountRecordModel model : dataList) {
            List itemData = new ArrayList();

            for (int i = 0; i < postTypeIdArr.size(); i++) {
                switch (postTypeIdArr.getString(i)) {
                    case "1":
                        itemData.add(model.getTalkCount());
                        break;
                    case "2":
                        itemData.add(model.getPlayCount());
                        break;
                    case "3":
                        itemData.add(model.getMarketCount());
                        break;
                    case "4":
                        itemData.add(model.getPartTimeCount());
                        break;
                    case "5":
                        itemData.add(model.getWorkCount());
                        break;
                    case "6":
                        itemData.add(model.getStudyCount());
                        break;
                    case "7":
                        itemData.add(model.getLostCount());
                        break;
                    case "8":
                        itemData.add(model.getCampusCount());
                        break;
                    default:
                        itemData.add(model.getTalkCount());
                        itemData.add(model.getPlayCount());
                        break;
                }
            }
            recordDataList.add(itemData);
            labelList.add(model.getUserId());
        }
        int K = doAnalysis(VO.getDataList(), VO.getLabelList());
        VO.setType(K);
        // 放入Redis缓存
        redisService.set(key, VO, REDIS_EXIT_TIME);
        content.put(DEFAULT_KEY, VO);
        return content;
    }

    @RequestMapping("/userPostRate.json")
    public Map listUserPostRate(@RequestParam(value = "postRateIds", required = false) String postRateIds) {
        Map<String, CommonRecordVO> content = new HashMap<>();
        String key = REDIS_KEY + "userPostRate" + postRateIds;
        if (redisService.exists(key)) {
            content.put(DEFAULT_KEY, (CommonRecordVO) redisService.get(key));
            return content;
        }
        UserPostRateRecordParam param = new UserPostRateRecordParam();
        param.setStatus(0);
        param.setPageSize(DEFAULT_PAGE_SIZE);
        Result<PageList<UserPostRateRecordModel>> listResult = userPostRateRecordService.query(param);
        if (!listResult.isSuccess() || listResult.getContent() == null) {
            content.put(DEFAULT_KEY, null);
            return content;
        }
        List<UserPostRateRecordModel> dataList = listResult.getContent().getDataList();
        CommonRecordVO VO = new CommonRecordVO("用户行为频率记录数据");
        List recordDataList = new ArrayList<>();
        List<String> labelList = new ArrayList<>();
        VO.setDataList(recordDataList);
        VO.setLabelList(labelList);
        JSONArray postRateIdArr = JSONArray.parseArray(postRateIds);
        for (UserPostRateRecordModel model : dataList) {
            List itemData = new ArrayList();
            for (int i = 0; i < postRateIdArr.size(); i++) {
                switch (postRateIdArr.getString(i)) {
                    case "1":
                        itemData.add(model.getPostRate());
                        break;
                    case "2":
                        itemData.add(model.getVisitRate());
                        break;
                    case "3":
                        itemData.add(model.getCommentRate());
                        break;
                    case "4":
                        itemData.add(model.getUpvoteRate());
                        break;
                    default:
                        itemData.add(model.getPostRate());
                        itemData.add(model.getVisitRate());
                        break;
                }
            }
            recordDataList.add(itemData);
            labelList.add(model.getUserId());
        }
        int K = doAnalysis(VO.getDataList(), VO.getLabelList());
        VO.setType(K);
        // 放入Redis缓存
        redisService.set(key, VO, REDIS_EXIT_TIME);
        content.put(DEFAULT_KEY, VO);
        return content;
    }

    private int doAnalysis(List<List> dataList, List<String> labelList) {
        List<DataItem> dataItems = new ArrayList<>();
        for (int i = 0; i < dataList.size(); i++) {
            DataItem dataItem = new DataItem();
            dataItem.setName(labelList.get(i));
            dataItem.setItems(dataList.get(i));
            dataItems.add(dataItem);
        }
        List<ItemCluster> itemClusters = userPostCountRecordService.doAnalysis(dataItems);
        return itemClusters.size();
    }

    private void genPostList(List<PostModel> dataList, List<PostVO> postList) {
        for (PostModel post : dataList) {
            PostVO postVO = new PostVO();
            postVO.setId(post.getId());
            postVO.setTitle(post.getTitle());
            postVO.setUserId(post.getUserId());
            PostTypeEnums typeEnum = isValidPostType(post.getTypeId());
            if (typeEnum == null) {
                continue;
            }
            postVO.setType(typeEnum.getMessage());
            postVO.setGmtCreate(DataUtil.toLocaleString(post.getGmtCreate(), TIME_FORMAT));
            postVO.setUpvote(post.getUpvoteCount());
            postVO.setVisit(post.getVisitCount());
            LabelEnum labelEnum = LabelEnum.parseCode(post.getLabelId());
            if (labelEnum == null) {
                continue;
            }
            postVO.setLabel(labelEnum.getMessage());
            postList.add(postVO);
        }
    }

    private void genCommentList(List<CommentModel> dataList, List<CommentVO> commentList) {
        for (CommentModel comment : dataList) {
            CommentVO commentVO = new CommentVO();
            commentVO.setId(comment.getId());
            commentVO.setPostId(comment.getPostId());
            if (CommonStatusEnum.NORMAL.getValue().equals(comment.getStatus())) {
                commentVO.setStatus(CommonStatusEnum.NORMAL.name());
            } else {
                commentVO.setStatus(CommonStatusEnum.DELETE.name());
            }
            if (CommonStatusEnum.NORMAL.getValue().equals(comment.getBlackWhiteState())) {
                commentVO.setBlackWhiteState(false);
            } else {
                commentVO.setBlackWhiteState(true);
            }
            commentVO.setContent(comment.getContent());
            commentVO.setUserId(comment.getUserId());
            commentVO.setGmtCreate(DataUtil.toLocaleString(comment.getGmtCreate(), TIME_FORMAT));
            commentList.add(commentVO);
        }
    }

    /**
     * 判断是否为有效的帖子类型
     * 
     * @param typeId
     * @return
     */
    private PostTypeEnums isValidPostType(Integer typeId) {
        return PostTypeEnums.parseCode(typeId);
    }

    /**
     * 判断是否有效的标签
     *
     * @param model
     * @return
     */
    private LabelEnum isValidPostLabel(PostLabelRecordModel model) {
        return LabelEnum.parseCode(model.getLabelId());
    }

    private void genGenderPostTypeRecode(List<GenderPostVO> items) {
        GenderPostVO mModuleVO = new GenderPostVO();
        mModuleVO.setName(MALE);
        List<Integer> mDataList = new ArrayList();
        mModuleVO.setDataList(mDataList);
        PostTypeRecordParam mParam = new PostTypeRecordParam();
        mParam.setGender(GenderEnum.MALE.getCode());
        Result<PageList<PostTypeRecordModel>> mResult = postTypeRecordService.query(mParam);
        List<PostTypeRecordModel> mDataResult = mResult.getContent().getDataList();
        List<String> typeList = new ArrayList();
        for (PostTypeRecordModel model : mDataResult) {
            PostTypeEnums typeEnum = isValidPostType(model.getTypeId());
            if (typeEnum == null) {
                continue;
            }
            mDataList.add(model.getNumber());
            typeList.add(typeEnum.getMessage());
        }

        GenderPostVO fModuleVO = new GenderPostVO();
        fModuleVO.setName(FAMALE);
        List<Integer> fDataList = new ArrayList();
        fModuleVO.setDataList(fDataList);
        PostTypeRecordParam fParam = new PostTypeRecordParam();
        fParam.setGender(GenderEnum.FAMALE.getCode());
        Result<PageList<PostTypeRecordModel>> fResult = postTypeRecordService.query(fParam);
        List<PostTypeRecordModel> fDataResult = fResult.getContent().getDataList();
        for (PostTypeRecordModel model : fDataResult) {
            PostTypeEnums typeEnum = isValidPostType(model.getTypeId());
            if (typeEnum == null) {
                continue;
            }
            fDataList.add(model.getNumber());
        }

        mModuleVO.setLabelList(typeList);
        fModuleVO.setLabelList(typeList);

        items.add(mModuleVO);
        items.add(fModuleVO);
    }

    private void genGenderPostType(List<GenderPostVO> items) {
        GenderPostVO mModuleVO = new GenderPostVO();
        mModuleVO.setName(MALE);
        List<Integer> mDataList = new ArrayList();
        mModuleVO.setDataList(mDataList);
        PostLabelRecordParam mParam = new PostLabelRecordParam();
        mParam.setGender(GenderEnum.MALE.getCode());
        Result<PageList<PostLabelRecordModel>> mResult = postLabelRecordService.query(mParam);
        List<PostLabelRecordModel> mDataResult = mResult.getContent().getDataList();
        List<String> labelList = new ArrayList();
        for (PostLabelRecordModel model : mDataResult) {
            LabelEnum labelEnum = isValidPostLabel(model);
            if (labelEnum == null) {
                continue;
            }
            mDataList.add(model.getNumber());
            labelList.add(labelEnum.getMessage());
        }

        GenderPostVO fModuleVO = new GenderPostVO();
        fModuleVO.setName(FAMALE);
        List<Integer> fDataList = new ArrayList();
        fModuleVO.setDataList(fDataList);
        PostLabelRecordParam fParam = new PostLabelRecordParam();
        fParam.setGender(GenderEnum.FAMALE.getCode());
        Result<PageList<PostLabelRecordModel>> fResult = postLabelRecordService.query(fParam);
        List<PostLabelRecordModel> fDataResult = fResult.getContent().getDataList();
        for (PostLabelRecordModel model : fDataResult) {
            LabelEnum labelEnum = isValidPostLabel(model);
            if (labelEnum == null) {
                continue;
            }
            fDataList.add(model.getNumber());
        }

        mModuleVO.setLabelList(labelList);
        fModuleVO.setLabelList(labelList);

        items.add(mModuleVO);
        items.add(fModuleVO);
    }

    private void genGenderPostTime(List<CommonRecordVO> items) {
        CommonRecordVO mModuleVO = new CommonRecordVO();
        mModuleVO.setName(MALE);
        List mDataList = new ArrayList();
        mModuleVO.setDataList(mDataList);
        PostTimeRecordParam mParam = new PostTimeRecordParam();
        mParam.setGender(GenderEnum.MALE.getCode());
        mParam.setPageSize(DEFAULT_PAGE_SIZE);
        Result<PageList<PostTimeRecordModel>> mPostTimeResult = postTimeRecordService.query(mParam);
        PageList<PostTimeRecordModel> mContent = mPostTimeResult.getContent();
        List<PostTimeRecordModel> dataList1 = mContent.getDataList();
        genDataList(mDataList, dataList1);

        CommonRecordVO fModuleVO = new CommonRecordVO();
        fModuleVO.setName(FAMALE);
        List fDataList = new ArrayList();
        fModuleVO.setDataList(fDataList);
        PostTimeRecordParam fParam = new PostTimeRecordParam();
        fParam.setGender(GenderEnum.FAMALE.getCode());
        fParam.setPageSize(DEFAULT_PAGE_SIZE);
        Result<PageList<PostTimeRecordModel>> fPostTimeResult = postTimeRecordService.query(fParam);
        PageList<PostTimeRecordModel> fContent = fPostTimeResult.getContent();
        List<PostTimeRecordModel> dataList2 = fContent.getDataList();
        genDataList(fDataList, dataList2);

        items.add(mModuleVO);
        items.add(fModuleVO);
    }

    private void genDataList(List<Number[]> mDataList, List<PostTimeRecordModel> dataList1) {
        for (PostTimeRecordModel model : dataList1) {
            Integer[] data = new Integer[3];
            data[0] = model.getHour();
            data[1] = model.getWeek();
            data[2] = model.getNumber();
            mDataList.add(data);
        }
    }

    private void genModuleItem(List<ModuleItemVO> items) {
        for (PostTypeEnums enums : PostTypeEnums.values()) {
            ModuleItemVO item = new ModuleItemVO();
            item.setName(enums.getMessage());
            PostParam param = new PostParam();
            param.setTypeId(enums.getCode());
            param.setStatus(CommonStatusEnum.NORMAL.getValue());
            Integer count = postService.count(param);
            if (count == null || count <= 0) {
                continue;
            }
            item.setValue(count);
            items.add(item);
        }
    }

}
