package com.heart.campus.web.rpc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.heart.campus.common.result.Result;
import com.heart.campus.service.data.comment.CommentService;
import com.heart.campus.service.data.comment.model.CommentModel;
import com.heart.campus.service.data.post.PostService;
import com.heart.campus.service.data.post.model.PostModel;

/**
 * 帖子相关管理controller
 *
 * @author: heart
 * @date: 2018/4/26
 */

@Controller
@RequestMapping("/user")
public class PostManageController {

    private static final String DEFAULR_URL = "/error";

    @Autowired
    private PostService         postService;

    @Autowired
    private CommentService      commentService;

    @RequestMapping("/update-post.json")
    public ModelAndView updatePost(PostModel post) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Boolean> result = postService.update(post);
        if (result.isSuccess()) {
            mv.setViewName("/post-list");
        }
        return mv;
    }

    @RequestMapping("/delete-post.json")
    public ModelAndView deletePost(PostModel post) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Boolean> result = postService.delete(post.getId());
        if (result.isSuccess()) {
            mv.setViewName("/post-list");
        }
        return mv;
    }

    @RequestMapping("/update-comment.json")
    public ModelAndView updateComment(CommentModel comment) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Boolean> result = commentService.update(comment);
        if (result.isSuccess()) {
            mv.setViewName("/comment-list");
        }
        return mv;
    }

    @RequestMapping("/delete-comment.json")
    public ModelAndView deleteComment(CommentModel comment) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Boolean> result = commentService.relDelete(comment.getId());
        if (result.isSuccess()) {
            mv.setViewName("/comment-list");
        }
        return mv;
    }
}
