package com.heart.campus.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * 主控制器
 *
 * @author: heart
 * @date: 2017/10/28
 */
@Controller
public class MainController {

    @RequestMapping({ "/", "/login", "/logout" })
    public String login() {
        return "login";
    }

    @RequestMapping("/register")
    public String register() {
        return "register";
    }

}
