package com.heart.campus.web.rpc;

import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.common.util.SendEmailUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.heart.campus.common.result.Result;
import com.heart.campus.service.system.user.UserService;
import com.heart.campus.service.system.user.model.UserModel;

/**
 * Users Restful服务
 *
 * @author: heart
 * @date: 2018/03/10
 */
@Controller
@RequestMapping("/user")
public class UserRestController {

    private static final String DEFAULR_URL = "/error";

    @Autowired
    UserService                 userService;

    @RequestMapping("/delete-user.json")
    public ModelAndView delete(UserModel user) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Boolean> result = userService.delete(user.getId());
        if (result.isSuccess()) {
            mv.setViewName("/user-list");
        }
        return mv;
    }

    @RequestMapping("/add-user.json")
    public ModelAndView add(UserModel user) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Long> result = userService.insert(user);
        if (result.isSuccess()) {
            mv.setViewName("/user-list");
        }
        return mv;
    }

    @RequestMapping("/update-user.json")
    public ModelAndView update(UserModel user) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Boolean> result = userService.update(user);
        if (result.isSuccess()) {
            mv.setViewName("/user-list");
        }
        return mv;
    }

    @PostMapping("/send-mail.json")
    public ModelAndView sendMail(@RequestParam("theme") String theme,
                                 @RequestParam("content") String content,
                                 @RequestParam("destMail") String mail) {
        ModelAndView mv = new ModelAndView("/mail");
        try {
            SendEmailUtil.doSendEmail(theme,content,mail);
            mv.addObject("status",0);
        } catch (Exception e) {
            mv.addObject("status",-1);
            e.printStackTrace();
        }
        return mv;
    }

}
