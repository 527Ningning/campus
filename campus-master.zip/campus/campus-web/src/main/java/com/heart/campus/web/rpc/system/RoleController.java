package com.heart.campus.web.rpc.system;/**
                                        * Created by Administrator on 2018/3/22.
                                        */

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.util.DataUtil;
import com.heart.campus.service.redis.RedisService;
import com.heart.campus.service.system.role.RoleService;
import com.heart.campus.service.system.role.model.RoleModel;
import com.heart.campus.service.system.role.param.RoleParam;
import com.heart.campus.web.vo.RoleVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.heart.campus.common.util.DataUtil.TIME_FORMAT;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/22
 */
@RestController
@RequestMapping("/user")
public class RoleController {

    private static final String DEFAULT_KEY       = "data";
    private static final int    DEFAULT_PAGE_SIZE = 200;
    private static final String REDIS_KEY         = "system_data_";
    private static final Long   REDIS_EXIT_TIME   = 3600L;

    @Autowired
    private RoleService         roleService;

    @Autowired
    private RedisService        redisService;

    @RequestMapping("/roleList.json")
    public Map listRole() {
        Map<String, List<RoleVO>> content = new HashMap<>();
        String key = REDIS_KEY + "role_list";
        if (redisService.exists(key)) {
            content.put(DEFAULT_KEY, (List<RoleVO>) redisService.get(key));
        }
        RoleParam roleParam = new RoleParam();
        roleParam.setPageSize(DEFAULT_PAGE_SIZE);
        roleParam.setStatus(0);
        Result<PageList<RoleModel>> listResult = roleService.query(roleParam);
        List<RoleModel> dataList = listResult.getContent().getDataList();
        List<RoleVO> roleList = new ArrayList<>();
        genRoleList(dataList, roleList);
        // 放入Redis缓存
        redisService.set(key, roleList);
        content.put(DEFAULT_KEY, roleList);
        return content;
    }

    private void genRoleList(List<RoleModel> dataList, List<RoleVO> roleList) {
        for (RoleModel role : dataList) {
            RoleVO roleVO = new RoleVO();
            roleVO.setId(role.getId());
            roleVO.setName(role.getName());
            roleVO.setDesc(role.getDesc());
            roleVO.setGmtCreate(DataUtil.toLocaleString(role.getGmtCreate(), TIME_FORMAT));
            Integer status = role.getStatus();
            if (1 == status) {
                roleVO.setStatus("无效");
            } else {
                roleVO.setStatus("有效");
            }
            roleList.add(roleVO);
        }
    }

}
