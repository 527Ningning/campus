package com.heart.campus.web.vo;

import java.io.Serializable;
import java.util.List;

/**
 * @Description: 通用数据记录VO
 * @Author: heart
 * @Date: 2018/3/30
 */
public class CommonRecordVO implements Serializable {

    private static final long serialVersionUID = 1455769196L;

    private String            name;
    private List<String>      labelList;
    private List<List>        dataList;
    private Integer           type;

    public CommonRecordVO(){
    }

    public CommonRecordVO(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getLabelList() {
        return labelList;
    }

    public void setLabelList(List<String> labelList) {
        this.labelList = labelList;
    }

    public List<List> getDataList() {
        return dataList;
    }

    public void setDataList(List<List> dataList) {
        this.dataList = dataList;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
