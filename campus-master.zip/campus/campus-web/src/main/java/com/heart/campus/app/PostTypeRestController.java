package com.heart.campus.app;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.service.data.posttype.PostTypeService;
import com.heart.campus.service.data.posttype.model.PostTypeModel;
import com.heart.campus.service.data.posttype.param.PostTypeParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * 帖子类别restful接口
 *
 * @author: yuwu
 * @date: 2017/11/28
 */
@RestController
@RequestMapping("/app/postType")
public class PostTypeRestController {

    @Autowired
    PostTypeService postTypeService;

    /**
     * 拉取所有的帖子类别
     * 
     * @return
     */
    @RequestMapping(value = "/lists", method = RequestMethod.GET)
    public Result<PageList<PostTypeModel>> getAllTypeList() {

        PostTypeParam param = new PostTypeParam();
        param.setStatus(CommonStatusEnum.NORMAL.getValue());
        param.setPage(1);
        param.setPageSize(10);
        return postTypeService.query(param);
    }

}
