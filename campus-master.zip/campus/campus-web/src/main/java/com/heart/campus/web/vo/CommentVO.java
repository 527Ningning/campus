package com.heart.campus.web.vo;

import java.io.Serializable;

/**
 * @Description: 评论VO
 * @Author: heart
 * @Date: 2018/3/22
 */
public class CommentVO implements Serializable {

    private static final long serialVersionUID = 1255769196L;

    /**
     * 序号
     */
    private long              id;

    /**
     * 状态
     */
    private String            status;

    /**
     * 是否列入黑名单
     */
    private boolean           blackWhiteState;

    /**
     * 
     */
    private String            postId;

    /**
     * 
     */
    private String            userId;

    /**
     * 
     */
    private String            content;

    /**
     * 
     */
    private String            gmtCreate;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isBlackWhiteState() {
        return blackWhiteState;
    }

    public void setBlackWhiteState(boolean blackWhiteState) {
        this.blackWhiteState = blackWhiteState;
    }

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(String gmtCreate) {
        this.gmtCreate = gmtCreate;
    }
}
