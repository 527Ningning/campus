package com.heart.campus.app;

import com.heart.campus.app.vo.UserVO;
import com.heart.campus.common.enums.CommonRolesEnum;
import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.util.ParamsVerifier;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.common.util.StringUtil;
import com.heart.campus.service.system.user.UserService;
import com.heart.campus.service.system.user.model.UserModel;

/**
 * App用户 Restful接口
 *
 * @author: yuwu
 * @date: 2017/11/21
 */
@RestController
@RequestMapping("/app/user")
public class UserLoginRestController {

    @Autowired
    UserService userService;

    /**
     * App用户【一般】登录模式
     *
     * @param userId
     * @param password
     * @return
     */
    @RequestMapping(value = "/loginByCommon", method = RequestMethod.POST)
    public Result<UserModel> checkValid(@RequestParam(value = "userId", required = false) String userId,
                                        @RequestParam(value = "password", required = false) String password) {
        if (ParamsVerifier.isEmpty(userId,password)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<UserModel> result = userService.getByUserId(userId);
        if (result.isSuccess() && result.getContent() != null
            && result.getContent().getUserPassword().equals(password)) {
            return result;
        }
        return ResultGenerator.genError(ErrorCodeEnum.USER_LOGIN_INVALID);
    }

    /**
     * App用户【一般】注册模式
     *
     * @return
     */
    @RequestMapping(value = "/registerByCommon", method = RequestMethod.POST)
    public Result<Long> register(UserVO user) {
        if (user == null || ParamsVerifier.isNull(user.getUserId(),user.getPassword(),user.getPhone())) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<UserModel> result = userService.getByUserId(user.getUserId());
        if (result.isSuccess() && result.getContent() != null) {
            return ResultGenerator.genError(ErrorCodeEnum.USER_ID_DUPLICATE);
        }
        UserModel model = new UserModel();
        model.setUserId(user.getUserId());
        model.setUserName(user.getName());
        model.setUserPassword(user.getPassword());
        model.setUserBlackWhiteState(0);
        model.setUserAddress(user.getAddress());
        model.setUserSchool(user.getSchool());
        model.setUserGender(Integer.valueOf(user.getGender()));
        model.setUserSubject(user.getSubject());
        model.setUserPhone(user.getPhone());
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        model.setRoles(CommonRolesEnum.USER.getValue());
        Result<Long> insertResult = userService.insert(model);
        if (insertResult.isSuccess()) {
            return insertResult;
        }
        return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_INVALID);
    }

    /**
     * APP用户修改个人信息
     * 
     * @param userId
     * @param password
     * @param name
     * @param gender
     * @param phone
     * @param school
     * @param subject
     * @param address
     * @return
     */
    @RequestMapping(value = "", method = RequestMethod.PUT)
    public Result<Boolean> modified(@RequestParam(value = "id", required = false) String id,
                                    @RequestParam(value = "userId", required = false) String userId,
                                    @RequestParam(value = "password", required = false) String password,
                                    @RequestParam(value = "name", required = false) String name,
                                    @RequestParam(value = "gender", required = false) String gender,
                                    @RequestParam(value = "phone", required = false) String phone,
                                    @RequestParam(value = "school", required = false) String school,
                                    @RequestParam(value = "subject", required = false) String subject,
                                    @RequestParam(value = "address", required = false) String address) {

        if (StringUtil.isBlank(userId) || StringUtil.isBlank(password) || StringUtil.isBlank(name)
            || StringUtil.isBlank(gender) || StringUtil.isBlank(phone) || StringUtil.isBlank(school)
            || StringUtil.isBlank(subject) || StringUtil.isBlank(address)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }

        Result<UserModel> result = userService.getByUserId(userId);
        if (result.isSuccess() && result.getContent() != null
            && result.getContent().getUserPassword().equals(password)) {
            UserModel model = new UserModel();
            model.setId(Long.valueOf(id));
            model.setUserId(userId);
            model.setUserName(name);
            model.setUserPassword(password);
            model.setUserBlackWhiteState(0);
            model.setUserAddress(address);
            model.setUserSchool(school);
            model.setUserGender(Integer.valueOf(gender));
            model.setUserSubject(subject);
            model.setUserPhone(phone);
            model.setStatus(CommonStatusEnum.NORMAL.getValue());
            model.setRoles(CommonRolesEnum.USER.getValue());
            Result<Boolean> modifiedResult = userService.update(model);
            return modifiedResult;
        }

        return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_INVALID);
    }

    /**
     * 通过用户学号获取用户信息 用途: 通过发帖人头像点进去查看用户信息
     *
     * @param userId
     * @return
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public Result<UserModel> getByUserId(@RequestParam(value = "userId") String userId) {
        return userService.getByUserId(userId);
    }

}
