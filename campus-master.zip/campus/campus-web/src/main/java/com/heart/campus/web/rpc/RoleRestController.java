package com.heart.campus.web.rpc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.heart.campus.common.result.Result;
import com.heart.campus.service.system.role.RoleService;
import com.heart.campus.service.system.role.model.RoleModel;

/**
 * Role Restful服务
 *
 * @author: heart
 * @date: 2018/03/10
 */
@Controller
@RequestMapping("/user")
public class RoleRestController {

    private static final String DEFAULR_URL = "/error";

    @Autowired
    private RoleService         roleService;

    @RequestMapping("/delete-role.json")
    public ModelAndView delete(RoleModel role) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Boolean> result = roleService.delete(role.getId());
        if (result.isSuccess()) {
            mv.setViewName("/role-list");
        }
        return mv;
    }

    @RequestMapping("/add-role.json")
    public ModelAndView add(RoleModel role) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Long> result = roleService.insert(role);
        if (result.isSuccess()) {
            mv.setViewName("/role-list");
        }
        return mv;
    }

    @RequestMapping("/update-role.json")
    public ModelAndView update(RoleModel role) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<Boolean> result = roleService.update(role);
        if (result.isSuccess()) {
            mv.setViewName("/role-list");
        }
        return mv;
    }

}
