package com.heart.campus.web.vo;

import java.io.Serializable;

/**
 * @Description: 基础数据VO
 * @Author: heart
 * @Date: 2018/1/18
 */
public abstract class BaseDataVO implements Serializable {

    private static final long serialVersionUID = 1238241477L;

    /**
     * 数据标题
     */
    private String            title;

    /**
     * 数据项
     */
    private Object            data;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
