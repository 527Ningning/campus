package com.heart.campus.web.vo;

import java.io.Serializable;
import java.util.List;

/**
 * @Description: 男女发帖模块VO
 * @Author: heart
 * @Date: 2018/3/30
 */
public class GenderPostVO implements Serializable {

    private static final long serialVersionUID = 1424655769196L;

    private String name;
    private List   dataList;
    private List   labelList;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List getDataList() {
        return dataList;
    }

    public void setDataList(List dataList) {
        this.dataList = dataList;
    }

    public List getLabelList() {
        return labelList;
    }

    public void setLabelList(List labelList) {
        this.labelList = labelList;
    }
}
