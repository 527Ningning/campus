package com.heart.campus.web.bops;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.heart.campus.common.result.Result;
import com.heart.campus.service.data.comment.CommentService;
import com.heart.campus.service.data.comment.model.CommentModel;
import com.heart.campus.service.data.post.PostService;
import com.heart.campus.service.data.post.model.PostModel;
import com.heart.campus.service.system.member.MemberService;
import com.heart.campus.service.system.member.model.MemberModel;
import com.heart.campus.service.system.role.RoleService;
import com.heart.campus.service.system.role.model.RoleModel;
import com.heart.campus.service.system.user.UserService;
import com.heart.campus.service.system.user.model.UserModel;

/**
 * 后台跳转控制器
 *
 * @author: heart
 * @date: 2018/1/20
 */
@Controller
@RequestMapping("/user")
public class PathController {

    private static final String DEFAULR_URL = "/error";

    @Autowired
    private HttpServletRequest  request;

    @Autowired
    private UserService         userService;

    @Autowired
    private RoleService         roleService;

    @Autowired
    private PostService         postService;

    @Autowired
    private CommentService      commentService;

    @Autowired
    private MemberService       memberService;

    /**
     * 如果是/user/**路径则需要登录认证<br>
     * 未登录跳转至登录页面
     *
     * @ret urn
     */
    @RequestMapping({"", "/", "/admin", "/data"})
    public ModelAndView user() {
        ModelAndView mv = new ModelAndView("index");
        HttpSession session = request.getSession();
        Object userInfo = session.getAttribute("userInfo");
        mv.addObject("userInfo", userInfo);
        return mv;
    }

    @RequestMapping("/addUser")
    public String addUser() {
        return "user-add";
    }

    @RequestMapping("/editUser")
    public ModelAndView editUser(Long id) {
        ModelAndView mv = new ModelAndView("user-edit");
        Result<UserModel> result = userService.find(id);
        if (!result.isSuccess() || result.getContent() == null) {
            return mv;
        }
        mv.addObject("user", result.getContent());
        return mv;
    }

    @RequestMapping("/addRole")
    public String addRole() {
        return "role-add";
    }

    @RequestMapping("/editRole")
    public ModelAndView editRole(Long id) {
        ModelAndView mv = new ModelAndView("role-edit");
        Result<RoleModel> result = roleService.find(id);
        if (!result.isSuccess() || result.getContent() == null) {
            return mv;
        }
        mv.addObject("role", result.getContent());
        return mv;
    }

    @RequestMapping("/editPost")
    public ModelAndView editPost(Long id) {
        ModelAndView mv = new ModelAndView("post-edit");
        Result<PostModel> result = postService.find(id);
        if (!result.isSuccess() || result.getContent() == null) {
            return mv;
        }
        mv.addObject("post", result.getContent());
        return mv;
    }

    @RequestMapping("/editComment")
    public ModelAndView editComment(Long id) {
        ModelAndView mv = new ModelAndView("comment-edit");
        Result<CommentModel> result = commentService.find(id);
        if (!result.isSuccess() || result.getContent() == null) {
            return mv;
        }
        mv.addObject("comment", result.getContent());
        return mv;
    }

    @RequestMapping("/data-statistics")
    public String dataStatistics() {
        return "data-statistics";
    }

    @RequestMapping("/data-analysis")
    public String dataAnalysis() {
        return "data-analysis";
    }

    @RequestMapping("/user-list")
    public String userList() {
        return "user-list";
    }

    @RequestMapping("/role-list")
    public String roleList() {
        return "role-list";
    }

    @RequestMapping("/post-list")
    public String postList() {
        return "post-list";
    }

    @RequestMapping("/comment-list")
    public String commentList() {
        return "comment-list";
    }

    @RequestMapping("/mail")
    public String sendMail() {
        return "mail";
    }

    @RequestMapping("/list-member")
    public ModelAndView listMember() {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<List<MemberModel>> result = memberService.loadMemberList();
        if (result.isSuccess()) {
            mv.setViewName("team");
            mv.addObject("memberDtos", result.getContent());
        }
        return mv;
    }

    @RequestMapping("/member/detail.json")
    public ModelAndView memberDetail(@RequestParam("mid") long mId) {
        ModelAndView mv = new ModelAndView(DEFAULR_URL);
        Result<MemberModel> result = memberService.find(mId);
        if (result.isSuccess()) {
            mv.setViewName("detail");
            mv.addObject("member", result.getContent());
        }
        return mv;
    }

}
