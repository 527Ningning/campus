package com.heart.campus.app;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.util.NumberUtil;
import com.heart.campus.common.util.ResultGenerator;
import com.heart.campus.common.util.StringUtil;
import com.heart.campus.service.data.post.PostService;
import com.heart.campus.service.data.post.model.PostModel;
import com.heart.campus.service.data.post.param.PostParam;
import com.heart.campus.service.system.user.UserService;
import com.heart.campus.service.system.user.model.UserModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * APP帖子 接口
 *
 * @author: yuwu
 * @date: 2017/11/27
 */
@RestController
@RequestMapping("/app/post")
public class PostRestController {

    @Autowired
    PostService postService;

    @Autowired
    UserService userService;

    /**
     * 根据帖子类别获得帖子列表 【注意】:当postType传参为空时,默认拉取所有帖子
     *
     * @param postType
     * @return
     */
    @RequestMapping(value = "/lists", method = RequestMethod.GET)
    public Result<PageList<PostModel>> getAllListByType(@RequestParam(value = "postType", required = false) String postType) {

        if (NumberUtil.stringToInt(postType) != -1 || postType == null) {
            PostParam param = new PostParam();
            if (postType != null) {
                param.setTypeId(NumberUtil.stringToInt(postType));
            }
            param.setStatus(CommonStatusEnum.NORMAL.getValue());
            param.setPage(1);
            param.setPageSize(20);
            param.setCountNeeded(true);
            return postService.query(param);
        } else {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_INVALID);
        }
    }

    /**
     * 根据用户学号和帖子类别获得帖子列表
     * 
     * @param userId
     * @param postType
     * @return
     */
    @RequestMapping(value = "/myLists", method = RequestMethod.GET)
    public Result<PageList<PostModel>> getUserListByUserId(@RequestParam(value = "userId", required = false) String userId,
                                                           @RequestParam(value = "postType", required = false) String postType) {
        if (userId == null) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        if (NumberUtil.stringToInt(postType) != -1 || postType == null) {
            PostParam param = new PostParam();
            param.setUserId(userId);
            if (postType != null) {
                param.setTypeId(NumberUtil.stringToInt(postType));
            }
            param.setStatus(CommonStatusEnum.NORMAL.getValue());
            param.setPage(1);
            param.setPageSize(10);
            param.setCountNeeded(true);
            return postService.query(param);
        } else {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_INVALID);
        }
    }

    /**
     * 发帖
     * 
     * @param postType
     * @param title
     * @param userId
     * @param content
     * @return
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    public Result<Long> post(@RequestParam(value = "postType", required = false) String postType,
                             @RequestParam(value = "title", required = false) String title,
                             @RequestParam(value = "userId", required = false) String userId,
                             @RequestParam(value = "content", required = false) String content) {

        if (StringUtil.isBlank(userId) || StringUtil.isBlank(title) || StringUtil.isBlank(content)
            || NumberUtil.stringToInt(postType) == -1) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_INVALID);
        }

        PostModel model = new PostModel();
        model.setUserId(userId);
        model.setPostId("111111");
        model.setTypeId(NumberUtil.stringToInt(postType));
        model.setTitle(title);
        model.setContent(content);
        model.setPriority(0);
        model.setUpvoteCount(0);
        model.setVisitCount(0);
        model.setBlackWhiteState(0);
        model.setStatus(CommonStatusEnum.NORMAL.getValue());
        return postService.insert(model);
    }

    /**
     * 用户删除个人帖子
     * 
     * @param postId
     * @param userId
     * @param password
     * @return
     */
    @RequestMapping(value = "", method = RequestMethod.PUT)
    public Result<Boolean> putPost(@RequestParam(value = "postId", required = false) Long postId,
                                   @RequestParam(value = "userId", required = false) String userId,
                                   @RequestParam(value = "password", required = false) String password) {

        if (StringUtil.isBlank(userId) || postId == null || StringUtil.isBlank(password)) {
            return ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL);
        }
        Result<UserModel> userResult = userService.getByUserId(userId);
        if (!userResult.isSuccess() || userResult.getContent() == null
            || !password.equals(userResult.getContent().getUserPassword())) {
            return ResultGenerator.genError(ErrorCodeEnum.USER_LOGIN_INVALID);
        }
        Result<PostModel> result = postService.find(postId);
        if (result.isSuccess() && result.getContent() != null && userId.equals(result.getContent().getUserId())) {
            return postService.delete(postId);
        } else {
            return ResultGenerator.genError(ErrorCodeEnum.OPERATION_IS_INVALID);
        }
    }

    /**
     * 根据帖子ID获取具体帖子
     * 
     * @param postId
     * @return
     */
    @RequestMapping(value = "", method = RequestMethod.GET)
    public Result<PostModel> getPostById(@RequestParam(value = "postId", required = false) Long postId) {

        Result<PostModel> result = postService.getLiveById(postId);
        if (result.isSuccess() && result.getContent() != null) {
            PostModel model = result.getContent();
            model.setVisitCount(model.getVisitCount() + 1);
            postService.update(model);
        }
        return result;
    }

    /*
     * @RequestMapping(value = "/upvote", method = RequestMethod.POST) public
     * Result<Boolean> postUpvote(@RequestParam(value = "postId", required = false)
     * Long postId,
     * @RequestParam(value = "upvote", required = false) Integer upvote) { if
     * (postId == null || upvote == null) { return
     * ResultGenerator.genError(ErrorCodeEnum.PARAM_IS_NULL); } Result<PostModel>
     * result = postService.find(postId) if (upvote == 1) { } else { } }
     */

}
