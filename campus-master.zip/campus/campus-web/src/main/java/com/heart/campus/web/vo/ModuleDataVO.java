package com.heart.campus.web.vo;

/**
 * @Description: 图表数据模型VO
 * @Author: heart
 * @Date: 2018/1/18
 */
public class ModuleDataVO extends BaseDataVO {

    private static final long serialVersionUID = 1438841467L;

}
