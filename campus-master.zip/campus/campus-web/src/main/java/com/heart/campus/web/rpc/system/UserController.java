package com.heart.campus.web.rpc.system;/**
                                        * Created by Administrator on 2018/3/22.
                                        */

import com.heart.campus.common.page.PageList;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.util.DataUtil;
import com.heart.campus.service.redis.RedisService;
import com.heart.campus.service.system.user.UserService;
import com.heart.campus.service.system.user.model.UserModel;
import com.heart.campus.service.system.user.param.UserParam;
import com.heart.campus.web.vo.UserVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.heart.campus.common.util.DataUtil.TIME_FORMAT;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/22
 */
@RestController
@RequestMapping("/user")
public class UserController {

    private static final String DEFAULT_KEY       = "data";
    private static final int    DEFAULT_PAGE_SIZE = 9999;
    private static final String REDIS_KEY         = "system_data_";
    private static final Long   REDIS_EXIT_TIME   = 3600L;

    @Autowired
    private UserService         userService;

    @Autowired
    private RedisService        redisService;

    @RequestMapping("/userList.json")
    public Map listUser() {
        Map<String, List<UserVO>> content = new HashMap<>();
        String key = REDIS_KEY + "user_list";
        if (redisService.exists(key)) {
            content.put(DEFAULT_KEY, (List<UserVO>) redisService.get(key));
        }
        UserParam param = new UserParam();
        param.setStatus(0);
        param.setPageSize(DEFAULT_PAGE_SIZE);
        Result<PageList<UserModel>> listResult = userService.query(param);
        List<UserModel> dataList = listResult.getContent().getDataList();
        List<UserVO> userList = new ArrayList<>();
        genUserList(dataList, userList);
        // 放入Redis缓存
        redisService.set(key, userList);
        content.put(DEFAULT_KEY, userList);
        return content;
    }

    private void genUserList(List<UserModel> dataList, List<UserVO> userList) {
        for (UserModel user : dataList) {
            UserVO userVO = new UserVO();
            userVO.setId(user.getId());
            userVO.setUserId(user.getUserId());
            userVO.setUserName(user.getUserName());
            userVO.setUserPhone(user.getUserPhone());
            userVO.setUserEmail(user.getUserEmail());
            userVO.setUserAddress(user.getUserAddress());
            userVO.setUserSchool(user.getUserSchool());
            userVO.setGmtCreate(DataUtil.toLocaleString(user.getGmtCreate(), TIME_FORMAT));
            int userGender = user.getUserGender();
            if (userGender == 1) {
                userVO.setUserGender("男");
            } else {
                userVO.setUserGender("女");
            }
            userList.add(userVO);
        }
    }

}
