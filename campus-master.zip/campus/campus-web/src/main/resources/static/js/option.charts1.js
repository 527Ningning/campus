function getOptionCharts1(item, label) {
    // 指定图表的配置项和数据
    option = {
        title: {
            text: item.title,
            subtext: '数据来自校园信息共享平台',
            left: 'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: "{b} : {c} ({d}%)"
        },
        legend: {
            type: 'scroll',
            // orient: 'vertical',
            // top: 'middle',
            bottom: 10,
            left: 'center',
            data: label
        },
        series: [
            {
                type: 'pie',
                radius: '65%',
                center: ['50%', '50%'],
                selectedMode: 'single',
                data: item.data,
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    }
                }
            }
        ]
    };

    return option;
}
