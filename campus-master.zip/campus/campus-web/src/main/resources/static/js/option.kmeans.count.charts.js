function getOptionKmeansCountCharts(item) {

    var data = item.dataList;
    var labelList = item.labelList;
    var clusterNumber = item.type;
    var step = ecStat.clustering.hierarchicalKMeans(data, clusterNumber, true);
    var result;

    option = {
        timeline: {
            top: 'center',
            right: 35,
            height: 300,
            width: 10,
            inverse: true,
            playInterval: 2500,
            symbol: 'none',
            orient: 'vertical',
            axisType: 'category',
            autoPlay: true,
            label: {
                normal: {
                    show: false
                }
            },
            data: []
        },
        baseOption: {
            title: {
                text: 'KMeans分析——基于学生发帖类型数量',
                subtext: '数据来自校园信息共享平台',
                left: 'center'
            },
            xAxis: {
                type: 'value'
            },
            yAxis: {
                type: 'value'
            },
            series: [{
                type: 'scatter'
            }]
        },
        options: []
    };

    for (var i = 0; !(result = step.next()).isEnd; i++) {

        option.options.push(getOption(result, clusterNumber));
        option.timeline.data.push(i + '');

    }

    function getOption(result, k) {
        var clusterAssment = result.clusterAssment;
        var centroids = result.centroids;
        var ptsInCluster = result.pointsInCluster;
        var color = ['#c23531', '#2f4554', '#61a0a8', '#d48265', '#91c7ae', '#749f83', '#ca8622', '#bda29a', '#6e7074', '#546570', '#c4ccd3'];
        var series = [];
        for (i = 0; i < k; i++) {
            series.push({
                name: 'scatter' + i,
                type: 'scatter',
                animation: false,
                data: ptsInCluster[i],
                label: {
                    emphasis: {
                        show: true,
                        formatter: function (param) {
                            return labelList[param.dataIndex];
                        },
                        position: 'top',
                        fontSize: 16
                    }
                },
                markPoint: {
                    symbolSize: 29,
                    label: {
                        normal: {
                            show: false
                        },
                        emphasis: {
                            show: true,
                            position: 'top',
                            formatter: function (params) {
                                return Math.round(params.data.coord[0] * 100) / 100 + '  ' +
                                    Math.round(params.data.coord[1] * 100) / 100 + ' ';
                            },
                            textStyle: {
                                color: '#000'
                            }
                        }
                    },
                    itemStyle: {
                        normal: {
                            opacity: 1.0
                        }
                    },
                    data: [{
                        coord: centroids[i]
                    }]
                }
            });
        }

        return {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross'
                }
            },
            series: series,
            color: color
        };
    }

    return option;
}
