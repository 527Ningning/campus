function getOptionCharts3(item) {
    option = {
        title: {
            text: '男性女性发帖类型统计',
            subtext: '数据来自校园信息共享平台',
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                label: {
                    backgroundColor: '#6a7985'
                }
            }
        },
        legend: {
            data: ['男性', '女性']
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                data: item[0].labelList
            }
        ],
        yAxis: [
            {
                type: 'value'
            }
        ],
        series: [
            {
                name: item[0].name,
                color: '#aae0d6',
                type: 'line',
                stack: '总量',
                areaStyle: {normal: {}},
                data: item[0].dataList,
                smooth: true
            },
            {
                name: item[1].name,
                color: '#da5e3b',
                type: 'line',
                stack: '总量',
                areaStyle: {normal: {}},
                data: item[1].dataList,
                smooth: true
            }
        ]
    };
    return option;
}
