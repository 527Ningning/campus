function getOptionCharts4(item, max_value) {
    option = {
        title: {
            text: '男女性别发帖标签统计',
            subtext: '数据来自校园信息共享平台',
            x: 'center',
            align: 'right'
        },
        grid: {
            bottom: 80
        },
        toolbox: {
            feature: {
                dataZoom: {
                    yAxisIndex: 'none'
                },
                restore: {},
                saveAsImage: {}
            }
        },
        tooltip: {
            trigger: 'axis',
            axisPointer: {
                type: 'cross',
                animation: false,
                label: {
                    backgroundColor: '#505765'
                }
            }
        },
        legend: {
            data: ['男性', '女性'],
            x: 'left'
        },
        dataZoom: [
            {
                show: true,
                realtime: true,
                start: 0,
                end: 100
            },
            {
                type: 'inside',
                realtime: true,
                start: 0,
                end: 100
            }
        ],
        xAxis: [
            {
                type: 'category',
                boundaryGap: false,
                axisLine: {onZero: false},
                data: item[0].labelList
            }
        ],
        yAxis: [
            {
                name: '发帖数',
                type: 'value',
                max: max_value
            },
            {
                name: '发帖数',
                nameLocation: 'start',
                type: 'value',
                max: max_value,
                inverse: true
            }
        ],
        series: [
            {
                name: item[0].name,
                color: '#166b98',
                type: 'line',
                animation: false,
                areaStyle: {
                    normal: {}
                },
                lineStyle: {
                    normal: {
                        width: 1
                    }
                },
                data: item[0].dataList,
                smooth: true
            },
            {
                name: item[1].name,
                color: '#ca5436',
                type: 'line',
                yAxisIndex: 1,
                animation: false,
                areaStyle: {
                    normal: {}
                },
                lineStyle: {
                    normal: {
                        width: 1
                    }
                },
                data: item[1].dataList,
                smooth: true
            }
        ]
    };

    return option;
}
