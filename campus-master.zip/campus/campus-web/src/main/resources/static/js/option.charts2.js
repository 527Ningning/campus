function getOptionCharts2(item) {

    var hours = ['12a', '1a', '2a', '3a', '4a', '5a', '6a',
        '7a', '8a', '9a', '10a', '11a',
        '12p', '1p', '2p', '3p', '4p', '5p',
        '6p', '7p', '8p', '9p', '10p', '11p'];
    var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    var data_m = item[0].dataList;
    var data_f = item[1].dataList;
    option = {
        backgroundColor: '#668B8B',

        title: {
            text: '大学生发帖时间分布图',
            subtext: '数据来自校园信息共享平台',
            textStyle: {
                color: '#ffffff'
            }
        },
        legend: {
            data: [item[0].name, item[1].name],
            left: 'right',
            textStyle: {
                color: '#ffffff'
            }
        },
        polar: {},
        tooltip: {
            formatter: function (params) {
                return params.value[2] + ' commits in ' + hours[params.value[1]] + ' of ' + days[params.value[0]];
            }
        },
        angleAxis: {
            type: 'category',
            data: hours,
            boundaryGap: false,
            splitLine: {
                show: true,
                lineStyle: {
                    color: '#ffffff',
                    type: 'dashed'
                }
            },
            axisLine: {
                show: false
            }
        },
        radiusAxis: {
            type: 'category',
            data: days,
            axisLine: {
                show: false
            },
            axisLabel: {
                rotate: 45
            }
        },
        series: [
            {
                name: item[0].name,
                type: 'scatter',
                coordinateSystem: 'polar',
                symbolSize: function (val) {
                    return val[2] * 2;
                },
                data: data_m,
                animationDelay: function (idx) {
                    return idx * 5;
                }
            },
            {
                name: item[1].name,
                type: 'scatter',
                color: '#BBFFFF',
                coordinateSystem: 'polar',
                symbolSize: function (val) {
                    return val[2] * 2;
                },
                data: data_f,
                animationDelay: function (idx) {
                    return idx * 5;
                }
            }
        ]
    };

    return option;
}
