package com.heart.campus.common.util;

import java.util.Collection;
import java.util.Map;

/**
 * <strong>描述：</strong>集合工具类<br>
 * <strong>功能：</strong>判断集合是否为空<br>
 *
 * @author: heart
 * @date: 2017/10/21
 */
public class CollectionUtil {

    /**
     * Return <code>true</code> if the supplied Collection is <code>null</code> or
     * empty. Otherwise, return <code>false</code>.
     *
     * @param collection the Collection to check
     * @return whether the given Collection is empty
     */
    public static boolean isEmpty(Collection<?> collection) {
        return (collection == null || collection.isEmpty());
    }

    public static boolean isNotEmpty(Collection<?> collection) {
        return !isEmpty(collection);
    }

    /**
     * Return <code>true</code> if the supplied Map is <code>null</code> or empty.
     * Otherwise, return <code>false</code>.
     *
     * @param map the Map to check
     * @return whether the given Map is empty
     */
    public static boolean isEmpty(Map<?, ?> map) {
        return (map == null || map.isEmpty());
    }

    public static boolean isNotEmpty(Map<?, ?> map) {
        return !isEmpty(map);
    }

}
