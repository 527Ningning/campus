package com.heart.campus.common.enums;

/**
 * 角色状态枚举类
 * 
 * @author: yuwu
 * @date: 2017/11/23
 */
public enum CommonRolesEnum {
    /**
     * 一般使用用户
     */
    USER("1"),

    /**
     * 管理员用户
     */
    ADMIN("2");

    String value;

    CommonRolesEnum(String value) {
        this.value = value;
    }

    public String getValue(){
        return value;
    }
}
