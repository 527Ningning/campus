package com.heart.campus.common.enums;

/**
 * 性别枚举
 *
 * @author: heart
 * @date: 2018/4/19
 */
public enum GenderEnum {

    /**
     * 男性
     */
    MALE(1),

    /**
     * 女性
     */
    FAMALE(0);

    int code;

    GenderEnum(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }
}
