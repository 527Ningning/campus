package com.heart.campus.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.common.domain.AbstractDO;
import com.heart.campus.common.domain.AbstractModel;
import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.mapper.AbstractMapper;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.page.Paginator;
import com.heart.campus.common.param.AbstractQueryParam;
import com.heart.campus.common.param.IbatisQueryParam;
import com.heart.campus.common.result.Result;
import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.StringUtil;

/**
 * @author: heart
 * @date: 2017/10/23
 */
public abstract class DefaultService<M extends AbstractModel, D extends AbstractDO, P extends AbstractQueryParam> {

    private static final String DEFAULT_ORDER_BY = "ID";
    private static final String DEFAULT_ORDER    = "DESC";
    private static final String DEFAULT_ID       = "id";

    /**
     * 创建一条记录
     *
     * @param model
     * @return
     */
    public Result<Long> insert(M model) {
        Result<Long> result = new Result<>();
        result.setSuccess(false);
        if (model == null) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_NULL.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_NULL.getMessage());
            return result;
        }
        final D d = getMapper().toDO(model);
        if (d == null) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_INVALID.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_INVALID.getMessage());
            return result;
        }
        Integer num = getDao().insert(d);
        if (num == null || num <= 0 || d.getId() == null || d.getId() <= 0) {
            result.setErrCode(ErrorCodeEnum.SERVICE_IS_ERROR.getCode());
            result.setErrMessage(ErrorCodeEnum.SERVICE_IS_ERROR.getMessage());
            return result;
        }
        result.setContent(d.getId());
        result.setSuccess(true);
        return result;
    }

    public Result<Integer> batchInsert(List<M> models) {
        Result<Integer> result = new Result<>();
        result.setSuccess(false);
        if (models == null || models.size() == 0) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_NULL.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_NULL.getMessage());
            return result;
        }
        List<D> dos = new ArrayList<>();
        for (M model : models) {
            D d = getMapper().toDO(model);
            dos.add(d);
        }
        if (dos == null || dos.size() == 0) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_INVALID.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_INVALID.getMessage());
            return result;
        }
        Integer num = getDao().batchInsert(dos);
        if (num == null || num <= 0) {
            result.setErrCode(ErrorCodeEnum.SERVICE_IS_ERROR.getCode());
            result.setErrMessage(ErrorCodeEnum.SERVICE_IS_ERROR.getMessage());
            return result;
        }
        result.setContent(num);
        result.setSuccess(true);
        return result;
    }

    /**
     * 根据主键id更新
     *
     * @param model
     * @return
     */
    public Result<Boolean> update(M model) {
        Result<Boolean> result = new Result<>();
        result.setSuccess(false);
        if (model == null) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_NULL.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_NULL.getMessage());
            return result;
        }
        final D d = getMapper().toDO(model);
        if (d == null || d.getId() == null) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_INVALID.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_INVALID.getMessage());
            return result;
        }

        Map<String, Object> whereParam = new HashMap<String, Object>();
        whereParam.put(DEFAULT_ID, d.getId());
        Integer num = update(d, whereParam, null);
        if (num == null || num <= 0) {
            result.setErrCode(ErrorCodeEnum.SERVICE_IS_ERROR.getCode());
            result.setErrMessage(ErrorCodeEnum.SERVICE_IS_ERROR.getMessage());
            return result;
        }
        result.setContent(true);
        result.setSuccess(true);
        return result;
    }

    /**
     * 根据指定条件更新,支持批量更新
     *
     * @param model
     * @param param
     * @return
     */
    public Result<Integer> batchUpdate(M model, P param) {
        Result<Integer> result = new Result<>();
        result.setSuccess(false);
        if (model == null || param == null) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_NULL.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_NULL.getMessage());
            return result;
        }
        final D d = getMapper().toDO(model);
        if (d == null) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_INVALID.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_INVALID.getMessage());
            return result;
        }
        Integer num = update(d, param.toParamMap(), param.toLikeParamMap());
        if (num == null) {
            result.setErrCode(ErrorCodeEnum.SERVICE_IS_ERROR.getCode());
            result.setErrMessage(ErrorCodeEnum.SERVICE_IS_ERROR.getMessage());
            return result;
        }
        result.setContent(num);
        result.setSuccess(true);
        return result;
    }

    /**
     * 根据主键id查询
     *
     * @param id
     * @return
     */
    public Result<M> find(Long id) {
        Result<M> result = new Result<>();
        result.setSuccess(false);
        if (id == null) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_NULL.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_NULL.getMessage());
            return result;
        }
        IbatisQueryParam p = new IbatisQueryParam();
        p.addParam(DEFAULT_ID, id);
        List<D> dList = getDao().query(p.toParamMap());
        if (CollectionUtil.isEmpty(dList)) {
            result.setErrCode(ErrorCodeEnum.RESULT_IS_NULL.getCode());
            result.setErrMessage(ErrorCodeEnum.RESULT_IS_NULL.getMessage());
            return result;
        }
        M m = getMapper().toModel(dList.get(0));
        result.setSuccess(true);
        result.setContent(m);
        return result;
    }

    /**
     * 查询记录,支持分页
     *
     * @param param
     * @return
     * @throws Exception
     */
    public Result<PageList<M>> query(P param) {
        Result<PageList<M>> result = new Result<>();
        result.setSuccess(false);
        if (param == null) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_NULL.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_NULL.getMessage());
            return result;
        }
        Map<String, Object> equalParam = param.toParamMap();
        Map<String, Object> likeParam = param.toLikeParamMap();
        if (CollectionUtil.isEmpty(equalParam) && CollectionUtil.isEmpty(likeParam)) {
            result.setErrCode(ErrorCodeEnum.PARAM_IS_NULL.getCode());
            result.setErrMessage(ErrorCodeEnum.PARAM_IS_NULL.getMessage());
            return result;
        }
        IbatisQueryParam p = new IbatisQueryParam();
        if (CollectionUtil.isNotEmpty(equalParam)) {
            p.setEqualParam(equalParam);
        }
        if (CollectionUtil.isNotEmpty(likeParam)) {
            p.setLikeParam(likeParam);
        }
        String order = param.getOrder();
        String orderBy = param.getOrderBy();
        if (StringUtil.isBlank(order)) {
            order = DEFAULT_ORDER;
        }
        if (StringUtil.isBlank(orderBy)) {
            orderBy = DEFAULT_ORDER_BY;
        }
        p.setOrder(order);
        p.setOrderBy(orderBy);
        if (param.isPaged()) {
            p.setPage(param.getPage());
            p.setPageSize(param.getPageSize());
        }
        final PageList<M> pageList = new PageList<>();
        try {
            Map<String, Object> paramMap = p.toParamMap();
            final List<D> doList = getDao().query(paramMap);
            if (param.isPaged()) {
                final Paginator paginator = new Paginator(param.getPageSize());
                paginator.setPage(param.getPage());
                pageList.setPaginator(paginator);
                if (param.isCountNeeded()) {
                    Integer count = 0;
                    // 如果返回结果个数为0,则无需count总结果个数,减少count次数
                    if (doList == null || doList.size() == 0) {
                        count = 0;
                    } else {
                        count = getDao().count(paramMap);
                    }
                    paginator.setItems(count);
                }
            }

            final List<M> models = new ArrayList<>();

            if (CollectionUtil.isNotEmpty(doList)) {
                for (D d : doList) {
                    final M model = getMapper().toModel(d);
                    if (model != null) {
                        models.add(model);
                    }
                }
            }
            pageList.setDataList(models);
        } catch (Exception e) {
            throw new RuntimeException("failed to query models by param: " + param, e);
        }
        result.setSuccess(true);
        result.setContent(pageList.getDataList().size() != 0 ? pageList : null);
        return result;
    }

    /**
     * 统计记录数
     *
     * @param param
     * @return
     */
    public Integer count(P param) {
        if (param == null) {
            return 0;
        }
        Map<String, Object> equalParam = param.toParamMap();
        Map<String, Object> likeParam = param.toLikeParamMap();
        if (CollectionUtil.isEmpty(equalParam) && CollectionUtil.isEmpty(likeParam)) {
            return 0;
        }
        IbatisQueryParam p = new IbatisQueryParam();
        if (CollectionUtil.isNotEmpty(equalParam)) {
            p.setEqualParam(equalParam);
        }
        if (CollectionUtil.isNotEmpty(likeParam)) {
            p.setLikeParam(likeParam);
        }
        Integer num = getDao().count(p.toParamMap());
        return num;
    }

    /**
     * 物理删除,如果要逻辑删除调用batchUpdate或update方法
     *
     * @param param
     * @return
     */
    public Integer delete(P param) {
        if (param == null) {
            return 0;
        }
        Map<String, Object> equalParam = param.toParamMap();
        Map<String, Object> likeParam = param.toLikeParamMap();
        if (CollectionUtil.isEmpty(equalParam) && CollectionUtil.isEmpty(likeParam)) {
            return 0;
        }
        IbatisQueryParam p = new IbatisQueryParam();
        if (CollectionUtil.isNotEmpty(equalParam)) {
            p.setEqualParam(equalParam);
        }
        if (CollectionUtil.isNotEmpty(likeParam)) {
            p.setLikeParam(likeParam);
        }
        Integer num = getDao().delete(p.toParamMap());
        return num;
    }

    public Integer update(D d, Map<String, Object> whereParam, Map<String, Object> likeParam) {
        if (d == null || (CollectionUtil.isEmpty(whereParam) && CollectionUtil.isEmpty(likeParam))) {
            return 0;
        }
        IbatisQueryParam param = new IbatisQueryParam();
        if (whereParam != null) {
            param.setEqualParam(whereParam);
        }
        if (likeParam != null) {
            param.setLikeParam(likeParam);
        }
        param.setSetParam(getObjectProperties(d));
        Integer num = update(param);
        return num;
    }

    public Integer update(IbatisQueryParam param) {
        if (param == null) {
            return 0;
        }
        if (CollectionUtil.isEmpty(param.getIdList()) && CollectionUtil.isEmpty(param.getEqualParam())
            && CollectionUtil.isEmpty(param.getLikeParam())) {
            return 0;
        }
        Integer num = getDao().update(param.toParamMap());
        return num;
    }

    protected static Map<String, Object> getObjectProperties(Object obj) {
        return (JSONObject) (JSON.toJSON(obj));
    }

    public abstract AbstractMapper<M, D> getMapper();

    public abstract AbstractDAO<D> getDao();

}
