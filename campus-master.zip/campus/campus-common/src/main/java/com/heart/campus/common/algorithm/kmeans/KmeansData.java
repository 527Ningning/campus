package com.heart.campus.common.algorithm.kmeans;

/**
 *
 * @author: qiuchao.qc
 * @date: 2017/10/9
 */
public class KmeansData {
    /**
     * 原始矩阵
     */
    private double[][] data;

    /**
     * 聚类中心
     */
    private double[][] centers;

    /**
     * 矩阵行
     */
    private int row;

    /**
     * 矩阵列
     */
    private int column;

    public KmeansData(double[][] data, int row, int column) {
        this.data = data;
        this.row = row;
        this.column = column;
    }

    public double[][] getData() {
        return data;
    }

    public void setData(double[][] data) {
        this.data = data;
    }

    public double[][] getCenters() {
        return centers;
    }

    public void setCenters(double[][] centers) {
        this.centers = centers;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }
}
