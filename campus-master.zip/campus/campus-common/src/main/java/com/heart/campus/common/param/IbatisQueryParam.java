package com.heart.campus.common.param;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.heart.campus.common.util.CollectionUtil;
import com.heart.campus.common.util.StringUtil;

/**
 * Ibatis查询参数
 *
 * @author: heart
 * @date: 2017/10/21
 */
public class IbatisQueryParam extends AbstractParam {

    private static final long   serialVersionUID = 8185255106184425721L;

    /**
     * 支持根据id列表批量查询的参数
     */
    private List<Long>          idList           = new ArrayList<Long>();

    /**
     * 全匹配查询
     */
    private Map<String, Object> equalParam       = new HashMap<String, Object>();

    /**
     * 模糊匹配查询
     */
    private Map<String, Object> likeParam        = new HashMap<String, Object>();

    /**
     * update时更新的值
     */
    private Map<String, Object> setParam         = new HashMap<String, Object>();

    /**
     * 排序列,如ID
     */
    private String              orderBy;

    /**
     * 排序列,如ID
     */
    private String              order            = "DESC";

    @Override
    protected void addParams(Map<String, Object> existParam) {
        if (!CollectionUtil.isEmpty(idList)) {
            existParam.put("idList", idList);
        }

        if (orderBy != null) {
            existParam.put("orderBy", orderBy.toUpperCase());
        }

        if (order != null) {
            existParam.put("order", order.toUpperCase());
        }

        for (String key : equalParam.keySet()) {
            existParam.put("equalParam_" + key, equalParam.get(key));
        }

        for (String key : likeParam.keySet()) {
            existParam.put("likeParam_" + key, likeParam.get(key));
        }

        for (String key : setParam.keySet()) {
            existParam.put("setParam_" + key, setParam.get(key));
        }
    }

    public List<Long> getIdList() {
        return idList;
    }

    public void setIdList(List<Long> idList) {
        this.idList = idList;
    }

    public IbatisQueryParam addParam(String key, Object value) {
        equalParam.put(key, value);
        return this;
    }

    public IbatisQueryParam addParamIfNotNull(String key, Object value) {
        if (value == null) {
            return this;
        }
        equalParam.put(key, value);
        return this;
    }

    public IbatisQueryParam addParamIfNotEmpty(String key, String value) {
        if (StringUtil.isEmpty(value)) {
            return this;
        }
        equalParam.put(key, value);
        return this;
    }

    public IbatisQueryParam addParamIfNotEmpty(String key, Collection<?> value) {
        if (CollectionUtil.isEmpty(value)) {
            return this;
        }
        equalParam.put(key, value);
        return this;
    }

    public IbatisQueryParam addLikeParam(String key, String value) {
        // 不加入空值
        if (!StringUtil.isEmpty(value)) {
            likeParam.put(key, value);
        }
        return this;
    }

    public IbatisQueryParam addLikeParamIfNotEmpty(String key, List<String> valueList) {
        if (CollectionUtil.isEmpty(valueList)) {
            return this;
        }
        likeParam.put(key, valueList);
        return this;
    }

    public IbatisQueryParam addSetParam(String key, Object value) {
        setParam.put(key, value);
        return this;
    }

    public IbatisQueryParam removeEqualParam(String key) {
        equalParam.remove(key);
        return this;
    }

    public IbatisQueryParam removeLikeParam(String key) {
        likeParam.remove(key);
        return this;
    }

    public IbatisQueryParam removeSetParam(String key) {
        setParam.remove(key);
        return this;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public Map<String, Object> getEqualParam() {
        return equalParam;
    }

    public void setEqualParam(Map<String, Object> equalParam) {
        this.equalParam = equalParam;
    }

    public Map<String, Object> getLikeParam() {
        return likeParam;
    }

    public void setLikeParam(Map<String, Object> likeParam) {
        this.likeParam = likeParam;
    }

    public Map<String, Object> getSetParam() {
        return setParam;
    }

    public void setSetParam(Map<String, Object> setParam) {
        this.setParam = setParam;
    }
}
