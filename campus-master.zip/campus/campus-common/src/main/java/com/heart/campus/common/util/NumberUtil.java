package com.heart.campus.common.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 判断输入参数是否为数字
 *
 * @author: yuwu
 * @date: 2017/11/27
 */

public class NumberUtil {

    public static Pattern pattern = Pattern.compile("[0-9]*");

    /***
     * 判断参数是否全是数字(非数字，小数均无法通过，id不大可能是小数 所有这种情况要考虑)
     * 
     * @param str 字符串
     * @return 数字字符串返回t返rue.否则回false
     */
    public static boolean isNumeric(String str) {
        Matcher matcher = NumberUtil.pattern.matcher(str);
        boolean b = matcher.matches();
        return b;
    }

    /***
     * @function：字符串转为数字。 @param ：字符串
     * @return ：int @describe：如果转换成功，返回一个整型的数字；如果转换失败，返回-1.
     */
    public static int stringToInt(String parameter) {
        int i = -1;
        if (parameter != null && !"".equals(parameter)) {
            boolean b = NumberUtil.isNumeric(parameter);
            if (b == true) {
                i = Integer.parseInt(parameter);
            }
        }
        return i;
    }

}
