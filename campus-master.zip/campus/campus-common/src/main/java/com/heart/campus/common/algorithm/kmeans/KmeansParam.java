package com.heart.campus.common.algorithm.kmeans;

/**
 * 控制k_means迭代的参数
 *
 * @author: qiuchao.qc
 * @date: 2017/10/9
 */
public class KmeansParam {

    /**
     * 系统默认最大聚类K值
     */
    public static final int K = 24;
    /**
     * 系统默认算法最大迭代次数
     */
    public static final int MAX_INTERATION = 4000;
    /**
     * 停止迭代时的精确度
     */
    public static final double MIN_CRITERIA = 0.1;
    /**
     * 允许最小中心欧式距离
     */
    public static final double MIN_EUCLIDEAN_DISTANCE = 0.6;

    // 非final转换
    public static double criteria = MIN_CRITERIA;
    public static int attempts = MAX_INTERATION;
    public static double min_euclideanDistance = MIN_EUCLIDEAN_DISTANCE;

}
