package com.heart.campus.common.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * MD5加密工具类
 *
 * @author: heart
 * @date: 2017/10/24
 */
public class Md5Util {

    private Md5Util(){
    }

    public static String md5(String text) {
        return md5(text, false);
    }

    private static byte[] md5Bytes(String text) {
        if (null != text && !"".equals(text)) {
            MessageDigest msgDigest = null;

            try {
                msgDigest = MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException var3) {
                throw new IllegalStateException("System doesn\'t support MD5 algorithm.");
            }

            msgDigest.update(text.getBytes());
            byte[] bytes = msgDigest.digest();
            return bytes;
        } else {
            return new byte[0];
        }
    }

    private static String md5(String text, boolean isReturnRaw) {
        if (null != text && !"".equals(text)) {
            byte[] bytes = md5Bytes(text);
            if (isReturnRaw) {
                return new String(bytes);
            } else {
                String md5Str = new String();

                for (int i = 0; i < bytes.length; ++i) {
                    byte tb = bytes[i];
                    char tmpChar = (char) (tb >>> 4 & 15);
                    char high;
                    if (tmpChar >= 10) {
                        high = (char) (97 + tmpChar - 10);
                    } else {
                        high = (char) (48 + tmpChar);
                    }

                    md5Str = md5Str + high;
                    tmpChar = (char) (tb & 15);
                    char low;
                    if (tmpChar >= 10) {
                        low = (char) (97 + tmpChar - 10);
                    } else {
                        low = (char) (48 + tmpChar);
                    }

                    md5Str = md5Str + low;
                }

                return md5Str;
            }
        } else {
            return text;
        }
    }
}
