package com.heart.campus.common.enums;

/**
 * 黑白名单枚举类
 * 
 * @author: yuwu
 * @date: 2017/11/28
 */
public enum CommonBlackWhiteEnum {

    /**
     * 白名单,即没有被拉黑
     */
    WHITE(0),
    /**
     * 黑名单成员,不允许登录
     */
    BLACK(1);

    int value;

    CommonBlackWhiteEnum(int value){
        this.value = value;
    }

    public int getValue() {
        return value;
    }
}
