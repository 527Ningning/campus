package com.heart.campus.common.algorithm.kmeans;

import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.util.ParamsVerifier;

import java.text.DecimalFormat;
import java.util.*;

/**
 * K-Means聚类算法
 *
 * @author: qiuchao.qc
 * @date: 2017/10/9
 */
public class KmeansHandler {
    private DecimalFormat numberFormat = new DecimalFormat("#####.00");
    private KmeansData kmeansData = null;
    // feature,样本名称和索引映射
    private Map<String, Integer> nameMap = new HashMap<>();
    private Map<Integer, String> indexMap = new HashMap<>();
    private KmeansModel kmeansModel = new KmeansModel();

    /**
     * 文件到矩阵的映射,更改数据源时修改此方法
     *
     * @return
     * @throws Exception
     */
    public double[][] itemToMatrix(List<DataItem> dataItems) {
        if (ParamsVerifier.isEmpty(dataItems)) {
            return null;
        }
        int col = dataItems.get(0).getItems().size();

        double[][] matrixData = new double[dataItems.size()][col];

        for (int j = 0; j < dataItems.size(); j++) {
            nameMap.put(dataItems.get(j).getName(), j);
            indexMap.put(j, dataItems.get(j).getName());
            for (int i = 0; i < col; i++) {
                matrixData[j][i] = Double.parseDouble(String.valueOf(dataItems.get(j).getItems().get(i)));
            }
        }
        kmeansModel.setIdentifier(nameMap);
        kmeansModel.setIden0(indexMap);
        return matrixData;
    }


    /**
     * 清零操作
     *
     * @param matrix
     * @param highDim
     * @param lowDim
     */
    private void setDouble2Zero(double[][] matrix, int highDim, int lowDim) {
        for (int i = 0; i < highDim; i++) {
            for (int j = 0; j < lowDim; j++) {
                matrix[i][j] = 0;
            }
        }
    }

    /**
     * 聚类中心拷贝
     *
     * @param dests
     * @param sources
     * @param highDim
     * @param lowDim
     */
    private void copyCenters(double[][] dests, double[][] sources, int highDim, int lowDim) {
        for (int i = 0; i < highDim; i++) {
            for (int j = 0; j < lowDim; j++) {
                dests[i][j] = sources[i][j];
            }
        }
    }

    /**
     * 更新聚类中心
     * 计算每个聚类的物理中心（均值）
     *
     * @param k
     * @param data
     */
    private void updateCenters(int k, KmeansData data) {
        double[][] centers = data.getCenters();
        setDouble2Zero(centers, k, data.getColumn());
        int[] labels = kmeansModel.getLabels();
        int[] centerCounts = kmeansModel.getCenterCounts();
        for (int i = 0; i < data.getColumn(); i++) {
            for (int j = 0; j < data.getRow(); j++) {
                centers[labels[j]][i] += data.getData()[j][i];
            }
        }
        for (int i = 0; i < k; i++) {
            for (int j = 0; j < data.getColumn(); j++) {
                centers[i][j] = centers[i][j] / centerCounts[i];
            }
        }
    }

    /**
     * 计算欧氏距离
     *
     * @param pointA
     * @param pointB
     * @param dim
     * @return
     */
    public double euclidDist(double[] pointA, double[] pointB, int dim) {
        double length = 0;
        for (int i = 0; i < dim; i++) {
            double tmp = pointA[i] - pointB[i];
            tmp = tmp * tmp;
            length += tmp;
        }
        return Math.sqrt(length);
    }

    /**
     * 样本训练,需要人为设定k值(聚类中心数目)
     *
     * @param k
     * @return
     * @throws Exception
     */
    public KmeansModel execute(List<DataItem> dataItems, int k) throws Exception {
        double[][] matrix = itemToMatrix(dataItems);
        if (matrix == null) {
            return null;
        }
        kmeansData = new KmeansData(matrix, matrix.length, matrix[0].length);
        return execute(k, new KmeansParam());
    }

    /**
     * 样本训练(系统默认最优聚类中心数目)
     *
     * @return
     * @throws Exception
     */
    public KmeansModel execute(List<DataItem> dataItems) {
        double[][] matrix = itemToMatrix(dataItems);
        if (matrix == null) {
            return null;
        }
        kmeansData = new KmeansData(matrix, matrix.length, matrix[0].length);
        return execute(new KmeansParam());
    }

    public KmeansModel execute(KmeansParam param) {
        int k = KmeansParam.K;
        double[][] data = kmeansData.getData();
        int row = kmeansData.getRow();
        int col = kmeansData.getColumn();
        // 1：数据归一化处理
        normalize(data, row, col);
        // 2：计算第一个样本与其他样本的所有欧氏距离
        double euclideanDistance = calEuclideanDistance(param, data, row, col);

        // 3：计算聚类中心
        int centerIndexes[] = new int[k];// 收集聚类中心索引的数组
        int countCenter = 0;// 动态表示中心的数目
        int count = 0;// 计数器
        centerIndexes[0] = 0;
        countCenter++;
        countCenter = getCountCenter(data, row, col, euclideanDistance, centerIndexes, countCenter, count);

        double[][] centers = new double[countCenter][col]; // 聚类中心
        kmeansData.setCenters(centers);
        int[] centerCounts = new int[countCenter]; // 聚类中心的样本个数
        kmeansModel.setCenterCounts(centerCounts);
        Arrays.fill(centerCounts, 0);
        int[] labels = new int[row]; // 样本的类别
        kmeansModel.setLabels(labels);
        double[][] oldCenters = new double[countCenter][col]; // 存储旧的聚类中心
        setClusterCenter(data, col, centerIndexes, countCenter, centers);

        // 4：初始聚类
        cluster(countCenter, centers, centerCounts, labels);
        updateCenters(countCenter, kmeansData);
        copyCenters(oldCenters, centers, countCenter, kmeansData.getColumn());

        // 5：迭代处理
        int maxAttempts = param.attempts > 0 ? param.attempts : KmeansParam.MAX_INTERATION;
        int attempts = 1;
        double criteria = param.criteria > 0 ? param.criteria : KmeansParam.MIN_CRITERIA;
        double criteriaBreakCondition = 0;
        boolean[] flags = new boolean[k]; // 用来表示聚类中心是否发生变化
        Iterate iterate = new Iterate(countCenter, centers, centerCounts, labels, oldCenters, maxAttempts, attempts,
                criteria, criteriaBreakCondition,
                flags).invoke();
        criteriaBreakCondition = iterate.getCriteriaBreakCondition();
        attempts = iterate.getAttempts();

        // 6：存储聚类结果
        KmeansModel result = storeClusterInfo(criteriaBreakCondition, countCenter, attempts, param, centerCounts);
        return result;
    }

    private int getCountCenter(double[][] data, int row, int col, double euclideanDistance, int[] centerIndexes, int countCenter, int count) {
        for (int i = 1; i < row; i++) {
            // 计算当前点与每一个聚类中心的距离,如果大于阈值，认为是新的聚类中心
            for (int j = 0; j < countCenter; j++) {
                if (euclidDist(data[i], data[centerIndexes[j]], col) > euclideanDistance) {
                    count++;
                }
            }
            if (count == countCenter) {
                centerIndexes[countCenter++] = i;
            }
            count = 0;
        }
        return countCenter;
    }

    private void setClusterCenter(double[][] data, int col, int[] centerIndexes, int countCenter, double[][] centers) {
        // 给聚类中心赋值
        for (int i = 0; i < countCenter; i++) {
            int m = centerIndexes[i];
            for (int j = 0; j < col; j++) {
                centers[i][j] = data[m][j];
            }
        }

        // 给最初始的聚类中心赋值
        kmeansModel.setOriginalCenters(new double[countCenter][col]);
        for (int i = 0; i < countCenter; i++) {
            for (int j = 0; j < col; j++) {
                kmeansModel.getOriginalCenters()[i][j] = centers[i][j];
            }
        }
    }

    private double calEuclideanDistance(KmeansParam param, double[][] data, int row, int col) {
        List<Double> distList = calDistListForFisrt(data, row, col);
        param.min_euclideanDistance = Double.valueOf(numberFormat.format((Collections.max(distList) + Collections.min(distList)) / 2));
        return param.min_euclideanDistance > 0 ? param.min_euclideanDistance
                : KmeansParam.MIN_EUCLIDEAN_DISTANCE;
    }

    private List<Double> calDistListForFisrt(double[][] data, int row, int col) {
        List<Double> distList = new ArrayList<>();
        for (int i = 1; i < row; i++) {
            distList.add(euclidDist(data[0], data[i], col));
        }
        return distList;
    }

    // 聚类方法
    private void cluster(int countCenter, double[][] centers, int[] centerCounts, int[] labels) {
        for (int i = 0; i < kmeansData.getRow(); i++) {
            double minDist = euclidDist(kmeansData.getData()[i], centers[0], kmeansData.getColumn());
            int label = 0;
            for (int j = 1; j < countCenter; j++) {
                double tempDist = euclidDist(kmeansData.getData()[i], centers[j], kmeansData.getColumn());
                if (tempDist < minDist) {
                    minDist = tempDist;
                    label = j;
                }
            }
            labels[i] = label;
            centerCounts[label]++;
        }
    }

    private KmeansModel execute(int k, KmeansParam param) {
        double[][] data = kmeansData.getData();
        int row = kmeansData.getRow();
        int col = kmeansData.getColumn();
        // 首先进行数据归一化处理
        normalize(data, row, col);

        // 计算距离向量
        double euclideanDistance = calEuclideanDistance(param, kmeansData.getData(), kmeansData.getRow(), kmeansData.getColumn());

        double[][] centers = new double[k][kmeansData.getColumn()];
        int[] centerCounts = new int[k];
        Arrays.fill(centerCounts, 0);
        int[] labels = new int[kmeansData.getRow()];
        double[][] oldCenters = new double[k][kmeansData.getColumn()];
        kmeansData.setCenters(centers);
        kmeansModel.setCenterCounts(centerCounts);
        kmeansModel.setLabels(labels);

        int centerIndexes[] = new int[k];
        int countCenter = 0;
        int count = 0;
        centerIndexes[0] = 0;
        countCenter++;
        for (int i = 1; i < kmeansData.getRow(); i++) {
            for (int j = 0; j < countCenter; j++) {
                if (euclidDist(kmeansData.getData()[i], kmeansData.getData()[centerIndexes[j]], kmeansData.getColumn())
                        > euclideanDistance) {
                    count++;
                }
            }
            if (count == countCenter) {
                centerIndexes[countCenter++] = i;
            }
            count = 0;

            if (countCenter == k) {
                break;
            }

            if (countCenter < k && i == kmeansData.getRow() - 1) {
                k = countCenter;
                break;
            }
        }

        setClusterCenter(kmeansData.getData(), kmeansData.getColumn(), centerIndexes, k, centers);

        cluster(k, centers, centerCounts, labels);
        updateCenters(k, kmeansData);
        copyCenters(oldCenters, centers, k, kmeansData.getColumn());

        int maxAttempts = param.attempts > 0 ? param.attempts : KmeansParam.MAX_INTERATION;
        int attempts = 1;
        double criteria = param.criteria > 0 ? param.criteria : KmeansParam.MIN_CRITERIA;
        double criteriaBreakCondition = 0;
        boolean[] flags = new boolean[k];

        Iterate iterate = new Iterate(countCenter, centers, centerCounts, labels, oldCenters, maxAttempts, attempts,
                criteria, criteriaBreakCondition,
                flags).invoke();
        criteriaBreakCondition = iterate.getCriteriaBreakCondition();
        attempts = iterate.getAttempts();

        KmeansModel resultModel = storeClusterInfo(criteriaBreakCondition, k, attempts, param, centerCounts);
        return resultModel;
    }

    /**
     * 把聚类结果存储到Model中
     *
     * @param criteriaBreakCondition
     * @param k
     * @param attempts
     * @param param
     * @param centerCounts
     * @return
     */
    private KmeansModel storeClusterInfo(double criteriaBreakCondition, int k, int attempts, KmeansParam param,
                                         int[] centerCounts) {
        kmeansModel.setData(kmeansData);
        kmeansModel.setK(k);
        int perm[] = new int[kmeansData.getRow()];
        kmeansModel.setPerm(perm);
        int start[] = new int[k];
        kmeansModel.setStart(start);
        group_class(perm, start, k, kmeansData);
        return kmeansModel;
    }

    /**
     * 把聚类样本按所属类别连续存储
     *
     * @param perm
     * @param start
     * @param k
     * @param data
     */
    private void group_class(int perm[], int start[], int k, KmeansData data) {

        start[0] = 0;
        for (int i = 1; i < k; i++) {
            start[i] = start[i - 1] + kmeansModel.getCenterCounts()[i - 1];
        }

        for (int i = 0; i < data.getRow(); i++) {
            perm[start[kmeansModel.getLabels()[i]]++] = i;
        }

        start[0] = 0;
        for (int i = 1; i < k; i++) {
            start[i] = start[i - 1] + kmeansModel.getCenterCounts()[i - 1];
        }
    }

    /**
     * 数据归一化处理
     */
    private void normalize(double[][] data, int row, int col) {
        Map<Integer, Double[]> minAndMax = new HashMap<>();
        for (int i = 0; i < kmeansData.getColumn(); i++) {
            Double[] numArr = new Double[2];
            double min = data[kmeansData.getRow() - 1][i];
            double max = data[0][i];
            for (int j = 0; j < row; j++) {
                if (data[j][i] > max) {
                    max = data[j][i];
                }
                if (data[j][i] < min) {
                    min = data[j][i];
                }
            }
            numArr[0] = min;
            numArr[1] = max;
            minAndMax.put(i, numArr);
        }
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                double min = minAndMax.get(j)[0];
                double max = minAndMax.get(j)[1];
                // 分母
                double den = max - min;
                if (den == 0) {
                    data[i][j] = 1.0;
                } else {
                    data[i][j] = (data[i][j] - min) / (max - min);
                }
                data[i][j] = Double.valueOf(numberFormat.format(data[i][j]));
            }
        }
    }

    /**
     * 迭代实现类
     */
    private class Iterate {
        private int countCenter;
        private double[][] centers;
        private int[] centerCounts;
        private int[] labels;
        private double[][] oldCenters;
        private int maxAttempts;
        private int attempts;
        private double criteria;
        private double criteriaBreakCondition;
        private boolean[] flags;

        public Iterate(int countCenter, double[][] centers, int[] centerCounts, int[] labels, double[][] oldCenters,
                       int maxAttempts, int attempts, double criteria, double criteriaBreakCondition,
                       boolean... flags) {
            this.countCenter = countCenter;
            this.centers = centers;
            this.centerCounts = centerCounts;
            this.labels = labels;
            this.oldCenters = oldCenters;
            this.maxAttempts = maxAttempts;
            this.attempts = attempts;
            this.criteria = criteria;
            this.criteriaBreakCondition = criteriaBreakCondition;
            this.flags = flags;
        }

        public int getAttempts() {
            return attempts;
        }

        public double getCriteriaBreakCondition() {
            return criteriaBreakCondition;
        }

        public Iterate invoke() {
            // 迭代
            while (attempts < maxAttempts) { // 迭代次数不超过最大值，最大中心改变量不超过阈值
                for (int i = 0; i < countCenter; i++) { //  初始化中心点"是否被修改过"标记
                    flags[i] = false;
                }
                for (int i = 0; i < kmeansData.getRow(); i++) {
                    double minDist = euclidDist(kmeansData.getData()[i], centers[0], kmeansData.getColumn());
                    int label = 0;
                    for (int j = 1; j < countCenter; j++) {
                        double tempDist = euclidDist(kmeansData.getData()[i], centers[j], kmeansData.getColumn());
                        if (tempDist < minDist) {
                            minDist = tempDist;
                            label = j;
                        }
                    }
                    if (label != labels[i]) { // 如果当前点被聚类到新的类别则做更新
                        int oldLabel = labels[i];
                        labels[i] = label;
                        centerCounts[oldLabel]--;
                        centerCounts[label]++;
                        flags[oldLabel] = true;
                        flags[label] = true;
                    }
                }
                updateCenters(countCenter, kmeansData);
                attempts++;

                // 计算被修改过的中心点最大修改量是否超过阈值
                double maxDist = 0;
                for (int i = 0; i < countCenter; i++) {
                    if (flags[i]) {
                        double tempDist = euclidDist(centers[i], oldCenters[i], kmeansData.getColumn());
                        if (maxDist < tempDist) {
                            maxDist = tempDist;
                        }
                        for (int j = 0; j < kmeansData.getColumn(); j++) { // 更新oldCenter
                            oldCenters[i][j] = centers[i][j];
                            oldCenters[i][j] = Double.valueOf(numberFormat.format(oldCenters[i][j]));
                        }
                    }
                }
                if (maxDist < criteria) {
                    criteriaBreakCondition = maxDist;
                    break;
                }
            }
            return this;
        }
    }
}
