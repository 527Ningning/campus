package com.heart.campus.common.param;

import java.io.Serializable;

/**
 * <strong>描述：</strong>支持分页查询的参数<br>
 * <strong>功能：</strong>可支持分页查询<br>
 * <strong>注意事项：</strong><br>
 * <ul>
 * <li>pageSize默认为20</li>
 * </ul>
 *
 * @author: heart
 * @date: 2017/10/21
 */
public class PagableParam implements Serializable {

    private static final long serialVersionUID = -2129373759424589030L;

    /**
     * page页码数
     */
    private Integer           page;
    /**
     * 分页大小
     */
    private Integer           pageSize         = 20;
    /**
     * 是否需要统计
     */
    private boolean           countNeeded      = false;

    /** 要查询数据的启始行 */
    public Integer getStartNum() {
        if (page == null || page <= 0) {
            page = 1;
        }
        if (pageSize == null || pageSize <= 0) {
            return 0;
        }
        return (page - 1) * pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    /** 获取页码 */
    public Integer getPage() {
        if (page == null) {
            return 0;
        }
        return page;
    }

    public void setPage(Integer page) {
        this.page = page;
    }

    /** 获取分页大小 */
    public Integer getPageSize() {
        if (pageSize == null) {
            return 20;
        }
        return pageSize;
    }

    /** 是否按指定分页查询 */
    public boolean isPaged() {
        return pageSize != null;
    }

    /** 是否需要统计总数 */
    public boolean isCountNeeded() {
        return countNeeded;
    }

    /**
     * 当需要统计功能的时候用该方法
     *
     * @param countNeeded
     * @param pageSize
     */
    public void setCountNeeded(boolean countNeeded, final Integer pageSize) {
        this.countNeeded = countNeeded;
        if (pageSize != null) {
            this.pageSize = pageSize;
        }
    }

    public void setCountNeeded(boolean countNeeded) {
        this.countNeeded = countNeeded;
    }
}
