package com.heart.campus.common.util;

import java.util.*;

/**
 * 多参数校验器
 *
 * @author: heart
 * @date: 2018/01/16
 */
public class ParamsVerifier {

    /**
     * 判断参数中是否有NULL参数
     *
     * @param params
     * @return
     */
    public static boolean isNull(Object... params) {
        for (Object object : params) {
            if (object == null) {
                return true;
            }
        }
        return false;
    }

    public static boolean isNotNull(Object... params) {
        return !isNull(params);
    }

    /**
     * 判断参数中是否有空参数
     *
     * @param params
     * @return
     */
    public static boolean isEmpty(Object... params) {
        if (isNull(params)) {
            return true;
        }
        for (Object object : params) {
            if (object instanceof String) {
                String tmp = (String) object;
                if (tmp.isEmpty()) {
                    return true;
                }
            }
            if (object instanceof Collection) {
                Collection tmp = (Collection) object;
                if (tmp.isEmpty()) {
                    return true;
                }
            }
            if (object instanceof Map) {
                Map tmp = (Map) object;
                if (tmp.isEmpty()) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isNotEmpty(Object... params) {
        return !isEmpty(params);
    }

}
