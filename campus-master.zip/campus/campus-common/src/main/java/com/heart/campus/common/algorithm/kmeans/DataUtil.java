package com.heart.campus.common.algorithm.kmeans;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据源处理工具类
 *
 * @author: qiuchao.qc
 * @date: 2017/10/9
 */
public class DataUtil {
    /**
     * 从文件读取源数据
     * @param path
     * @return
     * @throws Exception
     */
    public static List<String> readDateFromFile(String path) throws Exception {
        List<String> contents = new ArrayList<>();

        FileInputStream file;
        InputStreamReader inputFileReader;
        BufferedReader reader = null;
        String str;
        try {
            file = new FileInputStream(path);
            inputFileReader = new InputStreamReader(file, "utf-8");
            reader = new BufferedReader(inputFileReader);
            // 一次读入一行，直到读入null为文件结束
            while ((str = reader.readLine()) != null) {
                contents.add(str);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
        return contents;
    }
}
