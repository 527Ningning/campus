package com.heart.campus.common.service;

import java.util.List;

import com.heart.campus.common.domain.AbstractModel;
import com.heart.campus.common.page.PageList;
import com.heart.campus.common.param.AbstractQueryParam;
import com.heart.campus.common.result.Result;

/**
 * 抽象服务类
 *
 * @author: heart
 * @date: 2017/10/23
 */
public interface AbstractService<M extends AbstractModel, P extends AbstractQueryParam> {

    /**
     * 插入新数据
     * 
     * @param model
     * @return
     */
    Result<Long> insert(M model);

    /**
     * 批量插入
     * 
     * @param models
     * @return
     */
    Result<Integer> batchInsert(List<M> models);

    /**
     * 更新数据
     * 
     * @param model
     * @return
     */
    Result<Boolean> update(M model);

    /**
     * 根据主键查找数据
     * 
     * @param id
     * @return
     */
    Result<M> find(Long id);

    /**
     * 根据参数查询数据
     * 
     * @param param
     * @return
     */
    Result<PageList<M>> query(P param);

    /**
     * 根据参数删除
     * 
     * @param param
     * @return
     */
    Integer delete(P param);

    /**
     * 根据参数计数
     * 
     * @param param
     * @return
     */
    Integer count(P param);

}
