package com.heart.campus.common.dao;

import java.util.List;
import java.util.Map;

import com.heart.campus.common.domain.AbstractDO;

/**
 * 抽象DAO接口
 *
 * @author: heart
 * @date: 2017/10/21
 */
public interface AbstractDAO<D extends AbstractDO> {

    /**
     * 创建一条记录
     *
     * @param theDO 数据对象
     * @return 成功插入的数据主健ID
     */
    Integer insert(D theDO);

    /**
     * 批量删除记录
     *
     * @param param
     * @return 成功删除的数据条数
     */
    Integer delete(Map<String, Object> param);

    /**
     * 批量修改记录
     *
     * @param param
     * @return 更新成功的记录数
     */
    Integer update(Map<String, Object> param);

    /**
     * 批量查询
     *
     * @param param
     * @return
     */
    List<D> query(Map<String, Object> param);

    /**
     * 根据查询参数统计数据量
     *
     * @param param 查询参数对象
     * @return
     */
    Integer count(Map<String, Object> param);

    /**
     * 批量创建记录
     *
     * @param theDOs
     * @return
     */
    Integer batchInsert(List<D> theDOs);
}
