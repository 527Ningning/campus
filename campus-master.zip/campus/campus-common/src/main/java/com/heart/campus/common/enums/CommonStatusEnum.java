package com.heart.campus.common.enums;

/**
 * 通用状态枚举
 *
 * @author: heart
 * @date: 2017/11/12
 */
public enum  CommonStatusEnum {
    /**
     * 正常
     */
    NORMAL(0),

    /**
     * 删除
     */
    DELETE(1);

    Integer value;

    CommonStatusEnum(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }
}
