package com.heart.campus.common.param;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.heart.campus.common.util.StringUtil;

/**
 * <strong>描述：</strong>抽象查询参数<br>
 * <strong>功能：</strong>可支持分页<br>
 * <strong>使用场景：</strong>需要分页的功能，其参数均需继承该类<br>
 *
 * @author: heart
 * @date: 2017/10/21
 */
public abstract class AbstractParam extends PagableParam {

    private static final long serialVersionUID = 8142265086821973050L;

    public Map<String, Object> toParamMap() {
        final Map<String, Object> params = new HashMap<String, Object>();
        if (isPaged()) {
            params.put("startNum", getStartNum());
            params.put("pageSize", getPageSize());
        }
        addParams(params);
        // 增加额外的查询参数
        return params;
    }

    /**
     * 增加参数
     */
    protected abstract void addParams(Map<String, Object> existParam);

    protected void addIfNotNull(Map<String, Object> existing, String key, Object obj) {
        if (obj != null) {
            existing.put(key, obj);
        }
    }

    protected void addIfNotEmpty(Map<String, Object> existing, String key, String str) {
        if (!StringUtil.isEmpty(str)) {
            existing.put(key, str);
        }
    }

    protected void addIfNotEmpty(Map<String, Object> existing, String key, Collection<?> list) {
        if (list != null && list.size() > 0) {
            existing.put(key, list);
        }
    }

}
