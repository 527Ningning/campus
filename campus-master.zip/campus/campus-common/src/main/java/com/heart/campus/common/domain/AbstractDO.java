package com.heart.campus.common.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 抽象DO数据
 *
 * @author: heart
 * @date: 2017/10/21
 */
public abstract class AbstractDO implements Serializable {

    private static final long serialVersionUID = 8142465576921972196L;

    private Long              id;

    private Date              gmtCreate;

    private Date              gmtModified;

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
