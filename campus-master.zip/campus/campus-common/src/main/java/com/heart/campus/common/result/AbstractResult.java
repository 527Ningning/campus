package com.heart.campus.common.result;

import java.io.Serializable;

/**
 * 抽象结果类
 *
 * @author: heart
 * @date: 2017/10/23
 */
public class AbstractResult implements Serializable {

    private static final long serialVersionUID = -3934404708879884705L;

    /**
     * 请求是否成功
     */
    protected boolean         success          = true;
    /**
     * 错误码
     */
    protected String          errCode;
    /**
     * 错误信息
     */
    protected String          errMessage;

    /**
     * @return the success
     */
    public boolean isSuccess() {
        return success;
    }

    /**
     * @param success the success to set
     */
    public void setSuccess(boolean success) {
        this.success = success;
    }

    /**
     * @return the errCode
     */
    public String getErrCode() {
        return errCode;
    }

    /**
     * @param errCode the errCode to set
     */
    public void setErrCode(String errCode) {
        this.errCode = errCode;
    }

    /**
     * @return the errMessage
     */
    public String getErrMessage() {
        return errMessage;
    }

    /**
     * @param errMessage the errMessage to set
     */
    public void setErrMessage(String errMessage) {
        this.errMessage = errMessage;
    }
}
