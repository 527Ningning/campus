package com.heart.campus.common.result;

/**
 * 结果模型
 *
 * @author: heart
 * @date: 2017/10/23
 */
public class Result<T> extends AbstractResult {

    private static final long serialVersionUID = 5826203768703593145L;

    /**
     * 子错误码
     */
    private String            subErrCode;
    /**
     * 子错误信息
     */
    private String            subErrMessage;
    /**
     * 请求结果内容
     */
    private T                 content;

    /**
     * @return the subErrCode
     */
    public String getSubErrCode() {
        return subErrCode;
    }

    /**
     * @param subErrCode the subErrCode to set
     */
    public void setSubErrCode(String subErrCode) {
        this.subErrCode = subErrCode;
    }

    /**
     * @return the subErrMessage
     */
    public String getSubErrMessage() {
        return subErrMessage;
    }

    /**
     * @param subErrMessage the subErrMessage to set
     */
    public void setSubErrMessage(String subErrMessage) {
        this.subErrMessage = subErrMessage;
    }

    /**
     * @return the content
     */
    public T getContent() {
        return content;
    }

    /**
     * @param content the content to set
     */
    public void setContent(T content) {
        this.content = content;
    }
}
