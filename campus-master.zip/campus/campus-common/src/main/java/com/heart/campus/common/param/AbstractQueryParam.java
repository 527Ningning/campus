package com.heart.campus.common.param;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 抽象查询参数
 *
 * @author: heart
 * @date: 2017/10/24
 */
public abstract class AbstractQueryParam extends AbstractParam {

    private static final long serialVersionUID = 2964274344586836025L;

    public Map<String, Object> toLikeParamMap() {
        final Map<String, Object> params = new HashMap<String, Object>();
        addLikeParams(params);
        // 增加额外的查询参数
        return params;
    }

    public abstract void addLikeParams(Map<String, Object> existParam);

    public abstract String getOrderBy();

    public abstract String getOrder();

}
