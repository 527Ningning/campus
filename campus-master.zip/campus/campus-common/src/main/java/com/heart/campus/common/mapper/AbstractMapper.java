package com.heart.campus.common.mapper;

/**
 * 映射接口类
 *
 * @author: heart
 * @date: 2017/10/24
 */
public interface AbstractMapper<M, D> {

    /**
     * 将数据源转换为模型
     *
     * @param data 数据源
     * @return 模型
     */
    M toModel(D data);

    /**
     * 将模型转换为数据源
     *
     * @param model 模型
     * @return 数据源
     */
    D toDO(M model);
}
