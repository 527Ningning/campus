package com.heart.campus.common.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 抽象模型类
 *
 * @author: heart
 * @date: 2017/10/24
 */
public abstract class AbstractModel implements Serializable {

    private static final long serialVersionUID = -8125473436349209405L;

    private Long              id;

    private Date              gmtCreate;

    private Date              gmtModified;

    public Date getGmtCreate() {
        return gmtCreate;
    }

    public void setGmtCreate(Date gmtCreate) {
        this.gmtCreate = gmtCreate;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

}
