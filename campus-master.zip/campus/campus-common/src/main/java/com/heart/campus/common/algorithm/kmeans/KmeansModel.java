package com.heart.campus.common.algorithm.kmeans;

import com.heart.campus.common.domain.DataItem;
import com.heart.campus.common.domain.ItemCluster;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 聚类模型
 *
 * @author: qiuchao.qc
 * @date: 2017/10/9
 */
public class KmeansModel {
    private double originalCenters[][];
    private int centerCounts[];
    private int attempts; //最大迭代次数
    private double criteriaBreakCondition; // 迭代结束时的最小阈值
    private int[] labels;
    private int k;
    private int perm[];//连续存放的样本
    private int start[];//每个中心开始的位置
    private Map<String, Integer> identifier;
    private KmeansData data;
    private Map<Integer, String> iden0;

    public int predict(String iden) {
        int label = labels[identifier.get(iden)];
        return label;
    }

    /**
     * 将结果矩阵转换为数据簇
     *
     * @return
     */
    public List<ItemCluster> matrixToItemCluster() {
        List<ItemCluster> itemClusters = new ArrayList<>();
        int originalCount = 0;
        for (int i = 0; i < k; i++) {
            int index = labels[perm[start[i]]];
            int counts = centerCounts[index];
            List<DataItem> dataItems = new ArrayList<>();
            List center = new ArrayList();
            DataItem centerItem = new DataItem(iden0.get(perm[i]), center);
            ItemCluster itemCluster = new ItemCluster(index, centerCounts[i], centerItem, dataItems);
            for (int j = 0; j < originalCenters[0].length; j++) {
                center.add(originalCenters[i][j]);
            }

            originalCount += counts;
            for (int j = start[i]; j < originalCount; j++) {
                List items = new ArrayList();
                DataItem dataItem = new DataItem(iden0.get(perm[j]), items);
                for (double num : data.getData()[perm[j]]) {
                    items.add(num);
                }
                dataItems.add(dataItem);
            }
            itemClusters.add(itemCluster);
        }
        return itemClusters;
    }

    public double[][] getOriginalCenters() {
        return originalCenters;
    }

    public void setOriginalCenters(double[][] originalCenters) {
        this.originalCenters = originalCenters;
    }

    public int[] getCenterCounts() {
        return centerCounts;
    }

    public void setCenterCounts(int[] centerCounts) {
        this.centerCounts = centerCounts;
    }

    public int getAttempts() {
        return attempts;
    }

    public void setAttempts(int attempts) {
        this.attempts = attempts;
    }

    public double getCriteriaBreakCondition() {
        return criteriaBreakCondition;
    }

    public void setCriteriaBreakCondition(double criteriaBreakCondition) {
        this.criteriaBreakCondition = criteriaBreakCondition;
    }

    public int[] getLabels() {
        return labels;
    }

    public void setLabels(int[] labels) {
        this.labels = labels;
    }

    public int getK() {
        return k;
    }

    public void setK(int k) {
        this.k = k;
    }

    public int[] getPerm() {
        return perm;
    }

    public void setPerm(int[] perm) {
        this.perm = perm;
    }

    public int[] getStart() {
        return start;
    }

    public void setStart(int[] start) {
        this.start = start;
    }

    public Map<String, Integer> getIdentifier() {
        return identifier;
    }

    public void setIdentifier(Map<String, Integer> identifier) {
        this.identifier = identifier;
    }

    public KmeansData getData() {
        return data;
    }

    public void setData(KmeansData data) {
        this.data = data;
    }

    public Map<Integer, String> getIden0() {
        return iden0;
    }

    public void setIden0(Map<Integer, String> iden0) {
        this.iden0 = iden0;
    }
}
