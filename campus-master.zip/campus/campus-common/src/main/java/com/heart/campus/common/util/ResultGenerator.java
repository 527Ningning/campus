package com.heart.campus.common.util;

import com.heart.campus.common.enums.ErrorCodeEnum;
import com.heart.campus.common.result.Result;

/**
 * @author: yuwu
 * @date: 2017/11/10
 */
public class ResultGenerator {

    public static <T> Result<T> genSuccess(T content) {

        Result<T> result = new Result<>();
        result.setContent(content);
        return result;
    }

    public static <T> Result<T> genError(String errCode, String errMessage) {
        Result<T> result = new Result<>();
        result.setSuccess(false);
        result.setErrCode(errCode);
        result.setErrMessage(errMessage);
        return result;
    }

    public static <T> Result<T> genError(ErrorCodeEnum errorCodeEnum) {
        return genError(errorCodeEnum.getCode(), errorCodeEnum.getMessage());
    }
}