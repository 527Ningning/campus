package com.heart.campus.common.domain;/**
 * Created by Administrator on 2018/3/22.
 */

import java.util.List;

/**
 * @Description: 数据簇
 * @Author: heart
 * @Date: 2018/3/22
 */
public class ItemCluster {

    /**
     * 簇名称
     */
    private String name;

    /**
     * 簇顺序
     */
    private int order;

    /**
     * 簇成员个数
     */
    private int number;

    /**
     * 聚类中心
     */
    private DataItem centerItem;

    /**
     * 数据集
     */
    private List<DataItem> dataItems;

    public ItemCluster() {
    }

    public ItemCluster(int order, List<DataItem> dataItems) {
        this.order = order;
        this.dataItems = dataItems;
    }

    public ItemCluster(int order, int number, DataItem centerItem, List<DataItem> dataItems) {
        this.order = order;
        this.number = number;
        this.centerItem = centerItem;
        this.dataItems = dataItems;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrder() {
        return order;
    }

    public void setOrder(int order) {
        this.order = order;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public DataItem getCenterItem() {
        return centerItem;
    }

    public void setCenterItem(DataItem centerItem) {
        this.centerItem = centerItem;
    }

    public List<DataItem> getDataItems() {
        return dataItems;
    }

    public void setDataItems(List<DataItem> dataItems) {
        this.dataItems = dataItems;
    }
}

