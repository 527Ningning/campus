package com.heart.campus.common.domain;/**
 * Created by Administrator on 2018/3/22.
 */

import java.util.List;

/**
 * @Description: 数据项，主要用于数据分析的对象存储
 * @Author: heart
 * @Date: 2018/3/22
 */
public class DataItem {

    private String name;
    private List items;

    public DataItem() {
    }

    public DataItem(String name) {
        this.name = name;
    }

    public DataItem(String name, List<Object> items) {
        this.name = name;
        this.items = items;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Object> getItems() {
        return items;
    }

    public void setItems(List<Object> items) {
        this.items = items;
    }
}

