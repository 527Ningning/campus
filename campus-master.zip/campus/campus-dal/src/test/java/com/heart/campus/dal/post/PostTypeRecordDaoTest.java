package com.heart.campus.dal.post;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.PostTypeRecordDAO;

import junit.framework.TestCase;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostTypeRecordDaoTest extends BaseDaoTest {

    @Autowired
    PostTypeRecordDAO postTypeRecordDAO;

    @Test
    public void test_insert() {
    }

    @Test
    public void test_query() {
        Map param = new HashMap<>();
        param.put("equalParam_gender", 0);
        List list = postTypeRecordDAO.query(param);
        TestCase.assertNotNull(list);
    }

}
