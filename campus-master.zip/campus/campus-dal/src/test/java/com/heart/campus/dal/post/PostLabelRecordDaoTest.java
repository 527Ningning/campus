package com.heart.campus.dal.post;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.PostLabelRecordDAO;

import junit.framework.TestCase;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostLabelRecordDaoTest extends BaseDaoTest {

    @Autowired
    PostLabelRecordDAO postLabelRecordDAO;

    @Test
    public void test_insert() {
    }

    @Test
    public void test_query() {
        Map param = new HashMap<>();
        param.put("equalParam_gender", 0);
        List list = postLabelRecordDAO.query(param);
        TestCase.assertNotNull(list);
    }

}
