package com.heart.campus.dal.member;

import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.system.MemberDAO;
import com.heart.campus.dal.domain.system.MemberDO;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/5/9
 */
public class MemberDaoTest extends BaseDaoTest {

    @Autowired
    MemberDAO memberDAO;

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
//        param.put("userId", "112016321030905");
        List list = memberDAO.query(param);
        System.out.println(list.get(0).toString());
        TestCase.assertNotNull(list);
    }

    @Test
    public void test_loadMemberList() {
        List<MemberDO> memberDOS = memberDAO.loadMemberList();
        TestCase.assertNotNull(memberDOS);
    }


}

