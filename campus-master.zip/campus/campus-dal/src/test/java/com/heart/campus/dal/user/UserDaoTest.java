package com.heart.campus.dal.user;

import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.system.UserDAO;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: yuwu
 * @date: 2017/11/2
 */
public class UserDaoTest extends BaseDaoTest {

    @Autowired
    UserDAO userDAO;

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_userId", "112016321030905");
        List list = userDAO.query(param);
        System.out.println(list.get(0).toString());
        TestCase.assertNotNull(list);
    }

    @Test
    public void test_count() {
        Map<String, Object> param = new HashMap<>();
        int count = userDAO.count(param);
        //TestCase.assertEquals(2, count);
    }

}
