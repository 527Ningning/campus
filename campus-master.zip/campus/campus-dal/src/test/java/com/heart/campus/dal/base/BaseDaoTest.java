package com.heart.campus.dal.base;

import com.heart.campus.dal.DaoTestApplication;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * 基础测试类
 *
 * @author: heart
 * @date: 2017/11/13
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = { DaoTestApplication.class })
public abstract class BaseDaoTest {
    
}
