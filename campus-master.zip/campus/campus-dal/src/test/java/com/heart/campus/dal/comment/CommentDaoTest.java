package com.heart.campus.dal.comment;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.CommentDAO;
import com.heart.campus.dal.domain.data.CommentDO;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * CommentDAO接口测试
 *
 * @author: yuwu
 * @date: 2017/11/15
 */
public class CommentDaoTest extends BaseDaoTest {

    @Autowired
    CommentDAO commentDao;

    @Test
    public void test_count() {
        Map<String, Object> param = new HashMap<>();
        int count = commentDao.count(param);
        //TestCase.assertEquals(1, count);
    }

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_id", 1);
        List list = commentDao.query(param);
        //TestCase.assertEquals(1, list.size());
    }

    @Test
    public void test_insert() {
        CommentDO data = new CommentDO();
        data.setCommentId("1003");
        data.setPostId("1000");
        data.setUserId("112016321030905");
        data.setContent("内容");
        data.setStatus(CommonStatusEnum.NORMAL.getValue());
        data.setBlackWhiteState(0);
        commentDao.insert(data);
    }

}
