package com.heart.campus.dal.postType;

import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.PostTypeDAO;
import com.heart.campus.dal.domain.data.PostTypeDO;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PostTypeDAO接口测试
 *
 * @author: yuwu
 * @date: 2017/11/13
 */
public class PostTypeDaoTest extends BaseDaoTest {

    @Autowired
    PostTypeDAO postTypeDAO;

    @Test
    public void test_count() {
        Map<String, Object> param = new HashMap<>();
        int count = postTypeDAO.count(param);
        //TestCase.assertEquals(3, count);
    }

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_id", 4);
        List list = postTypeDAO.query(param);
        TestCase.assertEquals(1, list.size());
    }

    @Test
    public void test_insert() {
        PostTypeDO type = new PostTypeDO();
        type.setDesc("实用宝箱");
        //type.setStatus(0);
        postTypeDAO.insert(type);
    }

    @Test
    public void test_delete() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_id", 5);
        postTypeDAO.delete(param);
    }
}
