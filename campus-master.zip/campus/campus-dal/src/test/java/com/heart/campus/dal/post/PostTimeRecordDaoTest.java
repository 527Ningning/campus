package com.heart.campus.dal.post;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.PostTimeRecordDAO;
import com.heart.campus.dal.domain.data.PostTimeRecordDO;

import junit.framework.TestCase;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostTimeRecordDaoTest extends BaseDaoTest {

    @Autowired
    PostTimeRecordDAO postTimeRecordDao;

    @Test
    public void test_insert() {
        PostTimeRecordDO postTimeDO = new PostTimeRecordDO();
        postTimeDO.setGender(0);
        postTimeDO.setStatus(0);

        postTimeDO.setHour(4);
        postTimeDO.setWeek(21);
        postTimeDO.setNumber(7);

        Integer number = postTimeRecordDao.insert(postTimeDO);
        TestCase.assertNotSame(0, number);
    }

    @Test
    public void test_query() {
        Map param = new HashMap<>();
        param.put("equalParam_gender", 0);
        List list = postTimeRecordDao.query(param);
        TestCase.assertNotNull(list);
    }

}
