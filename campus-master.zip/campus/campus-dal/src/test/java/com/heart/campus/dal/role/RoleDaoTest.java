package com.heart.campus.dal.role;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.system.RoleDAO;
import com.heart.campus.dal.domain.system.RoleDO;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * RoleDAO接口测试
 * 
 * @author: yuwu
 * @date: 2017/11/3
 */
public class RoleDaoTest extends BaseDaoTest {

    @Autowired
    RoleDAO roleDAO;

    @Test
    public void test_count() {
        Map<String, Object> param = new HashMap<>();
        int count = roleDAO.count(param);
        //TestCase.assertEquals(4, count);
    }

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_name", "USER");
        List list = roleDAO.query(param);
        TestCase.assertNotNull(list);
    }

    @Test
    public void test_batchInsert() {
        List<RoleDO> roleDOS = new ArrayList<>();
        roleDOS.add(genRoleDO());
        roleDOS.add(genRoleDO());
        Integer num = roleDAO.batchInsert(roleDOS);
        TestCase.assertEquals(2, num.intValue());
    }

    private RoleDO genRoleDO() {
        RoleDO roleDO = new RoleDO();
        roleDO.setName("ROLE_TEST_3");
        roleDO.setStatus(CommonStatusEnum.NORMAL.getValue());
        return roleDO;
    }

}
