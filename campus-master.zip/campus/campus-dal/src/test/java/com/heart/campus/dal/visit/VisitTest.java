package com.heart.campus.dal.visit;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.VisitDAO;
import com.heart.campus.dal.domain.data.VisitDO;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * visitDAO测试
 * 
 * @author: yuwu
 * @date: 2017/11/29
 */
public class VisitTest extends BaseDaoTest {

    @Autowired
    VisitDAO visitDao;

    @Test
    public void test_count() {
        Map<String, Object> param = new HashMap<>();
        int count = visitDao.count(param);
        TestCase.assertEquals(0, count);
    }

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_userId", "112016321030905");
        List list = visitDao.query(param);
        TestCase.assertNotNull(list);
    }

    @Test
    public void test_insert() {
        Integer num = visitDao.insert(genRoleDO());
        TestCase.assertEquals(1, num.intValue());
    }

    private VisitDO genRoleDO() {
        VisitDO visitDO = new VisitDO();
        visitDO.setPostId(1L);
        visitDO.setUserId("112016321030905");
        visitDO.setStatus(CommonStatusEnum.NORMAL.getValue());
        return visitDO;
    }
}
