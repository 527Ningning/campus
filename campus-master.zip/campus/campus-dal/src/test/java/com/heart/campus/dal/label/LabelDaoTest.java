package com.heart.campus.dal.label;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.LabelDAO;
import com.heart.campus.dal.domain.data.LabelDO;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Label
 *
 * @author: yuwu
 * @date: 2017/12/23
 */
public class LabelDaoTest extends BaseDaoTest {

    @Autowired
    LabelDAO labelDAO;

    @Test
    public void test_count() {
        Map<String, Object> param = new HashMap<>();
        int count = labelDAO.count(param);
        TestCase.assertEquals(9, count);
    }

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_label", "心情");
        List list = labelDAO.query(param);
        TestCase.assertNotNull(list);
    }

    @Test
    public void test_batchInsert() {
        List<LabelDO> roleDOS = new ArrayList<>();
        roleDOS.add(genLabelDO());
        roleDOS.add(genLabelDO());
        Integer num = labelDAO.batchInsert(roleDOS);
        TestCase.assertEquals(2, num.intValue());
    }

    private LabelDO genLabelDO() {
        LabelDO labelDO = new LabelDO();
        labelDO.setLabel("测试");
        labelDO.setStatus(CommonStatusEnum.NORMAL.getValue());
        return labelDO;
    }

}
