package com.heart.campus.dal.post;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.UserPostRateRecordDAO;
import com.heart.campus.dal.domain.data.UserPostRateRecordDO;

import junit.framework.TestCase;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/30
 */
public class UserPostRateRecordDaoTest extends BaseDaoTest {

    @Autowired
    UserPostRateRecordDAO userPostRateRecordDAO;

    @Test
    public void test_insert() {
        UserPostRateRecordDO rateRecordDO = new UserPostRateRecordDO();
        rateRecordDO.setUserId("112016321001450");
        rateRecordDO.setVisitRate(0.32);
        rateRecordDO.setCommentRate(0.11);
        rateRecordDO.setPostRate(0.09);
        rateRecordDO.setUpvoteRate(0.28);
        Integer insert = userPostRateRecordDAO.insert(rateRecordDO);
        TestCase.assertNotNull(insert);

    }

    @Test
    public void test_query() {
        Map param = new HashMap<>();
        // param.put("equalParam_gender", 0);
        List list = userPostRateRecordDAO.query(param);
        TestCase.assertNotNull(list);
    }

}
