package com.heart.campus.dal.post;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.dal.base.BaseDaoTest;
import com.heart.campus.dal.dao.data.PostDAO;
import com.heart.campus.dal.domain.data.PostDO;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PostDAO单元测试
 *
 * @author: yuwu
 * @date: 2017/11/14
 */
public class PostDaoTest extends BaseDaoTest {

    @Autowired
    PostDAO postDao;

    @Test
    public void test_count() {
        Map<String, Object> param = new HashMap<>();
        int count = postDao.count(param);
        //TestCase.assertEquals(2, count);
    }

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_id", 2);
        List list = postDao.query(param);
        TestCase.assertEquals(1, list.size());
    }

    @Test
    public void test_insert() {
        PostDO data = new PostDO();
        data.setPostId("100");
        data.setTypeId(1);
        data.setUserId("112016321030905");
        data.setTitle("您好呀");
        data.setContent("这是内容啊");
        data.setPriority(3);
        data.setUpvoteCount(12);
        data.setVisitCount(10);
        data.setStatus(CommonStatusEnum.NORMAL.getValue());
        data.setBlackWhiteState(0);
        postDao.insert(data);
    }
//
//    @Test
//    public void test_delete() {
//        Map<String, Object> param = new HashMap<>();
//        param.put("equalParam_id", 5);
//        postDao.delete(param);
//    }
}
