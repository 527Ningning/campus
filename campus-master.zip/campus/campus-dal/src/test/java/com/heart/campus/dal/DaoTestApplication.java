package com.heart.campus.dal;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.PropertySource;

/**
 * DAO层单元测试SpringBoot配置类
 *
 * @author: heart
 * @date: 2017/10/21
 */
@SpringBootApplication
@PropertySource("classpath:application-test.properties")
@MapperScan(basePackages = "com.heart.campus.dal")
public class DaoTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(DaoTestApplication.class, args);
    }

}
