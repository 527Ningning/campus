package com.heart.campus.dal.upvote;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.heart.campus.dal.dao.data.UpvoteDAO;
import com.heart.campus.dal.domain.data.UpvoteDO;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.heart.campus.common.enums.CommonStatusEnum;
import com.heart.campus.dal.base.BaseDaoTest;

import junit.framework.TestCase;

/**
 * upvoteDAO测试
 * 
 * @author: yuwu
 * @date: 2017/11/29
 */
public class UpvoteTest extends BaseDaoTest {

    @Autowired
    UpvoteDAO upvoteDao;

    @Test
    public void test_count() {
        Map<String, Object> param = new HashMap<>();
        int count = upvoteDao.count(param);
        TestCase.assertEquals(0, count);
    }

    @Test
    public void test_query() {
        Map<String, Object> param = new HashMap<>();
        param.put("equalParam_userId", "112016321030905");
        List list = upvoteDao.query(param);
        TestCase.assertNotNull(list);
    }

    @Test
    public void test_insert() {
        Integer num = upvoteDao.insert(genRoleDO());
        TestCase.assertEquals(1, num.intValue());
    }

    private UpvoteDO genRoleDO() {
        UpvoteDO upvoteDO = new UpvoteDO();
        upvoteDO.setPostId(1L);
        upvoteDO.setUserId("112016321030905");
        upvoteDO.setStatus(CommonStatusEnum.NORMAL.getValue());
        return upvoteDO;
    }
}
