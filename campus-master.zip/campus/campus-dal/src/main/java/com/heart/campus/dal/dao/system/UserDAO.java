package com.heart.campus.dal.dao.system;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.dal.domain.system.UserDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * 用户DAO接口
 *
 * @author: yuwu
 * @date: 2017/11/2
 */
@Mapper
@Repository("userDao")
public interface UserDAO extends AbstractDAO<UserDO> {
}
