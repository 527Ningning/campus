package com.heart.campus.dal.dao.data;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.dal.domain.data.PostDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * 帖子DAO接口
 *
 * @author: yuwu
 * @date: 2017/11/14
 */
@Mapper
@Repository("postDao")
public interface PostDAO extends AbstractDAO<PostDO> {
}
