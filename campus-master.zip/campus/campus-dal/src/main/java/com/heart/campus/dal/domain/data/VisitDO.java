package com.heart.campus.dal.domain.data;

import com.heart.campus.common.domain.AbstractDO;

/**
 * 用户浏览记录DO
 * 
 * @author: yuwu
 * @date: 2017/11/29
 */
public class VisitDO extends AbstractDO {

    /**
     * 学号
     */
    private String  userId;

    /**
     * 帖子id
     */
    private Long    postId;

    /**
     * 逻辑删除位
     */
    private Integer status;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    @Override
    public String toString() {
        return "VisitDO{" +
                "userId='" + userId + '\'' +
                ", postId=" + postId +
                ", status=" + status +
                '}';
    }
}
