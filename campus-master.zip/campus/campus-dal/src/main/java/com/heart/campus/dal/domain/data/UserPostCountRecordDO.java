package com.heart.campus.dal.domain.data;

import com.heart.campus.common.domain.AbstractDO;

/**
 * @Description: 用户
 * @Author: heart
 * @Date: 2018/3/11
 */
public class UserPostCountRecordDO extends AbstractDO {

    /**
     * 用户学号
     */
    private String userId;

    /**
     * 七嘴八舌浏览
     */
    private Integer talkCount;

    /**
     * 约喝约玩浏览量
     */
    private Integer playCount;

    /**
     * 二手市场浏览量
     */
    private Integer marketCount;

    /**
     * 勤工俭学浏览量
     */
    private Integer partTimeCount;

    /**
     * 求职天地浏览量
     */
    private Integer workCount;

    /**
     * 学术殿堂浏览量
     */
    private Integer studyCount;

    /**
     * 失物招领浏览量
     */
    private Integer lostCount;

    /**
     * 校园百科浏览量
     */
    private Integer campusCount;

    /**
     * 状态
     */
    private Integer status;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getTalkCount() {
        return talkCount;
    }

    public void setTalkCount(Integer talkCount) {
        this.talkCount = talkCount;
    }

    public Integer getPlayCount() {
        return playCount;
    }

    public void setPlayCount(Integer playCount) {
        this.playCount = playCount;
    }

    public Integer getMarketCount() {
        return marketCount;
    }

    public void setMarketCount(Integer marketCount) {
        this.marketCount = marketCount;
    }

    public Integer getPartTimeCount() {
        return partTimeCount;
    }

    public void setPartTimeCount(Integer partTimeCount) {
        this.partTimeCount = partTimeCount;
    }

    public Integer getWorkCount() {
        return workCount;
    }

    public void setWorkCount(Integer workCount) {
        this.workCount = workCount;
    }

    public Integer getStudyCount() {
        return studyCount;
    }

    public void setStudyCount(Integer studyCount) {
        this.studyCount = studyCount;
    }

    public Integer getLostCount() {
        return lostCount;
    }

    public void setLostCount(Integer lostCount) {
        this.lostCount = lostCount;
    }

    public Integer getCampusCount() {
        return campusCount;
    }

    public void setCampusCount(Integer campusCount) {
        this.campusCount = campusCount;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}

