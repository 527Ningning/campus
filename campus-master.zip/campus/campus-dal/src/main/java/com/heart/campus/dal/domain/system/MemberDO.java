package com.heart.campus.dal.domain.system;

import com.heart.campus.common.domain.AbstractDO;

/**
 * @Description: 团队成员
 * @Author: heart
 * @Date: 2018/3/11
 */
public class MemberDO extends AbstractDO {

    /**
     * 年龄
     */
    private int     age;
    /**
     * 性别
     */
    private int     gender;
    /**
     * 中文名
     */
    private String  cName;
    /**
     * 英文名
     */
    private String  eName;
    /**
     * 职位
     */
    private String  rank;
    /**
     * 详情
     */
    private String  content;
    /**
     * 头像
     */
    private String  headPhoto;
    /**
     * 生活照
     */
    private String  lifePhoto;
    /**
     * 职称
     */
    private String  degree;
    /**
     * 邮箱
     */
    private String  email;
    /**
     * 学院
     */
    private String  depart;
    /**
     * 手机
     */
    private String  phone;
    /**
     * 座机
     */
    private String  telephone;
    /**
     * 研究方向
     */
    private String  direction;

    /**
     * 删除标志位
     */
    private Integer status;

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    public String geteName() {
        return eName;
    }

    public void seteName(String eName) {
        this.eName = eName;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getHeadPhoto() {
        return headPhoto;
    }

    public void setHeadPhoto(String headPhoto) {
        this.headPhoto = headPhoto;
    }

    public String getLifePhoto() {
        return lifePhoto;
    }

    public void setLifePhoto(String lifePhoto) {
        this.lifePhoto = lifePhoto;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDepart() {
        return depart;
    }

    public void setDepart(String depart) {
        this.depart = depart;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
