package com.heart.campus.dal.domain.system;

import com.heart.campus.common.domain.AbstractDO;
import com.heart.campus.common.domain.AbstractModel;

/**
 * 角色DO数据
 *
 * @author: yuwu
 * @date: 2017/11/3
 */
public class RoleDO extends AbstractDO {

    /**
     * 角色名称
     */
    private String name;

    /**
     * 角色描述
     */
    private String desc;

    /**
     * 删除标志位
     */
    private Integer status;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "RoleDO{" + "name='" + name + '\'' + ", status=" + status + '}';
    }

}
