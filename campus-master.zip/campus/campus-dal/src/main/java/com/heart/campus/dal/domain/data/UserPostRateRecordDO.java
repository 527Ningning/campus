package com.heart.campus.dal.domain.data;

import com.heart.campus.common.domain.AbstractDO;

/**
 * @Description: 用户帖子相关行为频率记录
 * @Author: heart
 * @Date: 2018/3/11
 */
public class UserPostRateRecordDO extends AbstractDO {

    /**
     * 用户学号
     */
    private String userId;

    /**
     * 发帖频率（每小时）
     */
    private Double postRate;

    /**
     * 浏览频率（每小时）
     */
    private Double visitRate;

    /**
     * 频率频率（每小时）
     */
    private Double commentRate;

    /**
     * 点赞频率（每小时）
     */
    private Double upvoteRate;

    /**
     * 状态
     */
    private Integer status;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Double getPostRate() {
        return postRate;
    }

    public void setPostRate(Double postRate) {
        this.postRate = postRate;
    }

    public Double getVisitRate() {
        return visitRate;
    }

    public void setVisitRate(Double visitRate) {
        this.visitRate = visitRate;
    }

    public Double getCommentRate() {
        return commentRate;
    }

    public void setCommentRate(Double commentRate) {
        this.commentRate = commentRate;
    }

    public Double getUpvoteRate() {
        return upvoteRate;
    }

    public void setUpvoteRate(Double upvoteRate) {
        this.upvoteRate = upvoteRate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}

