package com.heart.campus.dal.dao.data;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.dal.domain.data.VisitDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * 用户浏览DAO
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
@Mapper
@Repository("visitDao")
public interface VisitDAO extends AbstractDAO<VisitDO> {
}
