package com.heart.campus.dal.domain.data;

import com.heart.campus.common.domain.AbstractDO;

/**
 * @Description: 发帖时间记录表
 * @Author: heart
 * @Date: 2018/3/30
 */
public class PostTimeRecordDO extends AbstractDO {
    /**
     * 发帖小时
     */
    private Integer hour;

    /**
     * 发帖星期 X
     */
    private Integer week;

    /**
     * 发帖人性别
     */
    private Integer gender;

    /**
     * 发帖数量
     */
    private Integer number;

    private Integer status;

    public Integer getHour() {
        return hour;
    }

    public void setHour(Integer hour) {
        this.hour = hour;
    }

    public Integer getWeek() {
        return week;
    }

    public void setWeek(Integer week) {
        this.week = week;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}

