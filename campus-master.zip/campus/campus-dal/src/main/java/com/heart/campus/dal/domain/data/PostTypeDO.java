package com.heart.campus.dal.domain.data;

import com.heart.campus.common.domain.AbstractDO;

/**
 * @author: yuwu
 * @date: 2017/11/13
 */
public class PostTypeDO extends AbstractDO {

    /**
     * 类型描述
     */
    private String desc;

    /**
     * 删除标志位
     */
    private Integer    status;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
