package com.heart.campus.dal.dao.data;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.dal.domain.data.UserPostCountRecordDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/3/31
 */
@Mapper
@Repository("userPostCountRecordDao")
public interface UserPostCountRecordDAO extends AbstractDAO<UserPostCountRecordDO> {
}
