package com.heart.campus.dal.dao.data;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.dal.domain.data.LabelDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * 标签DAO
 *
 * @author: yuwu
 * @date: 2017/12/23
 */
@Mapper
@Repository("labelDao")
public interface LabelDAO extends AbstractDAO<LabelDO> {
}
