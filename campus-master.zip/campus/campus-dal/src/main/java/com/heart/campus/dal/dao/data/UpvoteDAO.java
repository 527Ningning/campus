package com.heart.campus.dal.dao.data;

import com.heart.campus.dal.domain.data.UpvoteDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.heart.campus.common.dao.AbstractDAO;

/**
 * 用户点赞DAO
 *
 * @author: yuwu
 * @date: 2017/11/29
 */
@Mapper
@Repository("upvoteDao")
public interface UpvoteDAO extends AbstractDAO<UpvoteDO> {
}
