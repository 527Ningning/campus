package com.heart.campus.dal.domain.data;

import com.heart.campus.common.domain.AbstractDO;

/**
 * 标签DO
 *
 * @author: yuwu
 * @date: 2017/12/23
 */
public class LabelDO extends AbstractDO {

    /**
     * 标签名字
     */
    private String  label;

    /**
     * 删除标志位
     */
    private Integer status;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "LabelDO{" +
                "label='" + label + '\'' +
                ", status=" + status +
                '}';
    }
}
