package com.heart.campus.dal.dao.data;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.dal.domain.data.PostTypeDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * 帖子类型DAO接口
 *
 * @author: yuwu
 * @date: 2017/11/13
 */
@Mapper
@Repository("postTypeDao")
public interface PostTypeDAO extends AbstractDAO<PostTypeDO> {
}
