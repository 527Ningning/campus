package com.heart.campus.dal.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.dal.domain.system.MemberDO;

/**
 * @Description:
 * @Author: heart
 * @Date: 2018/5/9
 */
@Mapper
@Repository("memberDao")
public interface MemberDAO extends AbstractDAO<MemberDO> {

    /**
     * 获取member概要信息列表
     *
     * @return
     */
    List<MemberDO> loadMemberList();
}
