package com.heart.campus.dal.domain.data;

import com.heart.campus.common.domain.AbstractDO;

/**
 * CommentDO数据 评论数据
 * 
 * @author: yuwu
 * @date: 2017/11/15
 */
public class CommentDO extends AbstractDO {

    /**
     * 评论ID
     */
    private String commentId;

    /**
     * 帖子ID
     */
    private String  postId;

    /**
     * 用户ID
     */
    private String  userId;

    /**
     * 评论内容
     */
    private String  content;

    /**
     * 黑白名单标志位
     */
    private Integer blackWhiteState;

    /**
     * 逻辑删除位
     */
    private Integer status;

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getBlackWhiteState() {
        return blackWhiteState;
    }

    public void setBlackWhiteState(Integer blackWhiteState) {
        this.blackWhiteState = blackWhiteState;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCommentId() {
        return commentId;
    }

    public void setCommentId(String commentId) {
        this.commentId = commentId;
    }
    @Override
    public String toString() {
        return "CommentDO{" +
                "postId='" + postId + '\'' +
                ", userId='" + userId + '\'' +
                ", content='" + content + '\'' +
                ", blackWhiteState=" + blackWhiteState +
                ", status=" + status +
                '}';
    }
}
