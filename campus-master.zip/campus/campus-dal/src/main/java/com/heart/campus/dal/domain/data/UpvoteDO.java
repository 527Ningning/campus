package com.heart.campus.dal.domain.data;

import com.heart.campus.common.domain.AbstractDO;

/**
 * 点赞DO
 * 
 * @author: yuwu
 * @date: 2017/11/29
 */
public class UpvoteDO extends AbstractDO {

    private String  userId;

    private Long    postId;

    private Integer status;

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    @Override
    public String toString() {
        return "UpvoteDO{" +
                "userId='" + userId + '\'' +
                ", postId=" + postId +
                ", status=" + status +
                '}';
    }
}
