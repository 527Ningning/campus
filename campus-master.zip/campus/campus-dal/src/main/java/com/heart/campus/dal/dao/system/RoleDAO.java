package com.heart.campus.dal.dao.system;

import com.heart.campus.common.dao.AbstractDAO;
import com.heart.campus.dal.domain.system.RoleDO;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * 角色DAO接口
 * 
 * @author: yuwu
 * @date: 2017/11/3
 */
@Mapper
@Repository("roleDao")
public interface RoleDAO extends AbstractDAO<RoleDO> {
}
