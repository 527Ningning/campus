# campus
基于SOA的校园信息共享平台

## 项目结构说明

* campus-start: Spring Boot启动入口
* campus-dal: 数据DAO层
* campus-service：业务逻辑层
* campus-web: 应用控制层和表示层
* campus-common: 通用工具包

## 数据库设计原则

1. 主键自生成，且均为id
2. 在TB所有表中都添加gmt_create、gmt_modified字段，都是datetime类型。gmt_create表示记录创建时间，gmt_modified表示最近修改时间，如果记录没有修改，gmt_create和gmt_modified一致。
3. 在TB所有表中都添加status状态，表示状态。其作用是所有delete操作均为逻辑删除，其实现是修改status
4. 禁止使用物理外键
5. 库名，表名，字段名必须都用小写字母，并用下划线_分隔，并且见名知意，使用名词
6. 存储精确浮点数必须使用DECIMAL替代FLOAT和DOUBLE
7. 尽可能不使用TEXT、BLOB类型
8. 适当建立索引
   * 非唯一索引必须按照“idx_字段名称_字段名称[_字段名]”进行命名
   * 唯一索引必须按照“uniq_字段名称_字段名称[_字段名]”进行命名
   * 索引名称必须使用小写
   * 索引中的字段数建议不超过5个
   * 单张表的索引数量控制在5个以内
   * 不建议使用%前缀模糊查询，例如LIKE “%weibo”

## 后台代码规范

1. 空指针判断
2. 避免“箭头型”代码
3. 注意依赖排包，避免依赖冲突
   * 打印依赖树：mvn dependency:tree > tree.log
   * 排包示例：
      ```xml
      <exclusions>
         <exclusion>
            <groupId>org.hamcrest</groupId>
            <artifactId>hamcrest-core</artifactId>
         </exclusion>
      </exclusions>
      ```

## 错误日志

### Coult not autowire. No beans of 'xxx' type found.

* 原因：spring没有成功注入该bean
* 解决方法：添加注解，如DAO层接口添加注解Repository

### org.apache.ibatis.binding.BindingException: Invalid bound statement (not found)

* 原因：
   1. SQL语法错误；
   2. mapper中对应的方法是否存在且正确
   3. mybatis配置文件是否成功加载
* 解决方案：在本项目中问题原因是配置文件未被加载，缺少配置项。解决方式是在application.properties中添加如下配置：
   `mybatis.config-location=classpath:mybatis-config.xml`

### Android版本更新下载失败问题

* 原因：
   1、排查发现是jetty服务器中断了资源下载
   2、定位Jetty配置文件
* 解决方案：修改Jetty配置文件【start.ini】中的http_timeout选项，把参数值修改为12000（即2分钟），问题解决。


## Mybatis数据类型参照

|JDBC Type|Java Type|
|---------|-------|
|CHAR|String|
|VARCHAR|String|
|LONGVARCHAR|String|
|NUMERIC|java.math.BigDecimal|
|DECIMAL|java.math.BigDecimal|
|BIT|boolean|
|BOOLEAN|boolean|
|TINYINT|byte|
|SMALLINT|short|
|INTEGER|int|
|BIGINT|long|
|REAL|float|
|FLOAT|double|
|DOUBLE|double|
|BINARY|byte[]|
|VARBINARY|byte[]|
|LONGVARBINARY|byte[]|
|DATE|java.sql.Date|
|TIME|java.sql.Time|
|TIMESTAMP|java.sql.Timestamp|
|CLOB|Clob|
|BLOB|Blob|
|ARRAY|Array|
|DISTINCT|mapping of underlying type|
|STRUCT|Struct|
|REF|ef|
|DATALINK|java.net.URL[color=red][/color]|
