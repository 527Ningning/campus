package app.campus.heart.com.campus.ui.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.common.utils.StringUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.SearchPresenter;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import app.campus.heart.com.campus.ui.adapter.RecycleViewDivider;
import app.campus.heart.com.campus.ui.adapter.SearchResultRviewAdapter;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 搜索结果页面
 *
 * @author: Veyron
 * @date：2018/04/26
 */
public class SearchResultsActivity extends AppCompatActivity
        implements SwipeRefreshLayout.OnRefreshListener {


    @BindView(R.id.go_back)
    ImageView mGoBack;
    @BindView(R.id.hot_postlist)
    RecyclerView mSearchPostlist;
    @BindView(R.id.swipe_common)
    SwipeRefreshLayout mSwipe;
    @BindView(R.id.scrollView)
    NestedScrollView mScrollView;

    private String userId;
    private String key;
    private Result<PageList<HotItemDto>> mResult;
    private SearchPresenter mPresenter;
    private Retrofit mRetrofit;

    //创建一个线性布局管理器
    LinearLayoutManager layoutManager;
    List<HotItemDto> mList = new ArrayList<>();
    SearchResultRviewAdapter mAdapter;

    private Handler handler = new Handler();

    private int index = 1;

    private boolean isLoading = false;  //判断是否加载更多，避免重复请求网络
    private Integer currentPage = 1;
    private Integer nextPage = 1;
    private Integer lastPage = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);
        ButterKnife.bind(this);
        Intent i = getIntent();
        userId = i.getStringExtra("userId");
        key = i.getStringExtra("key");
        mResult = (Result<PageList<HotItemDto>>)
                i.getSerializableExtra("result");

        initRefresh();

        initRetrofit();
        //展示搜索结果
        initPresenter();
        initSearchResultList();
    }

    private void initRefresh() {
        mSwipe.setOnRefreshListener(this);
        mSwipe.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimary, R.color.colorPrimaryDark);
    }

    private void initPresenter() {
        mPresenter = new SearchPresenter(new CallBack<PageList<HotItemDto>>() {
            @Override
            public void showResult(Result<PageList<HotItemDto>> result) {
                // 真正的显示数据

                LogUtil.E(result.toString());

                showSearchResultList(result);
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {

            }

            @Override
            public void showSuccess(String msg) {

            }
        }, mRetrofit);
    }

    private void initRetrofit() {
        mRetrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }

    private void initSearchResultList() {
        layoutManager = new LinearLayoutManager(this);
        mSearchPostlist.setLayoutManager(layoutManager);
        mSearchPostlist.setFocusable(false); // 取消列表的焦点，解决切换fragment时自动下滑列表导致的bug
        //添加分割线
        mSearchPostlist.addItemDecoration(new RecycleViewDivider(this, R.drawable.divider_mileage));
        mSearchPostlist.setNestedScrollingEnabled(false);//解决滑动缓慢问题

        ((SimpleItemAnimator) mSearchPostlist.getItemAnimator())
                .setSupportsChangeAnimations(false);  //解决刷新抖动问题

        // 对 mScrollView 的滑动监听
        if (mScrollView != null) {
            mScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
                @Override
                public void onScrollChange(NestedScrollView v, int scrollX,
                                           int scrollY, int oldScrollX, int oldScrollY) {
                    if (scrollY > oldScrollY) {
                        LogUtil.E("下滑...");
                    }
                    if (scrollY < oldScrollY) {
                        LogUtil.E("上滑");
                    }

                    if (scrollY == 0) {
                        LogUtil.E("滑动到顶部");
                    }

                    if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {
                        LogUtil.E("滑动到底部");

                        // 当前屏幕所看到的子项个数
                        int lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition();
                        // 再次判断是否滑动到 recycleView 显示当前页数据的底部
                        if (lastVisibleItemPosition + 1 == mAdapter.getItemCount()) {
                            //已经滑动到最下面
                            /*boolean isRefreshing = mSwipe.isRefreshing();
                            if (isRefreshing) {
                                mAdapter.notifyItemRemoved(mAdapter.getItemCount());
                                return;
                            }*/
                            if (!isLoading) {
                                isLoading = true;
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        isLoading = false;
                                        loadMoreData();
                                    }
                                }, 10);
                            }
                        }
                    }

                }
            });
        }
        // 这里的 mResult 是从搜索页面传过来的
        showSearchResultList(mResult);

        mScrollView.setFocusable(true);
        mScrollView.setFocusableInTouchMode(true);
        mScrollView.requestFocus();
        mScrollView.scrollTo(0, 0);  // 保证滑动到顶部
    }

    private void showSearchResultList(Result<PageList<HotItemDto>> result) {
        currentPage = result.getContent().getPaginator().getPage();
        nextPage = result.getContent().getPaginator().getNextPage();
        lastPage = result.getContent().getPaginator().getLastPage();

        if (currentPage == 1) {
            mList = result.getContent().getDataList();
            LogUtil.E("拉取的数据： " + mList.toString());
            mAdapter = new SearchResultRviewAdapter(SearchResultsActivity.this, mList);
            mSearchPostlist.setAdapter(mAdapter);
            isLoading = false;
            //请求完成结束刷新状态
            //mSwipe.setRefreshing(false);

            mAdapter.setOnItemClickListener(new SearchResultRviewAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(View view, int position) {
                    //点击事件
                    if (SharePresUtil.getObjectFromSharePres
                            (SearchResultsActivity.this, "userObject") == null) {
                        Toast.makeText(SearchResultsActivity.this,
                                "您未登录,请先登录", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(
                                SearchResultsActivity.this, LoginActivity.class));

                    } else {
                        Long postId = mAdapter.getList().get(position).getPostId();
                        LogUtil.E("Hot 点击事件" + postId);
                        Intent intent = new Intent(SearchResultsActivity.this, ArticleActivity.class);
                        intent.putExtra("postId", postId);
                        startActivity(intent);
                    }
                }

                @Override
                public void onItemLongClick(View view, final int position) {
                   /* if (SharePresUtil.getObjectFromSharePres
                            (SearchResultsActivity.this, "userObject") == null) {
                        Toast.makeText(SearchResultsActivity.this,
                                "您未登录,请先登录", Toast.LENGTH_LONG).show();
                        startActivity(new Intent(
                                SearchResultsActivity.this, LoginActivity.class));

                    } else {
                        AlertDialog.Builder builder = new AlertDialog.Builder( SearchResultsActivity.this);
                        builder.setTitle("请确认");
                        builder.setMessage("您是对这个帖子不感兴趣么?");
                        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText( SearchResultsActivity.this, "取消", Toast.LENGTH_SHORT).show();
                            }
                        });
                        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText( SearchResultsActivity.this, "确定", Toast.LENGTH_SHORT).show();
                                //mAdapter.removeItem(position);
                                Long postId = mAdapter.getList().get(position).getPostId();
                                deleteItem(position, tmpUserId, postId.intValue());
                            }
                        });
                        AlertDialog dialog = builder.create();
                        dialog.show();
                    }*/
                }
            });

        } else if (currentPage < result.getContent().getPaginator().getPages()) {
            mList = result.getContent().getDataList();
            mAdapter.addAll(mList);
            //mAdapter.notifyDataSetChanged();
            mAdapter.notifyItemChanged(1, 1);
            isLoading = false;
            //请求完成结束刷新状态
            //mSwipe.setRefreshing(false);
        } else if (currentPage == lastPage) {
            mList = result.getContent().getDataList();
            mAdapter.addAll(mList);
            //mAdapter.notifyDataSetChanged();
            mAdapter.notifyItemChanged(1, 1);
            //请求完成结束刷新状态
            //mSwipe.setRefreshing(false);
        }

        if (currentPage == lastPage) {
            setLoadingFooter(false);
        }
    }


    private void getData() {
        LogUtil.E("刷新数据");
        if (!mList.isEmpty()) {
            mList.clear();
        }
        LogUtil.E("userId", userId);
        if (!StringUtil.isBlank(key)) {
            LogUtil.E("key", key);
            mPresenter.getSearchResults(userId, 1, key);
            mSwipe.setRefreshing(false);
            index = 1;
            setLoadingFooter(true);
        }
    }

    @OnClick(R.id.go_back)
    public void onClick() {
        finish();
        mAdapter.setLoadingFooter(true);
    }

    private void loadMoreData() {
        index++;
        //mSwipe.setRefreshing(true);

        if (index > lastPage) {
            LogUtil.E("已经没有新的了");
            setLoadingFooter(false);
            Toast.makeText(SearchResultsActivity.this, "已经没有新的了", Toast.LENGTH_SHORT).show();
            mAdapter.notifyItemRemoved(mAdapter.getItemCount());
            //mSwipe.setRefreshing(false);
        } else {
            LogUtil.E("加载更多数据");
            setLoadingFooter(true);
            mPresenter.getSearchResults(userId, nextPage, key);
            //mSwipe.setRefreshing(false);
        }
    }

    @Override
    public void onRefresh() {
        // 开始刷新，设置当前为刷新状态
        mSwipe.setRefreshing(true);
        LogUtil.E("刷新数据");
        isLoading = false;
        // 下拉刷新操作：获取新数据
        getData();
    }


    private void setLoadingFooter(Boolean loading) {
        if (mAdapter != null) {
            if (loading) {
                mAdapter.setLoadingFooter(true);
            }
            if (loading && mAdapter.getItemCount() > 5) {
                mAdapter.setLoadingFooter(true);
            } else {
                mAdapter.setLoadingFooter(false);
            }
        }
    }
}
