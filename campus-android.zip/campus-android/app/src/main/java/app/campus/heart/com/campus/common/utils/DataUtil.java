package app.campus.heart.com.campus.common.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 日期转换工具类
 *
 * @author: yuwu
 * @date: 2017/11/23
 */
public class DataUtil {

    public static final String ISO8601DATE_FORMAT = "yyyy-mm-dd'T'hh:mm:ss[.mmm]Z";
    public static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    private static final String DEFAULT_DATE_FORMAT = DATE_FORMAT;

    /**
     * 把日期型转换成字符串形式。
     *
     * @param date       日期
     * @param dateFormat 日期格式，例如"yyyy-MM-dd"、"yyyy年MM月dd"
     * @return 日期字符串
     */
    public static String toLocaleString(Date date, String dateFormat) {
        if (date == null) {
            return "";
        }

        if (isBlank(dateFormat)) {
            return new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(date);
        }

        return new SimpleDateFormat(dateFormat).format(date);
    }

    /**
     * 获得时间
     *
     * @param timestamp
     * @return
     */
    public static Date getDate(Long timestamp) {
        Date date = null;
        if (timestamp != null && timestamp > 0) {
            date = new Date(timestamp);
        }
        return date;
    }

    /**
     * 返回时间区间
     *
     * @param date        当前时间
     * @param monthOffset 月份偏移
     * @return
     */
    public static Date[] getPostTime(Date date, int monthOffset) {
        DateFormat dateTimeFormat = DateFormat.getDateTimeInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date[] dateArea = new Date[2];
        try {
            Calendar nowCal = Calendar.getInstance();
            Calendar thenCal = Calendar.getInstance();
            nowCal.setTime(date);
            thenCal.setTime(date);
            thenCal.add(Calendar.MONTH, monthOffset);

            int nowDay = nowCal.get(Calendar.DAY_OF_MONTH);// 当前月的号
            int nowMaxDay = nowCal.getActualMaximum(Calendar.DAY_OF_MONTH);// 当前月的最大天数

            int thenDay = thenCal.get(Calendar.DAY_OF_MONTH);// 6个月之前的号
            int thenMaxDay = thenCal.getActualMaximum(Calendar.DAY_OF_MONTH);// 6个月之前的当月最大天数

            Date startDate;
            Date endDate;
            if (nowDay > thenDay) {
                // System.out.println("--这个月大于上个月，不用发邮件--");
                return null;
            } else {
                if (nowDay == nowMaxDay && thenDay < thenMaxDay) {
                    String startDateStr = thenCal.get(Calendar.YEAR) + "-" + (thenCal.get(Calendar.MONTH) + 1) + "-"
                            + thenDay + " 00:00:00";
                    String endDateStr = thenCal.get(Calendar.YEAR) + "-" + (thenCal.get(Calendar.MONTH) + 1) + "-"
                            + thenMaxDay + " 23:59:59";
                    startDate = dateTimeFormat.parse(startDateStr);
                    endDate = dateTimeFormat.parse(endDateStr);
                    // System.out.println("-这个月小于上个月，这个月是最后一天了-" + dateTimeFormat.format(startDate)
                    // + "--" +
                    // dateTimeFormat.format(endDate));
                } else {
                    String startDateStr = thenCal.get(Calendar.YEAR) + "-" + (thenCal.get(Calendar.MONTH) + 1) + "-"
                            + thenDay + " 00:00:00";
                    String endDateStr = thenCal.get(Calendar.YEAR) + "-" + (thenCal.get(Calendar.MONTH) + 1) + "-"
                            + thenDay + " 23:59:59";
                    startDate = sdf.parse(startDateStr);
                    endDate = sdf.parse(endDateStr);
                    // System.out.println("-一般情况-" + sdf.format(startDate) + "--" +
                    // sdf.format(endDate));
                }
                dateArea[0] = startDate;
                dateArea[1] = endDate;
                return dateArea;
            }
        } catch (ParseException e) {
            return null;
        }
    }

    // 是否是活动期间
    public static boolean isDuringEvent() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = new Date();
        Date begin = null;
        Date end = null;
        try {
            begin = sdf.parse("2013-11-08 20:00:00");
            end = sdf.parse("2013-11-08 22:00:00");
        } catch (ParseException e) {
        }
        return now.getTime() > begin.getTime() && now.getTime() < end.getTime();
    }

    /**
     * 把日期型转换成"yyyy/MM/dd/"字符串形式。
     *
     * @param date
     * @return 日期字符串
     */
    public static String toLocaleString(Date date) {
        return toLocaleString(date, null);
    }

    /**
     * 获得sysdate+hours后的时间
     *
     * @param hours 提前或者推后的时间
     * @return sysdate+hours后的时间
     */
    public static Date getSysDate(int hours) {
        Calendar time = Calendar.getInstance();

        time.add(Calendar.HOUR, hours);

        return time.getTime();
    }

    /**
     * 方法说明:天数差
     *
     * @param firstDate
     * @param lastDate
     */
    public static int getTimeIntervalDays(Date firstDate, Date lastDate) {
        long intervals = lastDate.getTime() - firstDate.getTime() + (60 * 1000);

        if (intervals > 0) {
            long daysd = intervals / (24 * 60 * 60 * 1000);

            return new Long(daysd).intValue();
        }

        return 0;
    }

    /**
     * 方法说明:小时差
     *
     * @param firstDate
     * @param lastDate
     */
    public static int getTimeIntervalHours(Date firstDate, Date lastDate) {
        long intervals = lastDate.getTime() - firstDate.getTime() + (60 * 1000);

        if (intervals > 0) {
            long longHours = (intervals / (60 * 60 * 1000)) % 24;

            return new Long(longHours).intValue();
        }

        return 0;
    }

    /**
     * 方法说明:分钟差
     *
     * @param firstDate
     * @param lastDate
     */
    public static int getTimeIntervalMins(Date firstDate, Date lastDate) {
        long intervals = lastDate.getTime() - firstDate.getTime() + (60 * 1000);

        if (intervals > 0) {
            long longMins = (intervals / (60 * 1000)) % 60;

            return new Long(longMins).intValue();
        }

        return 0;
    }

    private static boolean isBlank(String str) {
        int length;

        if ((str == null) || ((length = str.length()) == 0)) {
            return true;
        }

        for (int i = 0; i < length; i++) {
            if (!Character.isWhitespace(str.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    /**
     * 方法说明:parse date
     *
     * @param str
     */
    public static Date parseDate(String str) {
        if (isBlank(str)) {
            return null;
        }
        Date date = null;
        if (str.length() == DATETIME_FORMAT.length()) {
            date = parseDate(str, DATETIME_FORMAT);
        } else if (str.length() == TIME_FORMAT.length()) {
            date = parseDate(str, TIME_FORMAT);
        } else if (str.length() == DATE_FORMAT.length()) {
            date = parseDate(str, DATE_FORMAT);
        } else {
            date = parseDate(str, ISO8601DATE_FORMAT);
        }
        return date;
    }

    /**
     * 方法说明:parse date
     *
     * @param val
     */
    public static Date parseDate(Object val) {
        if (val == null) {
            return null;
        }
        Date date = null;
        try {
            if (val instanceof Date) {
                date = (Date) val;
            } else if (val instanceof Number) {
                date = new Date(((Number) val).longValue());
            } else if (val instanceof String) {
                date = parseDate((String) val);
                if (date == null) {
                    long longVal = Long.parseLong((String) val);
                    date = new Date(longVal);
                }
            }
        } catch (Exception e) {
        }
        return date;
    }

    /**
     * 方法说明:parse date
     *
     * @param date
     * @param dateformat
     */
    public static Date parseDate(String date, String dateformat) {
        SimpleDateFormat sdf = new SimpleDateFormat(dateformat);

        try {
            return sdf.parse(date);
        } catch (ParseException e) {
            return null;
        }
    }

    /**
     * 比较日期是否大于当前日期
     */
    public static boolean afterNow(Date date) {
        if (date == null) {
            return false;
        }

        Calendar nowCar = Calendar.getInstance();
        Calendar car = Calendar.getInstance();

        car.setTime(date);

        return car.after(nowCar);
    }

    /*
     * 查看是否早几天
     */
    public static boolean afterDays(Date date, int day) {
        if (date == null) {
            return false;
        }

        Calendar levelDay = Calendar.getInstance();
        Calendar createDay = Calendar.getInstance();

        createDay.setTime(date);
        createDay.add(Calendar.DATE, day);

        if (createDay.after(levelDay)) {
            return true;
        } else {
            return false;
        }
    }

    /*
     * 查看是否早几小时
     */
    public static boolean afterHours(Date date, int hours) {
        if (date == null) {
            return false;
        }

        Calendar levelDay = Calendar.getInstance();
        Calendar createDay = Calendar.getInstance();

        createDay.setTime(date);
        createDay.add(Calendar.HOUR, hours);

        if (createDay.after(levelDay)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 取得系统当前日期
     */
    public static Date getCurrentTime() {
        return new Date();
    }

    /**
     * 返回多少时间的前的时间, seconds 可以是负的
     *
     * @param when
     * @param seconds
     */
    public static Date addTime(Date when, int seconds) {
        Calendar c = Calendar.getInstance();

        c.setTime(when);
        c.add(Calendar.SECOND, seconds);

        return c.getTime();
    }

    /**
     * 获得当前时间
     *
     * @return
     */
    public static final Date currentTime() {

        return new Date();
    }

    public static long currentTimeMillis() {
        return System.currentTimeMillis();
    }

    /**
     * 检查日期是否在n天以内
     *
     * @param d
     * @param n
     * @return
     */
    public static boolean dateInRange(Date d, int n) {
        if (n < 0) {
            return false;
        }
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR, 0);
        c.set(Calendar.AM_PM, Calendar.AM);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        c.add(Calendar.DAY_OF_YEAR, 1 - n);
        return !c.getTime().after(d);
    }

    /**
     * 显示过去对于现在的时间偏移，如：刚刚、3天前等
     *
     * @param time
     * @return
     */
    public static final String getPastForNow(long time) {
        String distance = "";
        long now = System.currentTimeMillis();
        long dis = now - time;

        long oneSecond = 1000;
        long oneMinute = oneSecond * 60;
        long oneHour = oneMinute * 60;
        long oneDay = oneHour * 24;
        long oneWeek = oneDay * 7;
        long oneMonth = oneDay * 30;
        if (dis < 2000) {
            distance = "刚刚";
        } else if (dis / oneMinute < 1) {
            distance = String.valueOf(dis / oneSecond) + "秒前";
        } else if (dis / oneHour < 1) {
            distance = String.valueOf(dis / oneMinute) + "分钟前";
        } else if (dis / oneDay < 1) {
            distance = String.valueOf(dis / oneHour) + "小时前";
        } else if (dis / oneWeek < 1) {
            distance = String.valueOf(dis / oneDay) + "天前";
        } else if (dis / oneMonth < 1) {
            distance = String.valueOf(dis / oneWeek) + "周前";
        } else if (dis / oneMonth < 2) {
            distance = String.valueOf(dis / oneMonth) + "月前";
        } else {
            distance = new SimpleDateFormat("yyyy年MM月dd日").format(new Date(time));
        }
        return distance;
    }

    /**
     * 显示过去对于现在的时间偏移，如：刚刚、3天前等
     *
     * @param then
     * @return
     */
    public static final String getPastForNow(Date then) {
        Calendar thenCalendar = Calendar.getInstance();
        thenCalendar.setTime(then);

        Calendar nowCalendar = Calendar.getInstance();

        int nowYear = nowCalendar.get(Calendar.YEAR);
        int thenYear = thenCalendar.get(Calendar.YEAR);
        int thenMonth = thenCalendar.get(Calendar.MONTH) + 1;
        int nowDay = nowCalendar.get(Calendar.DATE);
        int nowHour = nowCalendar.get(Calendar.HOUR_OF_DAY);
        int thenDay = thenCalendar.get(Calendar.DATE);
        int thenHour = thenCalendar.get(Calendar.HOUR_OF_DAY);
        int thenMinute = thenCalendar.get(Calendar.MINUTE);
        long dis = nowCalendar.getTimeInMillis() - thenCalendar.getTimeInMillis();

        if (nowYear > thenYear) {
            return String.valueOf(thenYear) + '-' + thenMonth + '-' + thenDay + ' ' + thenHour + ':'
                    + (thenMinute >= 10 ? thenMinute : "0" + thenMinute);
        } // end if
        if (dis > 172800000 || (dis > 86400000 && nowHour < thenHour)) { // 两天的毫秒数: 2*24*60*60*1000 = 172800000
            return thenMonth + "月" + thenDay + "日" + ' ' + thenHour + ':'
                    + (thenMinute >= 10 ? thenMinute : "0" + thenMinute);
        } // end if
        if (dis > 86400000 || nowDay != thenDay) { // 一天的毫秒数: 24*60*60*1000 = 86400000
            return "昨天" + ' ' + thenHour + ':' + (thenMinute >= 10 ? thenMinute : "0" + thenMinute);
        } // end if
        if (dis > 3600000) { // 一小时的毫秒数: 60*60*1000 = 3600000
            return "今天" + ' ' + thenHour + ':' + (thenMinute >= 10 ? thenMinute : "0" + thenMinute);
        } // end if
        if (dis > 60000) { // 一分钟的毫秒数: 60*1000 = 60000
            return (dis) / 60000 + "分钟前";
        } // end if
        return "刚刚";

    }

    /**
     * 显示现在对将来的时间表现，如：1分钟、3天等，通常用于生日提醒等
     *
     * @param time
     * @return
     */
    public static final String getNowForFuture(long time) {
        String distance = "";
        long now = System.currentTimeMillis();

        long dis = time - now;

        long oneSecond = 1000;
        long oneMinute = oneSecond * 60;
        long oneHour = oneMinute * 60;
        long oneDay = oneHour * 24;
        long oneWeek = oneDay * 7;
        long oneMonth = oneDay * 30;
        long oneYear = oneMonth * 12;

        if (dis / oneMinute < 1) {
            distance = String.valueOf(dis / oneSecond) + "秒";
        } else if (dis / oneHour < 1) {
            distance = String.valueOf(dis / oneMinute) + "分钟";
        } else if (dis / oneDay < 1) {
            distance = String.valueOf(dis / oneHour) + "小时";
        } else if (dis / oneWeek < 1) {
            distance = String.valueOf(dis / oneDay) + "天";
        } else if (dis / oneMonth < 1) {
            distance = String.valueOf(dis / oneWeek) + "周";
        } else if (dis / oneMonth < 12) {
            distance = String.valueOf(dis / oneMonth) + "月";
        } else if (dis / oneYear < 2) {
            distance = String.valueOf(dis / oneYear) + "年";
        }
        return distance;
    }

}
