package app.campus.heart.com.campus;

import android.app.Application;
import android.content.Context;
import android.util.DisplayMetrics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 全局配置，CampusApplication
 *
 * @author: Veyron
 * @date：2017/11/28
 */

public class CampusApplication extends Application {

    //屏幕的高
    public static int H;

    @Override
    public void onCreate() {
        super.onCreate();

        //初始化Banner
        initScreenH();
    }

    private void initScreenH() {
        H = getScreenH(this);
    }

    /**
     * 得到屏幕的高
     *
     * @param aty
     * @return
     */
    public int getScreenH(Context aty) {
        DisplayMetrics dm = aty.getResources().getDisplayMetrics();
        return dm.heightPixels;
    }

}
