package app.campus.heart.com.campus.data.model;


import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.api.UserApiService;
import app.campus.heart.com.campus.data.bean.RegisterRequestBean;
import rx.Observable;

/**
 * 实际发起网络注册
 *
 * @author: Veyron
 * @date：2017/11/21
 */

public class RegisterModel {

    private UserApiService mApiService;
    public RegisterModel(UserApiService apiService) {
        mApiService = apiService;
    }

    public Observable<Result<Long>> register(RegisterRequestBean bean){
       return mApiService.register(bean.getUserId(),
               bean.getName(),
               bean.getGender(),
               bean.getPassword(),
               bean.getPhone(),
               bean.getSchool(),
               bean.getSubject(),
               bean.getAddress());
    }
}
