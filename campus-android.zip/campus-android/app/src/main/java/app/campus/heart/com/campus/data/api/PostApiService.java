package app.campus.heart.com.campus.data.api;

import java.util.List;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.dto.ArticleItemDto;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import app.campus.heart.com.campus.data.dto.LabelDto;
import app.campus.heart.com.campus.data.dto.MyArticleItemDto;
import app.campus.heart.com.campus.data.dto.PostDto;
import app.campus.heart.com.campus.data.dto.PostTypeDto;
import app.campus.heart.com.campus.data.dto.TopArticleDto;
import app.campus.heart.com.campus.data.dto.UnreadDto;
import app.campus.heart.com.campus.data.dto.UpvoteItemDto;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;
import rx.Observable;

/**
 * Post 相关的 ApiService
 *
 * @author: Veyron
 * @date：2017/12/1
 */

public interface PostApiService {

    // 删除 我的帖子 的文章
    @POST("post/delete")
    Observable<Result<Boolean>> deleteItem(@Query("userId") String userId,
                                           @Query("password") String password,
                                           @Query("postId") Integer postId);

    // 我的帖子 模块，拉取所有自己发的帖子列表
    @GET("post/myLists")
    Observable<Result<PageList<MyArticleItemDto>>>
    getMyPostLists(@Query("userId") String userId,
                   @Query("postType") Integer postType,
                   @Query("page") Integer page);


    //获取所有主帖子类型
    @GET("postType/lists")
    Observable<Result<PageList<PostTypeDto>>> getAllPostType();


    // 根据帖子类别拉取帖子
    @GET("post/lists")
    Observable<Result<PageList<PostDto>>>
    getPostByType(@Query("postType") Integer postType);


    // 拉取所有帖子
    @GET("post/lists")
    Observable<Result<PageList<PostDto>>> getAllPost();

    // 根据用户学号和类别拉取相应帖子
    @GET("post/lists")
    Observable<Result<PageList<PostDto>>>
    getPostByUidAndType(@Query("userId") String userId
            , @Query("postType") Integer postType);


    // 用户发布帖子
    @POST("post")
    Observable<Result<Long>> doPost(@Body RequestBody body);


    // 用户删除自己的帖子
    @PUT("user")
    @FormUrlEncoded
    Observable<Result<Boolean>> deletePost(@Field("postId") Long postId,
                                           @Field("userId") String userId,
                                           @Field("password") String password);

    // 根据帖子 ID 获取具体帖子
    @GET("post")
    Observable<Result<PostDto>> getPostById(@Query("postId") Long postId);


    // 根据帖子类型拉取该板块头条帖子
    @GET("post/topArticle")
    Observable<Result<List<TopArticleDto>>> getTopArticle
    (@Query("postType") int postType);


    // 主页根据用户 ID 拉取该系统推荐帖子
    @GET("post/hotItem")
    Observable<Result<PageList<HotItemDto>>> getHotItemList
    (@Query("userId") String userId
            , @Query("page") Integer page);

    // 根据类别ID拉取相应界面
    @GET("post/list")
    Observable<Result<PageList<ArticleItemDto>>> getArticleItemList
    (@Query("postType") Integer postType,
     @Query("page") Integer page);


    // 发帖模块拉取所有兴趣标签
    @GET("post/labels")
    Observable<Result<PageList<LabelDto>>> getPostLabelType();

    //增加不感兴趣操作
    @POST("post/noInterest")
    Observable<Result<Boolean>> addNoInterest(@Query("userId") String userId,
                                              @Query("postId") Integer postId);

    // 主页根据用户 ID 拉取该系统推荐帖子
    @GET("post/CampusHeadLines")
    Observable<Result<PageList<HotItemDto>>> getCampusHeadLines
    (@Query("page") Integer page);


    // 主页根据用户 ID 拉取【点赞我的】模块下的帖子
    @GET("post/myUpvote")
    Observable<Result<PageList<UpvoteItemDto>>> getUserUpvote
    (@Query("page") Integer page, @Query("userId") String userId);

    // 主页根据用户 ID 拉取【我的收藏】模块下的帖子
    @GET("post/myCollect")
    Observable<Result<PageList<HotItemDto>>> getCollect
    (@Query("page") Integer page, @Query("userId") String userId);

    // 验证用户权限功能
    @GET("post/authorization")
    Observable<Result<Boolean>> getAuthorization();


    // 获取用户未读评论数
    @GET("post/getUnreadCommentCount")
    Observable<Result<Integer>> getUnreadCommentCount();

    // 获取用户未读点赞数
    @GET("post/getUnreadUpvoteCount")
    Observable<Result<Integer>> getUnreadUpvoteCount();

    //获取未读消息
    @GET("post/getUnreadCount")
    Observable<Result<UnreadDto>> getUnreadCount();


}
