package app.campus.heart.com.campus.common.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Base64;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.dto.UserDto;

/**
 * SharedPreferences 工具类，用于存储复杂对象
 *
 * @author: Veyron
 * @date：2017/12/28
 */

public class SharePresUtil {


    /**
     * 将登录后返回的用户信息存储起来
     *
     * @param context
     * @param object
     * @param key
     * @return
     */
    public static boolean setObject2SharePres(Context context, Object object,
                                              String key) {
        SharedPreferences share = PreferenceManager
                .getDefaultSharedPreferences(context);
        if (object == null) {
            SharedPreferences.Editor editor = share.edit().remove(key);
            return editor.commit();
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(baos);
            oos.writeObject(object);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        // 将对象放到OutputStream中
        // 将对象转换成byte数组，并将其进行base64编码
        String objectStr = new String(Base64.encode(baos.toByteArray(),
                Base64.DEFAULT));
        try {
            baos.close();
            oos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        SharedPreferences.Editor editor = share.edit();
        // 将编码后的字符串写到base64.xml文件中
        editor.remove(key);
        editor.putString(key, objectStr);
        return editor.commit();
    }

    /**
     * 获取登录用户的数据
     *
     * @param context
     * @param key
     * @return
     */
    public static Object getObjectFromSharePres(Context context, String key) {
        SharedPreferences sharePre = PreferenceManager
                .getDefaultSharedPreferences(context);
        try {
            String wordBase64 = sharePre.getString(key, "");
            // 将base64格式字符串还原成byte数组
            if (wordBase64 == null || wordBase64.equals("")) { // 不可少，否则在下面会报java.io.StreamCorruptedException
                return null;
            }
            byte[] objBytes = Base64.decode(wordBase64.getBytes(),
                    Base64.DEFAULT);
            ByteArrayInputStream bais = new ByteArrayInputStream(objBytes);
            ObjectInputStream ois = new ObjectInputStream(bais);
            // 将byte数组转换成 product 对象
            Object obj = ois.readObject();
            bais.close();
            ois.close();
            return obj;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获取缓存中的BannerImage
     *
     * @param context
     * @return
     */
    public static List<String> getBannerImageList(Context context) {
        if (SharePresUtil.getObjectFromSharePres(context, "userObject") == null) {
            return null;
        }
        String userId = ((Result<UserDto>) SharePresUtil.getObjectFromSharePres(context, "userObject")).getContent().getUserId();
        if (SharePresUtil.getObjectFromSharePres(context, "MainBannerImageList" + userId) != null) {
            return (List<String>) SharePresUtil.getObjectFromSharePres(context, "MainBannerImageList" + userId);
        }
        return null;
    }

    /**
     * 设置缓存中的BannerImage
     *
     * @param context
     * @return
     */
    public static void setBannerImageList(Context context, List<String> list) {
        SharePresUtil.setObject2SharePres(context, list, "MainBannerImageList");
    }

    /**
     * 获取缓存中的BannerTitle
     *
     * @param context
     * @return
     */
    public static List<String> getBannerTitleList(Context context) {
        if (SharePresUtil.getObjectFromSharePres(context, "userObject") == null) {
            return null;
        }
        String userId = ((Result<UserDto>) SharePresUtil.getObjectFromSharePres(context, "userObject")).getContent().getUserId();
        if (SharePresUtil.getObjectFromSharePres(context, "MainBannerTitleList" + userId) != null) {
            return (List<String>) SharePresUtil.getObjectFromSharePres(context, "MainBannerTitleList" + userId);
        }
        return null;
    }

    /**
     * 设置缓存中的BannerTitle
     *
     * @param context
     * @return
     */
    public static void setBannerTitleList(Context context, List<String> list) {
        SharePresUtil.setObject2SharePres(context, list, "MainBannerTitleList");
    }

    public static Integer getUnreadComment(Context context) {
        if (SharePresUtil.getObjectFromSharePres(context, "userObject") == null) {
            return null;
        }
        String userId = ((Result<UserDto>) SharePresUtil.getObjectFromSharePres(context, "userObject")).getContent().getUserId();
        if (SharePresUtil.getObjectFromSharePres(context, "unread_comment_" + userId) != null) {
            return (Integer) SharePresUtil.getObjectFromSharePres(context, "unread_comment_" + userId);
        }
        return null;

    }

    public static void setUnreadComment(Context context, Integer count) {
        if (SharePresUtil.getObjectFromSharePres(context, "userObject") != null) {
            String userId = ((Result<UserDto>) SharePresUtil.getObjectFromSharePres(context, "userObject")).getContent().getUserId();
            SharePresUtil.setObject2SharePres(context, count, "unread_comment_" + userId);
        }
    }

    public static Integer getUnreadUpvote(Context context) {
        if (SharePresUtil.getObjectFromSharePres(context, "userObject") == null) {
            return null;
        }
        String userId = ((Result<UserDto>) SharePresUtil.getObjectFromSharePres(context, "userObject")).getContent().getUserId();
        if (SharePresUtil.getObjectFromSharePres(context, "unread_upvote_" + userId) != null) {
            return (Integer) SharePresUtil.getObjectFromSharePres(context, "unread_upvote_" + userId);
        }
        return null;
    }

    public static void setUnreadUpvote(Context context, Integer count) {
        if (SharePresUtil.getObjectFromSharePres(context, "userObject") != null) {
            String userId = ((Result<UserDto>) SharePresUtil.getObjectFromSharePres(context, "userObject")).getContent().getUserId();
            SharePresUtil.setObject2SharePres(context, count, "unread_upvote_" + userId);
        }
    }

}
