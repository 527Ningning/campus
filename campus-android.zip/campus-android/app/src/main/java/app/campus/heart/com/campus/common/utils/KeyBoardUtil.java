package app.campus.heart.com.campus.common.utils;

import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

/**
 * @author: Veyron
 * @date：2018/1/2
 */

public class KeyBoardUtil {

    /**
     * 隐藏软键盘
     */
    public static void hideSoftInputMethod(Activity act) {
        View view = act.getWindow().peekDecorView();
        if (view != null) {
            // 隐藏虚拟键盘
            InputMethodManager inputmanger = (InputMethodManager) act
                    .getSystemService(act.INPUT_METHOD_SERVICE);
            inputmanger.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    /**
     * 显示软键盘
     */
    public static void showSoftInputMethod(Activity act){
        View view = act.getWindow().peekDecorView();
        if (view != null){
            InputMethodManager imm = (InputMethodManager) view.getContext()
                    .getSystemService(act.INPUT_METHOD_SERVICE);
            if (imm != null){
                view.requestFocus();
                imm.showSoftInput(view,0);
            }
        }
    }
}
