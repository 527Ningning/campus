package app.campus.heart.com.campus.ui.customs;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import app.campus.heart.com.campus.R;

/**
 * @author: Veyron
 * @date：2018/01/10
 */
public class PostListViewHolder extends RecyclerView.ViewHolder {
    public TextView title, date, visitCount, upvoteCount,
            commentCount, big_type, small_type, delete;

    public LinearLayout layout;

    public PostListViewHolder(View view) {
        super(view);
        layout = (LinearLayout) view.findViewById(R.id.item_layout);
        title = (TextView) view.findViewById(R.id.title_common);
        date = (TextView) view.findViewById(R.id.date_common);
        big_type = (TextView) view.findViewById(R.id.big_type);
        small_type = (TextView) view.findViewById(R.id.small_type);
        visitCount = (TextView) view.findViewById(R.id.visitCount_common);
        upvoteCount = (TextView) view.findViewById(R.id.upvoteCount_common);
        commentCount = (TextView) view.findViewById(R.id.commentCount_common);
        delete = (TextView) view.findViewById(R.id.click_delete);
    }
}
