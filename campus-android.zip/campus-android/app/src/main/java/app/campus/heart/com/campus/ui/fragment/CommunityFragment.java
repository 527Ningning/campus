package app.campus.heart.com.campus.ui.fragment;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.listener.OnBannerListener;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.enums.ModuleEnum;
import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.common.utils.StringUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.AdvertPresenter;
import app.campus.heart.com.campus.controller.persenter.PostPresenter;
import app.campus.heart.com.campus.data.dto.AdvertDto;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import app.campus.heart.com.campus.data.dto.UserDto;
import app.campus.heart.com.campus.data.model.UserModel;
import app.campus.heart.com.campus.ui.activity.AdvertActivity;
import app.campus.heart.com.campus.ui.activity.ArticleActivity;
import app.campus.heart.com.campus.ui.activity.BaikeActivity;
import app.campus.heart.com.campus.ui.activity.FindActivity;
import app.campus.heart.com.campus.ui.activity.Jobctivity;
import app.campus.heart.com.campus.ui.activity.LoginActivity;
import app.campus.heart.com.campus.ui.activity.MarketActivity;
import app.campus.heart.com.campus.ui.activity.ModuleActivity;
import app.campus.heart.com.campus.ui.activity.MoreActivity;
import app.campus.heart.com.campus.ui.activity.PlayingActivity;
import app.campus.heart.com.campus.ui.activity.SearchActivity;
import app.campus.heart.com.campus.ui.activity.StudyingActivity;
import app.campus.heart.com.campus.ui.activity.TalkingAnywayActivity;
import app.campus.heart.com.campus.ui.activity.WorkActivity;
import app.campus.heart.com.campus.ui.adapter.RecycleViewDivider;
import app.campus.heart.com.campus.ui.adapter.RecommendRviewAdapter;
import app.campus.heart.com.campus.ui.customs.CustomsImageLoader;
import app.campus.heart.com.campus.ui.fragment.base.BaseFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * CommunityFragment，主页第一个栏目：社区
 *
 * @author: yuwu
 * @date：2017/11/22
 */

public class CommunityFragment extends BaseFragment
        implements SwipeRefreshLayout.OnRefreshListener
        , OnBannerListener {

    @BindView(R.id.banner)
    Banner mBanner;
    @BindView(R.id.main_qgjx)
    TextView mMainQgjx;
    @BindView(R.id.main_2sjy)
    TextView mMain2sjy;
    @BindView(R.id.main_forjob)
    TextView mMainForjob;
    @BindView(R.id.main_xsdt)
    TextView mMainXsdt;
    @BindView(R.id.main_talking)
    TextView mMainTalking;
    @BindView(R.id.main_playing)
    TextView mMainPlaying;
    @BindView(R.id.main_why)
    TextView mMainWhy;
    @BindView(R.id.main_bbx)
    TextView mMainBbx;
    @BindView(R.id.swipe)
    SwipeRefreshLayout mSwipe;

    @BindView(R.id.searchEdit)
    SearchView mSearchView;

    @BindView(R.id.action_search)
    LinearLayout mLinnerLayoutSearch;

    @BindView(R.id.hot_postlist)
    RecyclerView mHotPostlist;

    RecommendRviewAdapter mAdapter;
    List<HotItemDto> mList = new ArrayList<>();
    PostPresenter mPresenter;
    PostPresenter mPresenterDelete;
    @BindView(R.id.scrollView)
    NestedScrollView mScrollView;

    private static final OkHttpClient client = new OkHttpClient.Builder().
            connectTimeout(60, TimeUnit.SECONDS).
            readTimeout(60, TimeUnit.SECONDS).
            writeTimeout(60, TimeUnit.SECONDS).build();

    private Result<UserDto> mUserModel;//用户ID
    private List<AdvertDto> mAdvertDataList;
    private String tmpUserId = "112016321030905";
    private boolean isLoading = false;  //判断是否加载更多，避免重复请求网络
    private boolean isLoadingNext = false;//判断属于下拉加载还是上拉刷新
    private Boolean isLogined = false;
    private Integer currentPage = 1;
    private Integer nextPage = 1;
    private Integer lastPage = 1;

    //创建一个线性布局管理器
    LinearLayoutManager layoutManager;
    private Handler handler = new Handler();

    private int index = 1;

    private Retrofit retrofit;
    private AdvertPresenter mAdvertPresenter;

    @Override
    protected View initView() {
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        View view = mInflater.inflate(R.layout.fragment_layout_community, null);

        return view;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO: inflate a fragment view
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        ButterKnife.bind(this, rootView);


        mSwipe.setOnRefreshListener(this);
        mSwipe.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimary, R.color.colorPrimaryDark);

        return rootView;
    }

    @Override
    protected void initData() {
        super.initData();

        setOldBannerDatas();

        initRetrofit();

        initBanner();

        initUserData();

        initSearch();

        layoutManager = new LinearLayoutManager(getContext());
        mHotPostlist.setLayoutManager(layoutManager);
        mHotPostlist.setFocusable(false); // 取消列表的焦点，解决切换fragment时自动下滑列表导致的bug
        //添加分割线
        mHotPostlist.addItemDecoration(new RecycleViewDivider(getContext(), R.drawable.divider_mileage));
        mHotPostlist.setNestedScrollingEnabled(false);//解决滑动缓慢问题

        ((SimpleItemAnimator) mHotPostlist.getItemAnimator())
                .setSupportsChangeAnimations(false);  //解决刷新抖动问题

        // 对 mScrollView 的滑动监听
        if (mScrollView != null) {
            mScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
                @Override
                public void onScrollChange(NestedScrollView v, int scrollX,
                                           int scrollY, int oldScrollX, int oldScrollY) {
                    if (scrollY > oldScrollY) {
                        LogUtil.E("下滑...");
                    }
                    if (scrollY < oldScrollY) {
                        LogUtil.E("上滑");
                    }

                    if (scrollY == 0) {
                        LogUtil.E("滑动到顶部");
                    }

                    if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {
                        LogUtil.E("滑动到底部");

                        // 当前屏幕所看到的子项个数
                        int lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition();
                        // 再次判断是否滑动到 recycleView 显示当前页数据的底部
                        if (lastVisibleItemPosition + 1 == mAdapter.getItemCount()) {
                            //已经滑动到最下面
                            if (!isLoading) {
                                isLoading = true;
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        isLoading = false;
                                        loadMoreData();
                                    }
                                }, 10);
                            }
                        }
                    }

                }
            });
        }
        initHotItemList();

        mScrollView.setFocusable(true);
        mScrollView.setFocusableInTouchMode(true);
        mScrollView.requestFocus();
        mScrollView.scrollTo(0, 0);  // 保证滑动到顶部
    }

    private void initUserData() {
        if (SharePresUtil.getObjectFromSharePres(mContext, "userObject") != null) {
            mUserModel = (Result<UserDto>) SharePresUtil.getObjectFromSharePres(mContext, "userObject");
            if (mUserModel != null && mUserModel.getContent() != null && mUserModel.getContent().getUserId() != null) {
                tmpUserId = mUserModel.getContent().getUserId();
                isLogined = true;
            }
        }
    }

    private void initSearch() {
        mSearchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            //输入完成后，提交时触发的方法，一般情况是点击输入法中的搜索按钮才会触发，表示现在正式提交了
            public boolean onQueryTextSubmit(String query) {
                if (StringUtil.isBlank(query)) {
                    Toast.makeText(mContext, "请输入查找内容！", Toast.LENGTH_SHORT).show();
                    //listView.setAdapter(adapter);
                } else {
                    Intent intent = new Intent(mContext, SearchActivity.class);
                    if (isLogined) {
                        intent.putExtra("userId", tmpUserId);
                        intent.putExtra("isLogined", true);
                        intent.putExtra("key", query);
                        startActivity(intent);
                    }
                }
                return true;
            }

            //在输入时触发的方法，当字符真正显示到searchView中才触发，像是拼音，在输入法组词的时候不会触发
            public boolean onQueryTextChange(String newText) {
                return true;
            }
        });
    }

    private void initBanner() {
        mAdvertPresenter = new AdvertPresenter(new CallBack<PageList<AdvertDto>>() {
            @Override
            public void showResult(Result<PageList<AdvertDto>> result) {
                // 拿到广告数据
                mAdvertDataList = new ArrayList<>();
                mAdvertDataList = result.getContent().getDataList();
                List<String> titleList = new ArrayList<>();
                List<String> imageList = new ArrayList<>();
                for (int i = 0; i < mAdvertDataList.size(); i++) {
                    titleList.add(mAdvertDataList.get(i).getTitle());
                    imageList.add(mAdvertDataList.get(i).getCoverImg());
                }

                setBannerDatas(imageList, titleList);
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {
                LogUtil.E(msg);
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E(msg);
            }
        }, retrofit);
        mAdvertPresenter.getAdvertDatas();
    }

    private void setBannerDatas(List<String> imageList
            , List<String> titleList) {
        //默认是CIRCLE_INDICATOR
        mBanner.setImages(imageList)
                .setBannerTitles(titleList)
                .setBannerStyle(BannerConfig.CIRCLE_INDICATOR_TITLE)
                .setImageLoader(new CustomsImageLoader())
                .setOnBannerListener(this)
                .start();
        SharePresUtil.setBannerImageList(mContext, imageList);
        SharePresUtil.setBannerTitleList(mContext, titleList);
    }

    private void setOldBannerDatas() {
        if (SharePresUtil.getBannerImageList(mContext) != null && SharePresUtil.getBannerTitleList(mContext) != null) {
            mBanner.setImages(SharePresUtil.getBannerImageList(mContext))
                    .setBannerTitles(SharePresUtil.getBannerTitleList(mContext))
                    .setBannerStyle(BannerConfig.CIRCLE_INDICATOR_TITLE)
                    .setImageLoader(new CustomsImageLoader())
                    .setOnBannerListener(this)
                    .start();
        }
    }

    private void initRetrofit() {
        retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }

    private void initHotItemList() {
        mPresenter = new PostPresenter(new CallBack<PageList<HotItemDto>>() {
            @Override
            public void showResult(Result<PageList<HotItemDto>> result) {
                currentPage = result.getContent().getPaginator().getPage();
                nextPage = result.getContent().getPaginator().getNextPage();
                lastPage = result.getContent().getPaginator().getLastPage();

                if (currentPage == 1) {
                    mList = result.getContent().getDataList();
                    LogUtil.E("拉取的数据： " + mList.toString());
                    if (isLoadingNext) {
                        mAdapter.addAll(mList);
                        mAdapter.notifyItemChanged(1, 1);
                    } else {
                        mAdapter = new RecommendRviewAdapter(mContext, mList);
                        mHotPostlist.setAdapter(mAdapter);
                    }
                    isLoading = false;
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);

                    mAdapter.setOnItemClickListener(new RecommendRviewAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, int position) {
                            //点击事件
                            if (SharePresUtil.getObjectFromSharePres
                                    (mContext, "userObject") == null) {
                                Toast.makeText(mContext,
                                        "您未登录,请先登录", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(
                                        mContext, LoginActivity.class));

                            } else {
                                if (position < mAdapter.getList().size()) {
                                    Long postId = mAdapter.getList().get(position).getPostId();
                                    LogUtil.E("Hot 点击事件" + postId);
                                    Intent intent = new Intent(getActivity(), ArticleActivity.class);
                                    intent.putExtra("postId", postId);
                                    startActivity(intent);
                                }
                            }
                        }

                        @Override
                        public void onItemLongClick(View view, final int position) {
                            if (SharePresUtil.getObjectFromSharePres
                                    (mContext, "userObject") == null) {
                                Toast.makeText(mContext,
                                        "您未登录,请先登录", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(
                                        mContext, LoginActivity.class));

                            } else {
                                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                                builder.setTitle("请确认");
                                builder.setMessage("您是对这个帖子不感兴趣么?");
                                builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //Toast.makeText(mContext, "取消", Toast.LENGTH_SHORT).show();
                                    }
                                });
                                builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //Toast.makeText(mContext, "确定", Toast.LENGTH_SHORT).show();
                                        //mAdapter.removeItem(position);
                                        Long postId = mAdapter.getList().get(position).getPostId();
                                        deleteItem(position, tmpUserId, postId.intValue());
                                    }
                                });
                                AlertDialog dialog = builder.create();
                                dialog.show();
                            }
                        }
                    });

                } else if (currentPage < result.getContent().getPaginator().getPages()) {
                    LogUtil.E("更新推荐数据中");
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);
                    //mAdapter.notifyDataSetChanged();
                    mAdapter.notifyItemChanged(1, 1);
                    isLoading = false;
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);
                } else if (currentPage == lastPage) {
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);

                    //mAdapter.notifyDataSetChanged();
                    mAdapter.notifyItemChanged(1, 1);
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);
                }
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {
                LogUtil.E("错误信息： " + msg.toString());
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E("成功信息： " + msg.toString());
            }
        }, retrofit);

        getData();
    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.E("onResume()方法");
        //mScrollView.scrollTo(0, 0);  // 保证滑动到顶部
    }

    @Override
    public void onStart() {
        super.onStart();
        LogUtil.E("onStart()方法");
        //mScrollView.scrollTo(0, 0);       // 保证滑动到顶部
    }

    @Override
    public void onHiddenChanged(boolean hidd) {
        if (!hidd) {//当fragment从隐藏到出现的时候
            LogUtil.E("切换到当前fragment，onHiddenChanged()方法监听");
            //mScrollView.scrollTo(0, 0);
        }
    }

    @Override
    public void OnBannerClick(int position) {
        //Toast.makeText(getActivity(), "Banner点击事件" + position, Toast.LENGTH_SHORT).show();
        if (mAdvertDataList.size() != 0 && mAdvertDataList.size() >= position) {
            Intent intent = new Intent(getActivity(), AdvertActivity.class);
            intent.putExtra("advertUrl", mAdvertDataList.get(position).getUrl());
            startActivity(intent);
        }
    }


    /**
     * 对主页 8 个 分类的点击监听事件
     *
     * @param view
     */
    @OnClick({R.id.main_qgjx, R.id.main_2sjy, R.id.main_forjob, R.id.main_xsdt, R.id.main_talking, R.id.main_playing, R.id.main_why, R.id.main_bbx})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.main_qgjx:
                // 勤工俭学
                goToModule(ModuleEnum.勤工俭学);
                break;
            case R.id.main_2sjy:
                // 二手市场
                goToModule(ModuleEnum.二手市场);
                break;
            case R.id.main_forjob:
                // 求职天地
                goToModule(ModuleEnum.求职天地);
                break;
            case R.id.main_xsdt:
                // 学术殿堂
                goToModule(ModuleEnum.学术殿堂);
                break;
            case R.id.main_talking:
                // 七嘴八舌
                goToModule(ModuleEnum.七嘴八舌);
                break;
            case R.id.main_playing:
                // 约喝约玩
                goToModule(ModuleEnum.约喝约玩);
                break;
            case R.id.main_why:
                // 失物招领
                goToModule(ModuleEnum.失物招领);
                break;
            case R.id.main_bbx:
                // 更多模块
                Intent intent8 = new Intent(getActivity(), MoreActivity.class);
                startActivity(intent8);
                break;
        }
    }

    /**
     * 刷新回调方法
     */
    @Override
    public void onRefresh() {
        // 开始刷新，设置当前为刷新状态
        mSwipe.setRefreshing(true);

        isLoadingNext = false;

        isLoading = false;

        // 下拉刷新操作：获取新数据
        getData();

    }

    private void getData() {

        LogUtil.E("刷新数据");
        if (!mList.isEmpty()) {
            mList.clear();
        }
        //Toast.makeText(getActivity(), "正在为您推荐", Toast.LENGTH_SHORT).show();
        mPresenter.getHotItemList(tmpUserId, null);
        mSwipe.setRefreshing(false);
        index = 1;
    }


    private void loadMoreData() {
        index++;

        isLoadingNext = true;
        //Toast.makeText(getActivity(), "为您推荐下一页", Toast.LENGTH_SHORT).show();
        if (index > lastPage) {
            LogUtil.E("已经没有新的了");
            //Toast.makeText(mContext, "已经没有新的了", Toast.LENGTH_SHORT).show();
            mAdapter.notifyItemRemoved(mAdapter.getItemCount());
            //mSwipe.setRefreshing(false);
        } else {
            LogUtil.E("加载更多数据");
            mPresenter.getHotItemList(tmpUserId, nextPage);
            //mSwipe.setRefreshing(false);
        }
        mPresenter.getHotItemList(tmpUserId, nextPage);
    }

    private void deleteItem(final int position, String userId, Integer postId) {
        mPresenterDelete = new PostPresenter(new CallBack() {
            @Override
            public void showResult(Result result) {

            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {

            }

            @Override
            public void showSuccess(String msg) {

            }
        }, retrofit);
        mPresenterDelete.addNoInterest(userId, postId);
        mAdapter.removeItem(position);
    }

    @OnClick(R.id.action_search)
    public void onClick() {
        Intent intent = new Intent(mContext, SearchActivity.class);
        if (isLogined) {
            intent.putExtra("userId", tmpUserId);
            intent.putExtra("isLogined", true);
            startActivity(intent);
        }
    }

    public void goToModule(ModuleEnum moduleEnum) {
        Intent intent = new Intent(mContext, ModuleActivity.class);
        intent.putExtra("postType", moduleEnum.getValue());
        intent.putExtra("moduleName", moduleEnum.getModuleName());
        startActivity(intent);
    }
}
