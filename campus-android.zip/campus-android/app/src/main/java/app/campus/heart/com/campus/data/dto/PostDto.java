package app.campus.heart.com.campus.data.dto;

import app.campus.heart.com.campus.common.domain.AbstractModel;

/**
 * 帖子模型类
 *
 * @author: yuwu
 * @date: 2017/11/23
 */
public class PostDto extends AbstractModel {
    /**
     * 帖子ID
     */
    private String postId;

    /**
     * 帖子类型ID
     */
    private Integer typeId;

    /**
     * 帖子标题
     */
    private String title;

    /**
     * 用户学号
     */
    private String userId;

    /**
     * 帖子内容
     */
    private String content;

    /**
     * 帖子优先级
     */
    private Integer priority;

    /**
     * 帖子点赞数
     */
    private Integer upvoteCount;

    /**
     * 帖子浏览次数
     */
    private Integer visitCount;

    /**
     * 黑白名单标志位
     */
    private Integer blackWhiteState;

    /**
     * 逻辑删除位
     */
    private Integer status;

    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Integer getUpvoteCount() {
        return upvoteCount;
    }

    public void setUpvoteCount(Integer upvoteCount) {
        this.upvoteCount = upvoteCount;
    }

    public Integer getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(Integer visitCount) {
        this.visitCount = visitCount;
    }

    public Integer getBlackWhiteState() {
        return blackWhiteState;
    }

    public void setBlackWhiteState(Integer blackWhiteState) {
        this.blackWhiteState = blackWhiteState;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "PostDto{" +
                "postId='" + postId + '\'' +
                ", typeId=" + typeId +
                ", title='" + title + '\'' +
                ", userId='" + userId + '\'' +
                ", UserDto='" + content + '\'' +
                ", priority=" + priority +
                ", upvoteCount=" + upvoteCount +
                ", visitCount=" + visitCount +
                ", blackWhiteState=" + blackWhiteState +
                ", status=" + status +
                '}';
    }
}
