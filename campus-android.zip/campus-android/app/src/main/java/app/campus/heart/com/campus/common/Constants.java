package app.campus.heart.com.campus.common;

/**
 * 常量
 *
 * @author: Veyron
 * @date：2017/11/22
 */
public class Constants {

    public static final String BASE_HEADER_URL = "https://www.swu-ioeai.com/";
    //public static final String BASE_HEADER_URL = "http://192.168.1.109:8999";
    public static final String BASE_URL = BASE_HEADER_URL + "app/";
    //public static final String BASE_URL = "http://47.89.17.96:8999/app/";
    //public static final String BASE_URL = "http://192.168.1.109:8999/app/";
    public static final String BASE_URL_PREF = "http://192.168.1.109:8999";
    public static final String ACCOUNT_LOGIN_URL = BASE_URL + "user/";
    public static final String ACCOUNT_REGISTER_URL = BASE_URL + "user/";
    //软件更新下载安装包的路径
    public static final String DOWNLOAD_DIR = "/sdcard/test/";

    public static final String AUTHORIZATION = "Authorization";

    public static final String TAKEN_ID = "tokenId";

    public static final String POSTTYPE = "postType";

    //模块分组名称

}
