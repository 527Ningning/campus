package app.campus.heart.com.campus.ui.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bumptech.glide.Glide;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.change.TimeUtil;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.StringUtil;
import app.campus.heart.com.campus.data.dto.MyCommentDto;
import app.campus.heart.com.campus.data.dto.UpvoteItemDto;
import app.campus.heart.com.campus.ui.customs.CommentListViewHolder;
import app.campus.heart.com.campus.ui.customs.PostListViewHolder;
import jp.wasabeef.glide.transformations.CropCircleTransformation;


/**
 * 给使用 recyclerview 准备的适配器
 *
 * @author: veyron
 * @date：2018/02/03
 */


public class UpvotesRviewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_NULL = 0;
    private static final int TYPE_FOOTER = 1;
    private static final int TYPE_NORMAL = 2;

    private Context context;
    private List<UpvoteItemDto> list = new ArrayList<>();
    private static Boolean isShowLoading = true;

    public void setLoadingFooter(Boolean is) {
        isShowLoading = is;
    }

    public void addAll(List<UpvoteItemDto> list) {
        this.list.addAll(list);
    }

    public List<UpvoteItemDto> getList() {
        return list;
    }

    public UpvotesRviewAdapter(Context context, List<UpvoteItemDto> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getItemCount() {
        return list.size() == 0 ? 0 : list.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (isShowLoading) {
            if (position + 1 == getItemCount())
                return TYPE_FOOTER;
        }
        if (position + 1 == getItemCount())
            return TYPE_NULL;

        return TYPE_NORMAL;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_FOOTER) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_footer, parent,
                    false);
            return new FootViewHolder(view);
        }
        if (viewType == TYPE_NULL) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_null_footer, parent,
                    false);
            return new FootViewHolder(view);
        }
        View view = LayoutInflater.from(context).inflate(R.layout.item_myupvotes, parent,
                false);
        return new CommentListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position, List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);
        if (holder instanceof CommentListViewHolder) {
            UpvoteItemDto mMyCommentDto = list.get(position);
            // 设置 数据

            try {
                ((CommentListViewHolder) holder).date.setText(TimeUtil.getGap(mMyCommentDto.getDate()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            //((CommentListViewHolder) holder).date.setText(mMyCommentDto.getDate());


            ((CommentListViewHolder) holder).common1.setText(mMyCommentDto.getUserName()
                    + "-" + mMyCommentDto.getSchool());
            // ((CommentListViewHolder) holder).common2.setText(mMyCommentDto.getReplyUserName()
            //+ "-" + mMyCommentDto.getReplyUserSchool());
            // ((CommentListViewHolder) holder).content.setText(mMyCommentDto.getContent());

            Glide.with(context).load(mMyCommentDto.getUserLogo())
                    .bitmapTransform(new CropCircleTransformation(context))
                    .override(20, 20)
                    .into(((CommentListViewHolder) holder).userIcon);
            Glide.with(context).load(mMyCommentDto.getCoverImg())
                    .into(((CommentListViewHolder) holder).coverImg);
//            if (!mMyCommentDto.getDeleteState()) {
//                ((CommentListViewHolder) holder).click_delete.setText("不可删除");
//                ((CommentListViewHolder) holder).click_delete.setClickable(false);
//               // ((CommentListViewHolder) holder).flag_delete.setVisibility(View.GONE);
//
//            }

//            if (mMyCommentDto.getReplyUserId() == null || StringUtil.isEmpty(mMyCommentDto.getReplyUserId())) {
//                ((CommentListViewHolder) holder).reply_layout.setVisibility(View.INVISIBLE);
//            }
        }
    }

    public void removeItem(int position) {
        LogUtil.E("position: " + position);
        LogUtil.E("getItemCount: " + getItemCount());
        if (getItemCount() == 2 && getItemCount() - 2 == position) {      // 删除最后一个的时候，特殊处理
            list.clear();
            notifyDataSetChanged();
        } else {
            list.remove(position);
            notifyItemRemoved(position);
            if (position != list.size()) {
                notifyItemRangeChanged(position, list.size() - position);
            }
        }
    }

    static class FootViewHolder extends RecyclerView.ViewHolder {
        public FootViewHolder(View view) {
            super(view);
            view.setFocusable(false);
            view.setClickable(false);
        }
    }

}
