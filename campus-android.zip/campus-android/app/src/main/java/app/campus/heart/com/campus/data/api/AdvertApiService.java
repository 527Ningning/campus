package app.campus.heart.com.campus.data.api;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.dto.AdvertDto;
import retrofit2.http.GET;
import rx.Observable;

/**
 * 封面广告数据接口
 * @author: Veyron
 * @date：2018/1/6
 */

public interface AdvertApiService {
    // 获取首页广告数据
    @GET("advert")
    Observable<Result<PageList<AdvertDto>>>
    getAdvertDatas();

    // 获取首页广告数据
    @GET("advert/campus")
    Observable<Result<PageList<AdvertDto>>>
    getCampusAdvertDatas();
}


