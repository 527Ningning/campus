package app.campus.heart.com.campus.common.change;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 转换时间
 *
 * @author: yuwu
 * @date: 2018/4/23
 */
public class TimeUtil {

    public static final SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static final SimpleDateFormat simpleFormatTwo = new SimpleDateFormat("yyyy-MM-dd");

    public static int getGapMinutes(String fromTime) throws ParseException {
        Date currentTime = new Date();
        String currentTimeString = simpleFormat.format(currentTime);
        long from = simpleFormat.parse(fromTime).getTime();
        long to = simpleFormat.parse(currentTimeString).getTime();
        int minutes = (int) ((to - from) / (1000 * 60));
        return minutes;
    }

    public static int getGapHours(String fromTime) throws ParseException {
        Date currentTime = new Date();
        String currentTimeString = simpleFormat.format(currentTime);
        long from = simpleFormat.parse(fromTime).getTime();
        long to = simpleFormat.parse(currentTimeString).getTime();
        int hours = (int) ((to - from) / (1000 * 60 * 60));
        return hours;
    }

    public static int getGapDays(String fromTime) throws ParseException {
        Date currentTime = new Date();
        String currentTimeString = simpleFormat.format(currentTime);
        long from = simpleFormat.parse(fromTime).getTime();
        long to = simpleFormat.parse(currentTimeString).getTime();
        int days = (int) ((to - from) / (1000 * 60 * 60 * 24));
        return days;
    }

    public static String getGap(String time) throws ParseException {
        String unit;
        int daysGap = getGapDays(time);
        if (daysGap > 3) {
            return time;
        }
        if (daysGap > 0) {
            unit = "天前";
            return daysGap + unit;
        }
        int hoursGap = getGapHours(time);
        if (hoursGap > 0) {
            unit = "小时前";
            return hoursGap + unit;
        }
        int minutesGap = getGapMinutes(time);
        if (minutesGap > 0) {
            unit = "分钟前";
            return minutesGap + unit;
        }
        unit = "刚刚";
        return unit;
    }


    public static String getGapHot(String time) throws ParseException {
        String unit;
        int daysGap = getGapDays(time);
        if (daysGap > 3) {
            return time.split(" ")[0];
        }
        if (daysGap > 0) {
            unit = "天前";
            return daysGap + unit;
        }
        int hoursGap = getGapHours(time);
        if (hoursGap > 0) {
            unit = "小时前";
            return hoursGap + unit;
        }
        int minutesGap = getGapMinutes(time);
        if (minutesGap > 0) {
            unit = "分钟前";
            return minutesGap + unit;
        }
        unit = "刚刚";
        return unit;
    }
}
