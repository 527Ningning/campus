package app.campus.heart.com.campus.data.model;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.api.UserApiService;
import app.campus.heart.com.campus.data.bean.LoginRequestBean;
import app.campus.heart.com.campus.data.dto.UserDto;
import app.campus.heart.com.campus.data.dto.UserLoginDto;
import rx.Observable;

/**
 * 实际发起登录的地方
 *
 * @author: Veyron
 * @date：2017/11/21
 */
public class LoginModel {

    private UserApiService mApiService;

    public LoginModel(UserApiService apiService) {
        mApiService = apiService;
    }

    public Observable<Result<UserLoginDto>> login(LoginRequestBean requestBean){

        return mApiService.login(requestBean.getUserId(),requestBean.getPassword());
    }
}
