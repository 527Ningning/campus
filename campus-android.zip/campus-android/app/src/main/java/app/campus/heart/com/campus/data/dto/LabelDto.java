package app.campus.heart.com.campus.data.dto;


import app.campus.heart.com.campus.common.domain.AbstractModel;

/**
 * @author: Veyron
 * @date：2018/1/4
 */

public class LabelDto extends AbstractModel {


    /**
     * 标签名字
     */
    private String label;

    /**
     * 删除标志位
     */
    private Integer status;

    @Override
    public void setId(Long id) {
        super.setId(id);
    }

    @Override
    public Long getId() {
        return super.getId();
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "LabelDto{" +
                "label='" + label + '\'' +
                ", status=" + status +
                '}'+ "id: "+getId();
    }
}

