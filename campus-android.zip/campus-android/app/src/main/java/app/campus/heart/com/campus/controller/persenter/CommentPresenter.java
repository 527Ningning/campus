package app.campus.heart.com.campus.controller.persenter;

import org.w3c.dom.Comment;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.contact.CallBackHandle;
import app.campus.heart.com.campus.data.api.CommentApiService;
import app.campus.heart.com.campus.data.dto.MyCommentDto;
import app.campus.heart.com.campus.data.model.CommentModel;
import retrofit2.Retrofit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * @author: Veyron
 * @date：2018/2/2
 */

public class CommentPresenter {
    private CommentModel mModel;
    private CommentApiService mApiService;
    private CallBack callBack;

    public CommentPresenter(Retrofit retrofit) {
        mApiService = retrofit.create(CommentApiService.class);
        mModel = new CommentModel(mApiService);
    }

    public CommentPresenter(CallBack callBack, Retrofit retrofit) {
        this.callBack = callBack;
        mApiService = retrofit.create(CommentApiService.class);
        mModel = new CommentModel(mApiService);
    }

    // 获取用户的 所有评论
    public void getAllComments(Integer page, String userId) {
        mModel.getAllComment(page, userId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<MyCommentDto>>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError("拉取评论列表失败:" + e.toString());
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onNext(Result<PageList<MyCommentDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.dimissLoading();
                            callBack.showSuccess("拉取 评论列表 成功");
                        } else {
                            callBack.showError("拉取 评论列表 失败");
                        }
                    }
                });
    }

    // 获取用户的 所有评论
    public void getAllCommentsNew(final CallBackHandle callBackHandle, Integer page, String userId) {
        mModel.getAllComment(page, userId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<MyCommentDto>>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        callBackHandle.showLinkError("连接中断失败");
                    }

                    @Override
                    public void onNext(Result<PageList<MyCommentDto>> result) {
                        if (result.isSuccess()) {
                            callBackHandle.showSuccess(result, "拉取 评论列表 成功");
                        } else {
                            callBackHandle.showError(result, "拉取 评论列表 失败");
                        }
                    }
                });
    }

    public void deleteItem(String userId, String password, Long commentId) {
        mModel.deleteCommentItem(userId, password, commentId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<Boolean>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError("删除评论失败:" + e.toString());
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onNext(Result<Boolean> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.dimissLoading();
                            callBack.showSuccess("删除 评论 成功");
                        } else {
                            callBack.showError("删除 评论 失败");
                        }
                    }
                });
    }
}
