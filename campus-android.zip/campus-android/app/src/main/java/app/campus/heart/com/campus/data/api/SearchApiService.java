package app.campus.heart.com.campus.data.api;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import retrofit2.http.GET;
import retrofit2.http.Query;
import rx.Observable;

/**
 * 搜索接口
 * @author: Veyron
 * @date：2018/4/26
 */

public interface SearchApiService {

    // 主页根据用户 ID 拉取该系统推荐帖子
    @GET("post/search")
    Observable<Result<PageList<HotItemDto>>> getSearchResults(
            @Query("userId") String userId
            , @Query("page") Integer page
            , @Query("key") String key);
}
