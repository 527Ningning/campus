package app.campus.heart.com.campus.controller.contact;


import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.controller.persenter.BasePresenter;
import app.campus.heart.com.campus.data.bean.LoginRequestBean;
import app.campus.heart.com.campus.data.bean.RegisterRequestBean;
import app.campus.heart.com.campus.ui.fragment.base.BaseView;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.T;


/**
 * View 和 Presenter 总接口
 *
 * @author: Veyron
 * @date：2017/11/21
 */

public interface BaseContact {
//
//     interface View<T> extends BaseView{
//         void showResult(Result<T> result);     //显示数据
//         void showNodata();                     //提示没数据
//     }
     interface View extends BaseView{
        // void showResult(Result<T> result);     //显示数据
         void showNodata();                     //提示没数据
     }

     interface LoginPersenter extends BasePresenter {
          void Login(LoginRequestBean requestBean);//登录
     }
    interface RegisterPersenter extends BasePresenter {
         void Register(RegisterRequestBean requestBean);//注册
    }

}
