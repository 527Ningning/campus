package app.campus.heart.com.campus.data.model;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.api.AdvertApiService;
import app.campus.heart.com.campus.data.dto.AdvertDto;
import rx.Observable;

/**
 * 首页广告数据 Model
 *
 * @author: Veyron
 * @date：2018/1/6
 */

public class AdvertModel {
    private AdvertApiService mAdvertApiService;

    public AdvertModel(AdvertApiService advertApiService) {
        mAdvertApiService = advertApiService;
    }

    // 获取首页数据
    public Observable<Result<PageList<AdvertDto>>>
    getAdvertDatas() {
        return mAdvertApiService.getAdvertDatas();
    }

    // 获取校园广告
    public Observable<Result<PageList<AdvertDto>>>
    getCampusAdvertDatas() {
        return mAdvertApiService.getCampusAdvertDatas();
    }
}
