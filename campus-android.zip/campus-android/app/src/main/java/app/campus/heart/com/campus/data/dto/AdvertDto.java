package app.campus.heart.com.campus.data.dto;

/**
 * 广告数据Dto
 *
 * @author: yuwu
 * @date: 2018/1/5
 */
public class AdvertDto {

    /**
     * 标题
     */
    private String title;

    /**
     * 封面照片
     */
    private String coverImg;

    /**
     * url链接
     */
    private String url;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCoverImg() {
        return coverImg;
    }

    public void setCoverImg(String coverImg) {
        this.coverImg = coverImg;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
