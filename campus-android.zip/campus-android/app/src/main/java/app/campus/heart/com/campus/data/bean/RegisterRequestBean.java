package app.campus.heart.com.campus.data.bean;

/**
 * 登录情况 bean
 * @author: Veyron
 * @date：2017/11/24
 */

public class RegisterRequestBean {
    private String userId;
    private String name;
    private Integer gender;
    private String password;
    private String phone;
    private String school;
    private String subject;
    private String address;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    @Override
    public String toString() {
        return "RegisterRequestBean{" +
                "userId='" + userId + '\'' +
                ", name='" + name + '\'' +
                ", gender=" + gender +
                ", password='" + password + '\'' +
                ", phone='" + phone + '\'' +
                ", school='" + school + '\'' +
                ", subject='" + subject + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
