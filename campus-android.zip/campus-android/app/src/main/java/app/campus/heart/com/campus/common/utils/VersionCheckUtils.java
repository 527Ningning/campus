package app.campus.heart.com.campus.common.utils;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import app.campus.heart.com.campus.service.DownloadService;

/**
 * @author: Veyron
 * @date：2018/4/4
 */

public class VersionCheckUtils {

    public static Boolean isNewVersion(int newVersionCode,Context mContext){
        int nowVersionCode;
        nowVersionCode = getNowVerCode(mContext);
        if (newVersionCode > nowVersionCode){
            //可以更新
            return true;
        }
        return false;
    }

    /*
     * 取得程序的当前版本
     */
    public static int getNowVerCode(Context context) {
        int verCode = 0;
        try {
            verCode = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {

        }
        return verCode;
    }
    public static String getNowVerName(Context context){
        String VerName = "";
        try{
            VerName = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0).versionName;
        }catch (PackageManager.NameNotFoundException e){

        }
        return VerName;
    }
    public static void goUpdate(Context context,String new_apkurl){
        Intent intent = new Intent(context, DownloadService.class);
        intent.putExtra("apkUrl", new_apkurl);
        context.startService(intent);
    }
}
