package app.campus.heart.com.campus.controller.persenter;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.data.api.SearchApiService;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import app.campus.heart.com.campus.data.model.SearchModel;
import retrofit2.Retrofit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * 搜索模块的 presenter 层
 * @author: Veyron
 * @date：2018/4/26
 */

public class SearchPresenter {
    private SearchApiService mSearchApiService;
    private SearchModel mSearchModel;
    private CallBack callBack;


    public SearchPresenter(CallBack callBack, Retrofit retrofit) {
        this.callBack = callBack;
        mSearchApiService = retrofit.create(SearchApiService.class);
        mSearchModel = new SearchModel(mSearchApiService);
    }

    //发起搜索请求，并处理结果数据
    public void getSearchResults(String userId,Integer page,String key){
        mSearchModel.getSearchResults(userId,page,key)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<HotItemDto>>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError("请求出错：" + e.toString());
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onNext(Result<PageList<HotItemDto>> result) {
                        if (result.isSuccess() == true) {
                            callBack.showResult(result);
                            callBack.showSuccess("搜索请求获取数据成功");
                        } else {
                            callBack.showError("搜索请求获取数据失败:" + result.getErrMessage());

                        }
                    }
                });

    }

}
