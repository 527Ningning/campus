package app.campus.heart.com.campus.data.model;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.api.SearchApiService;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import rx.Observable;

/**
 * 搜索模块的 model 层
 * @author: Veyron
 * @date：2018/4/26
 */

public class SearchModel {
    private SearchApiService mApiService;

    public SearchModel(SearchApiService mSearchApiService) {
        mApiService = mSearchApiService;
    }
    // 获取搜索结果数据
    public Observable<Result<PageList<HotItemDto>>>
    getSearchResults(String userId,Integer page,String key) {
        return mApiService.getSearchResults(userId,page,key);
    }
}
