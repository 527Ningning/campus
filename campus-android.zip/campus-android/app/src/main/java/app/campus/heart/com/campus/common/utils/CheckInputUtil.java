package app.campus.heart.com.campus.common.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 输入项校验：正则匹配
 *
 * @author: Veyron
 * @date：2017/11/28
 */

public class CheckInputUtil {

    private static Pattern PHONE_PATTERN = Pattern.compile("^((13[0-9])|(15[^4,\\D])|(18[0-9]))\\d{8}$");
    private static Pattern PASSWORD_PATTERN = Pattern.compile("^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$");

    /**
     * 校验电话号码合法性
     *
     * @param phone
     * @return
     */
    public static boolean isPhoneValid(String phone) {
        Matcher matcher = PHONE_PATTERN.matcher(phone);
        return matcher.matches();
    }

    /**
     * 校验密码合法性：字母加数字
     *
     * @param password
     * @return
     */
    public static boolean isPasswordValid(String password) {
        Matcher matcher = PASSWORD_PATTERN.matcher(password);
        return matcher.matches();
    }

}
