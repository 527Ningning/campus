package app.campus.heart.com.campus.ui.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v4.view.PagerAdapter;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.data.dto.TopArticleDto;
import app.campus.heart.com.campus.ui.activity.ArticleActivity;
import app.campus.heart.com.campus.ui.activity.LoginActivity;


/**
 * 七嘴八舌上部头条 viewPager 适配器
 *  左右无限滑动+点击监听+活动监听
 * @author: Veyron
 * @date：2017/11/29
 */

public class ImageCardViewPagerAdapter extends PagerAdapter {

    private Context mContext;
    private List<TopArticleDto> mArticleBeanList;
    private SparseArray<View> mViews;

    public ImageCardViewPagerAdapter(Context context,List<TopArticleDto> beanList) {
        mContext = context;
        mArticleBeanList = beanList;
        mViews = new SparseArray<View>(mArticleBeanList.size());
    }


    // 获取要滑动的控件的数量
    @Override
    public int getCount() {
        return mArticleBeanList.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView(mViews.get(position));
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view = mViews.get(position);
        if (view == null) {
            view = newView(position);
            mViews.put(position, view);
        }
        container.addView(view);
        return view;
    }

    private View newView(final int position) {
        View view = View.inflate(mContext, R.layout.viewpager_item, null);
        ImageView imageView = (ImageView) view.findViewById(R.id.image);
        imageView.setAdjustViewBounds(true);

        // 加载图片，先显示缩略图，再显示原图
        Glide.with(mContext)
                .load(getItem(position).getPicUrl()).thumbnail(0.1f).into(imageView);

        TextView topTitle = (TextView) view.findViewById(R.id.top_title);
        topTitle.setText(getItem(position).getTitle().toString());

        final TextView name = (TextView) view.findViewById(R.id.top_name);
        name.setText(getItem(position).getUserName().toString());

        TextView site = (TextView) view.findViewById(R.id.top_site);
        site.setText(getItem(position).getSite().toString());

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogUtil.E("点击："+ name.getText().toString());
                if (SharePresUtil.getObjectFromSharePres(mContext,"userObject") == null){
                    Toast.makeText(mContext,
                            "您未登录,请先登录", Toast.LENGTH_LONG).show();
                    mContext.startActivity(new Intent(
                            mContext, LoginActivity.class));
                }else{
                    Intent intent = new Intent(mContext, ArticleActivity.class);
                    intent.putExtra("postId",getItem(position).getPostId());
                    intent.putExtra("userId", "");
                    mContext.startActivity(intent);
                }

            }
        });

        return view;
    }

    public TopArticleDto getItem(int position) {
        return mArticleBeanList.get(position);
    }
}
