package app.campus.heart.com.campus.ui.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.change.TimeUtil;
import app.campus.heart.com.campus.common.change.TransFormOrigin;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import jp.wasabeef.glide.transformations.CropCircleTransformation;


/**
 * 给使用 recyclerview 准备的适配器
 *
 * @author: Veyron
 * @date：2017/12/20
 */


public class RecommendRviewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_NULL = 0;
    private static final int TYPE_FOOTER = 1;
    private static final int TYPE_NORMAL = 2;

    private Context context;
    private List<HotItemDto> list = new ArrayList<>();

    public void addAll(List<HotItemDto> list) {
        this.list.addAll(list);
    }

    public List<HotItemDto> getList() {
        return list;
    }

    public interface OnItemClickListener {
        void onItemClick(View view, int position);

        void onItemLongClick(View view, int position);
    }

    private OnItemClickListener onItemClickListener;

    public RecommendRviewAdapter(Context context, List<HotItemDto> list) {
        this.context = context;
        this.list = list;
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public int getItemCount() {
        return list.size() == 0 ? 0 : list.size() + 1;
    }

    @Override
    public int getItemViewType(int position) {
        if (position + 1 == getItemCount())
            return TYPE_FOOTER;

        return TYPE_NORMAL;
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_FOOTER) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_footer, parent,
                    false);
            return new FootViewHolder(view);
        }
        View view = LayoutInflater.from(context).inflate(R.layout.hot_postlist_item, parent,
                false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, int position, List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);

        if (holder instanceof ItemViewHolder) {
            HotItemDto mHotItemDto = list.get(position);
            ((ItemViewHolder) holder).title.setText(mHotItemDto.getTitle());
            ((ItemViewHolder) holder).content.setText(mHotItemDto.getContent());

            try {
                ((ItemViewHolder) holder).date.setText(TimeUtil.getGapHot(mHotItemDto.getDate()));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            //((ItemViewHolder) holder).date.setText(mHotItemDto.getDate());

            ((ItemViewHolder) holder)
                    .tag.setText(TransFormOrigin
                    .getTag(mHotItemDto.getTag()));


            ((ItemViewHolder) holder).user_msg.setText(mHotItemDto.getUserName()
                    + "-" + mHotItemDto.getUserSchool());

            Glide.with(context).load(mHotItemDto.getUserLogo())
                    .bitmapTransform(new CropCircleTransformation(context))
                    .override(20, 20)
                    .into(((ItemViewHolder) holder).user_icon);


            ((ItemViewHolder) holder).postType.
                    setText(TransFormOrigin.
                            getPostType(mHotItemDto.getPostType()));


            ((ItemViewHolder) holder).visitCount.setText(mHotItemDto.getVisitCount() + "");
            ((ItemViewHolder) holder).upvoteCount.setText(mHotItemDto.getUpvoteCount() + "");
            ((ItemViewHolder) holder).commentCount.setText(mHotItemDto.getCommentCount() + "");

            ((ItemViewHolder) holder).postType.setTextColor(TransFormOrigin.getPostTypeColor(mHotItemDto.getPostType()));

            if (mHotItemDto.getCoverImg() != null) {
                ((ItemViewHolder) holder).coverimg.setVisibility(View.VISIBLE);
                Glide.with(context)
                        .load(mHotItemDto.getCoverImg())
                        .thumbnail(0.1f)
                        .into(((ItemViewHolder) holder).coverimg);
            } else {
                ((ItemViewHolder) holder).coverimg.setVisibility(View.GONE);
            }

            if (onItemClickListener != null) {
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int position = holder.getLayoutPosition();
                        onItemClickListener.onItemClick(holder.itemView, position);
                    }
                });

                holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        int position = holder.getLayoutPosition();
                        onItemClickListener.onItemLongClick(holder.itemView, position);
                        return false;
                    }
                });
            }
        }
    }

    static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView title, content, date, tag, user_msg, postType, visitCount, upvoteCount, commentCount;
        ImageView coverimg, user_icon;                                 // 图片

        public ItemViewHolder(View view) {
            super(view);
            content = (TextView) view.findViewById(R.id.content);
            title = (TextView) view.findViewById(R.id.title);
            date = (TextView) view.findViewById(R.id.date);
            coverimg = (ImageView) view.findViewById(R.id.coverimg);
            user_icon = (ImageView) view.findViewById(R.id.user_icon);
            tag = (TextView) view.findViewById(R.id.tag);
            user_msg = (TextView) view.findViewById(R.id.user_msg);
            postType = (TextView) view.findViewById(R.id.postType);
            visitCount = (TextView) view.findViewById(R.id.visitCount);
            upvoteCount = (TextView) view.findViewById(R.id.upvoteCount);
            commentCount = (TextView) view.findViewById(R.id.commentCount);
        }
    }

    static class FootViewHolder extends RecyclerView.ViewHolder {
        public FootViewHolder(View view) {
            super(view);
        }
    }

    public void removeItem(int position) {
        LogUtil.E("position: " + position);
        LogUtil.E("getItemCount: " + getItemCount());
        if (getItemCount() == 2 && getItemCount() - 2 == position) {
            // 删除最后一个的时候，特殊处理
            list.clear();
            notifyDataSetChanged();
        } else {
            list.remove(position);
            notifyItemRemoved(position);
            if (position != list.size()) {
                notifyItemRangeChanged(position, list.size() - position);
            }
        }
    }
}
