package app.campus.heart.com.campus.controller.persenter;

import android.content.Context;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.token.TokenManager;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.controller.contact.BaseContact;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.data.api.UserApiService;
import app.campus.heart.com.campus.data.bean.LoginRequestBean;
import app.campus.heart.com.campus.data.dto.UserDto;
import app.campus.heart.com.campus.data.dto.UserLoginDto;
import app.campus.heart.com.campus.data.model.LoginModel;
import app.campus.heart.com.campus.ui.fragment.base.BaseView;
import retrofit2.Retrofit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * 登录 Presenter
 *
 * @author: Veyron
 * @date：2017/11/21
 */

public class LoginPresenter implements BaseContact.LoginPersenter {
    private LoginModel mLoginModel;
    private BaseView mBaseView;
    private UserApiService mApiService;
    private Context mContext;

    public LoginPresenter(Context context, BaseView baseView, Retrofit retrofit) {
        mBaseView = baseView;
        mApiService = retrofit.create(UserApiService.class);
        mLoginModel = new LoginModel(mApiService);
        mContext = context;
    }

    @Override
    public void Login(LoginRequestBean requestBean) {
        /**
         * 使用 Rxjava 链式调用
         */
        mLoginModel.login(requestBean)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<UserLoginDto>>() {
                    @Override
                    public void onStart() {
                        super.onStart();
                        mBaseView.showLodading();
                    }

                    @Override
                    public void onCompleted() {
                        mBaseView.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        mBaseView.dimissLoading();
                        mBaseView.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<UserLoginDto> result) {
                        if (result.isSuccess()) {
                            mBaseView.showSuccess("登录成功");
                            // 把用户数据缓存起来
                            Result<UserDto> userDtoResult = new Result<>();
                            userDtoResult.setContent(result.getContent().getUserModel());
                            SharePresUtil.setObject2SharePres(mContext, userDtoResult, "userObject");
                            //SharePresUtil.setObject2SharePres(mContext, result.getContent().getTokenModel().toString(), "tokenId");
                            TokenManager.setCurrentToken(mContext, result.getContent().getTokenModel().toString());
                        } else {
                            mBaseView.showError("登录失败");
                        }
                    }

                });

    }
}
