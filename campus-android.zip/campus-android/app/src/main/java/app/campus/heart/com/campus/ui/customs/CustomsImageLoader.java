package app.campus.heart.com.campus.ui.customs;

import android.content.Context;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.youth.banner.loader.ImageLoader;

/**
 * 自定义 图片加载类
 * @author: Veyron
 * @date：2017/11/28
 */

public class CustomsImageLoader extends ImageLoader {
    @Override
    public void displayImage(Context context, Object path, ImageView imageView) {
        Glide.with(context)
                .load(path)//图片地址
                .crossFade()
                .thumbnail(0.1f)
                .priority(Priority.HIGH)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(false)
                .into(imageView);

        /**
         *  1.目前仅仅使用内存缓存,不使用磁盘缓存，方便测试最佳图片大小
         *  2.先使用缩略图，后显示原图
         *  3.设置高优先级显示
         */


    }
}
