package app.campus.heart.com.campus.ui.fragment.base;

import android.view.View;

/**
 * Created by Veyron on 2017/11/21.
 * Function：公共视图接口
 */

public interface BaseView{
    //声明公共的一些方法
    void showLodading();//显示加载进度条
    void dimissLoading();//关闭加载进度条
    void showError(String msg);//显示错误信息
    void showSuccess(String msg);//显示成功信息
}
