package app.campus.heart.com.campus.common.page;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import app.campus.heart.com.campus.common.utils.CollectionUtil;

/**
 * <strong>描述：</strong>包含"分页"信息的<code>List</code> <br>
 * <strong>功能：</strong>提供分页数据及请求数据<br>
 * <strong>使用场景：</strong>需要分页的数据<br>
 * <strong>注意事项：</strong>
 * <ul>
 * <li></li>
 * </ul>
 *
 * @author: yuwu
 * @date: 2017/11/28
 */
public class PageList<E> implements Iterable<E>, Serializable {

    private static final long serialVersionUID = -30365820371800982L;

    private Paginator paginator;
    private List<E> dataList;

    /**
     * 创建一个<code>PageList</code>
     */
    public PageList() {
        paginator = new Paginator();
        this.paginator.setItems(0);
        dataList = new ArrayList<E>();
    }

    /**
     * 创建<code>PageList</code>，并将指定<code>Collection</code>中的内容复制到新的list中。
     *
     * @param c 要复制的<code>Collection</code>
     */
    public PageList(Collection<E> c) {
        this(c, null);
    }

    /**
     * 创建<code>PageList</code>，并将指定<code>Collection</code>中的内容复制到新的list中。
     *
     * @param c 要复制的<code>Collection</code>
     */
    public PageList(Collection<E> c, Paginator paginator) {
        this.dataList = new ArrayList<E>(c);
        if (paginator == null) {
            this.paginator = new Paginator();
            this.paginator.setItems(0);
        } else {
            this.paginator = paginator;
        }
    }

    public Paginator getPaginator() {
        return paginator;
    }

    public void setPaginator(Paginator paginator) {
        this.paginator = paginator;
    }

    public List<E> getDataList() {
        return dataList;
    }

    public E first() {
        if (CollectionUtil.isEmpty(dataList)) {
            return null;
        }
        return dataList.get(0);
    }

    /**
     * 结果集不为空
     *
     * @return
     */
    public boolean hasResult() {
        return !CollectionUtil.isEmpty(getDataList());
    }

    public void setDataList(List<E> dataList) {
        this.dataList = dataList;
    }

    /**
     * <strong>描述：</strong>遍历数据<br>
     * <strong>功能：</strong>遍历数据<br>
     * <strong>使用场景：</strong>分页结果数据遍历<br>
     * <strong>注意事项：</strong>
     * <ul>
     * <li></li>
     * </ul>
     *
     * @see java.lang.Iterable#iterator()
     */
    @Override
    public Iterator<E> iterator() {
        if (this.dataList == null) {
            return new NullIterator<E>();
        }
        return this.dataList.iterator();
    }

    public static class NullIterator<E> implements Iterator<E> {

        @Override
        public boolean hasNext() {
            return false;
        }

        @Override
        public E next() {
            return null;
        }

        @Override
        public void remove() {
        }
    }

    @Override
    public String toString() {
        return "PageList{" +
                "paginator=" + paginator +
                ", dataList=" + dataList +
                '}';
    }
}

