package app.campus.heart.com.campus.common.generator;

import android.content.Context;

import dmax.dialog.SpotsDialog;

/**
 * SpotDialog生产器
 *
 * @author: yuwu
 * @date: 2018/5/10
 */
public class SpotDialogGenerator {
    /**
     * 刷新
     *
     * @param context
     * @return
     */
    public static SpotsDialog refreshSpotsDialog(Context context) {
        return new SpotsDialog(context, "拼命刷新中....");
    }

    /**
     * 生产一般的SpotsDialog
     * @param context
     * @param title
     * @return
     */
    public static SpotsDialog commonSpotsDialog(Context context, String title) {
        return new SpotsDialog(context, title);
    }


}
