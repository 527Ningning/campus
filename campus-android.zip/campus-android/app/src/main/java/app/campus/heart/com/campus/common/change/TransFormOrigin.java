package app.campus.heart.com.campus.common.change;

import android.graphics.Color;

import app.campus.heart.com.campus.common.enums.ModuleEnum;

/**
 * 把int转为中文原意
 *
 * @author yuwu
 * @date: 2017/12/20
 */
public class TransFormOrigin {

    /**
     * postType帖子类别部分
     */
    public static final String UNKNOWN = "unknown";
    public static final String TALK_ANYWAY = "七嘴八舌";
    public static final String SPARE_TIME_JOB = "勤工俭学";
    public static final String SECOND_HAND_MARKET = "二手市场";
    public static final String JOB = "求职天地";
    public static final String STUDY = "学术殿堂";
    public static final String PLAY = "约喝约玩";
    public static final String BAIKE = "校园百科";
    public static final String LOSTANDFOUND = "失物招领";
    public static final String CAMPUSNEWS = "校园头条";


    /**
     * 性别部分
     */
    public static final String MALE = "男";
    public static final String FEMALE = "女";

    /**
     * 首页标签部分
     */
    //public static final String ESSENCE = "精品";
    public static final String ESSENCE = "推荐";
    public static final String TOP = "置顶";

    /**
     * 标签部分
     */
    public static final String FEELING = "心情";
    public static final String DAILY = "日常";
    public static final String FOOD = "美食";
    public static final String ADV = "广告";
    public static final String STUDYING = "学习";
    public static final String RECOMMEND = "推荐";
    public static final String VISIT = "出行";
    public static final String PLAYING = "娱乐";
    public static final String TECH = "科技";

    /**
     * 获取postType原意
     *
     * @param postType
     * @return
     */
    public static String getPostType(int postType) {
//        String origin;
//        switch (postType) {
//            case 1:
//                origin = TALK_ANYWAY;
//                break;
//            case 2:
//                origin = PLAY;
//                break;
//            case 3:
//                origin = SECOND_HAND_MARKET;
//                break;
//            case 4:
//                origin = SPARE_TIME_JOB;
//                break;
//            case 5:
//                origin = JOB;
//                break;
//            case 6:
//                origin = STUDY;
//                break;
//            case 7:
//                origin = LOSTANDFOUND;
//                break;
//            case 8:
//                origin = BAIKE;
//                break;
//            case 9:
//                origin = CAMPUSNEWS;
//                break;
//            default:
//                origin = UNKNOWN;
//        }
//        return origin;
        return ModuleEnum.parseName(postType).getModuleName();
    }

    /**
     * 获取性别原意
     *
     * @param gender
     * @return
     */
    public static String getGender(int gender) {
        String origin;
        switch (gender) {
            case 0:
                origin = MALE;
                break;
            case 1:
                origin = FEMALE;
                break;
            default:
                origin = UNKNOWN;
        }
        return origin;
    }

    /**
     * 获取首页标签原意
     *
     * @param tag
     * @return
     */
    public static String getTag(int tag) {
        String origin;
        switch (tag) {
            case 0:
                origin = TOP;
                break;
            case 1:
                origin = ESSENCE;
                break;
            default:
                origin = UNKNOWN;
        }
        return origin;
    }

    /**
     * 获取标签类别颜色
     *
     * @param labelId
     * @return
     */
    public static int getLabelColor(int labelId) {
        int origin;
        switch (labelId) {
            case 1:
                origin = Color.rgb(102, 158, 238);
                break;
            case 2:
                origin = Color.RED;
                break;
            case 3:
                origin = Color.rgb(102, 85, 204);
                break;
            case 4:
                origin = Color.rgb(0, 0, 205);
                break;
            case 5:
                origin = Color.rgb(0, 255, 170);
                break;
            case 6:
                origin = Color.rgb(119, 136, 187);
                break;
            case 7:
                origin = Color.rgb(153, 187, 255);
                break;
            case 8:
                origin = Color.rgb(186, 85, 211);
                break;
            case 9:
                origin = Color.rgb(238, 187, 51);
                break;
            case 10:
                origin = Color.rgb(238, 187, 51);
                break;
            case 11:
                origin = Color.rgb(102, 158, 238);
                break;
            case 12:
                origin = Color.RED;
                break;
            case 13:
                origin = Color.rgb(102, 85, 204);
                break;
            case 14:
                origin = Color.rgb(0, 0, 205);
                break;
            case 15:
                origin = Color.rgb(0, 255, 170);
                break;
            case 16:
                origin = Color.rgb(119, 136, 187);
                break;
            case 17:
                origin = Color.rgb(153, 187, 255);
                break;
            case 18:
                origin = Color.rgb(186, 85, 211);
                break;
            case 19:
                origin = Color.rgb(238, 187, 51);
                break;
            case 20:
                origin = Color.rgb(119, 136, 187);
                break;
            case 21:
                origin = Color.rgb(153, 187, 255);
                break;
            case 22:
                origin = Color.rgb(186, 85, 211);
                break;
            case 23:
                origin = Color.rgb(238, 187, 51);
                break;
            case 24:
                origin = Color.rgb(102, 158, 238);
                break;
            case 25:
                origin = Color.RED;
                break;
            default:
                origin = Color.rgb(238, 68, 238);
        }
        return origin;
    }

    /**
     * 获取帖子类型类别颜色
     *
     * @param labelId
     * @return
     */
    public static int getPostTypeColor(int labelId) {
        int origin;
        switch (labelId) {
//            case 1:
//                origin = Color.rgb(255, 0, 255);
//                break;
//            case 2:
//                origin = Color.RED;
//                break;
//            case 3:
//                origin = Color.rgb(123, 104, 238);
//                break;
//            case 4:
//                origin = Color.rgb(238, 204, 238);
//                break;
//            case 5:
//                origin = Color.rgb(72, 209, 204);
//                break;
//            case 6:
//                origin = Color.rgb(0, 255, 0);
//                break;
//            case 7:
//                origin = Color.rgb(255, 165, 0);
//                break;
//            case 8:
//                origin = Color.rgb(238, 187, 51);
//                break;
//            case 9:
//                origin = Color.rgb(0, 255, 52551);
//                break;
//            default:
//                origin = Color.rgb(238, 68, 238);
            case 1:
                origin = Color.rgb(102, 158, 238);
                break;
            case 2:
                origin = Color.rgb(255, 105, 180);
                break;
            case 3:
                origin = Color.rgb(102, 85, 204);
                break;
            case 4:
                origin = Color.rgb(30, 144, 254);
                break;
            case 5:
                origin = Color.rgb(0, 255, 170);
                break;
            case 6:
                origin = Color.rgb(119, 136, 187);
                break;
            case 7:
                origin = Color.rgb(153, 187, 255);
                break;
            case 8:
                origin = Color.rgb(186, 85, 211);
                break;
            case 9:
                origin = Color.rgb(238, 187, 51);
                break;
            case 10:
                origin = Color.rgb(238, 187, 51);
                break;
            case 11:
                origin = Color.rgb(102, 158, 238);
                break;
            case 12:
                origin = Color.RED;
                break;
            case 13:
                origin = Color.rgb(102, 85, 204);
                break;
            case 14:
                origin = Color.rgb(0, 0, 205);
                break;
            case 15:
                origin = Color.rgb(0, 255, 170);
                break;
            case 16:
                origin = Color.rgb(119, 136, 187);
                break;
            case 17:
                origin = Color.rgb(153, 187, 255);
                break;
            case 18:
                origin = Color.rgb(186, 85, 211);
                break;
            case 19:
                origin = Color.rgb(238, 187, 51);
                break;
            case 20:
                origin = Color.rgb(119, 136, 187);
                break;
            case 21:
                origin = Color.rgb(153, 187, 255);
                break;
            case 22:
                origin = Color.rgb(186, 85, 211);
                break;
            case 23:
                origin = Color.rgb(238, 187, 51);
                break;
            case 24:
                origin = Color.rgb(102, 158, 238);
                break;
            case 25:
                origin = Color.RED;
                break;
            default:
                origin = Color.rgb(238, 68, 238);
        }
        return origin;
    }


    /**
     * 根据标签获取原意
     *
     * @param labelId
     * @return
     */
    public static String getLabel(int labelId) {
        String origin;
        switch (labelId) {
            case 1:
                origin = DAILY;
                break;
            case 2:
                origin = FEELING;
                break;
            case 3:
                origin = FOOD;
                break;
            case 4:
                origin = ADV;
                break;
            case 5:
                origin = STUDYING;
                break;
            case 6:
                origin = RECOMMEND;
                break;
            case 7:
                origin = VISIT;
                break;
            case 8:
                origin = PLAYING;
                break;
            case 9:
                origin = TECH;
                break;
            default:
                origin = UNKNOWN;
        }
        return origin;
    }


}
