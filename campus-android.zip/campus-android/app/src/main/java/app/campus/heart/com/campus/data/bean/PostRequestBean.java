package app.campus.heart.com.campus.data.bean;

import java.io.File;

/**
 * 发帖请求 bean
 * @author: Veyron
 * @date：2018/1/4
 */

public class PostRequestBean {
    private String userId;
    private Integer postType;
    private String title;
    private String content;
    private Integer labelId;
    private File coverImg;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getPostType() {
        return postType;
    }

    public void setPostType(Integer postType) {
        this.postType = postType;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getLabelId() {
        return labelId;
    }

    public void setLabelId(Integer labelId) {
        this.labelId = labelId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public File getCoverImg() {
        return coverImg;
    }

    public void setCoverImg(File coverImg) {
        this.coverImg = coverImg;
    }

    @Override
    public String toString() {
        return "PostRequestBean{" +
                "userId='" + userId + '\'' +
                ", postType=" + postType +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", labelId=" + labelId +
                ", coverImg=" + coverImg +
                '}';
    }
}
