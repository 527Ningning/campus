package app.campus.heart.com.campus.data.model;

import java.util.List;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.api.PostApiService;
import app.campus.heart.com.campus.data.dto.ArticleItemDto;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import app.campus.heart.com.campus.data.dto.LabelDto;
import app.campus.heart.com.campus.data.dto.MyArticleItemDto;
import app.campus.heart.com.campus.data.dto.TopArticleDto;
import app.campus.heart.com.campus.data.dto.UnreadDto;
import app.campus.heart.com.campus.data.dto.UpvoteItemDto;
import okhttp3.RequestBody;
import rx.Observable;

/**
 * 操作 post 的 Model 类
 *
 * @author: Veyron
 * @date：2017/12/1
 */

public class PostModel {
    private PostApiService mApiService;

    public PostModel(PostApiService apiService) {
        mApiService = apiService;
    }

    // 我的帖子 模块，删除帖子
    public Observable<Result<Boolean>> deleteItem(String userId, String password, Integer postId) {
        return mApiService.deleteItem(userId, password, postId);
    }

    // 我的帖子 模块，根据用户信息拉取用户发过的帖子列表
    public Observable<Result<PageList<MyArticleItemDto>>>
    getMyPostLists(String userId, Integer postType, Integer page) {
        return mApiService.getMyPostLists(userId, postType, page);
    }

    // 根据帖子类型拉取该板块头条帖子(int postType)
    public Observable<Result<List<TopArticleDto>>> getTopArticle(int postType) {
        return mApiService.getTopArticle(postType);
    }

    // 根据用户ID拉取系统推荐帖子
    public Observable<Result<PageList<HotItemDto>>> getHotItemList(String userId, Integer page) {
        return mApiService.getHotItemList(userId, page);
    }

    // 根据用户ID拉取系统学校头条
    public Observable<Result<PageList<HotItemDto>>> getCampusHeadLines(Integer page) {
        return mApiService.getCampusHeadLines(page);
    }

    //根据帖子类型拉取帖子
    public Observable<Result<PageList<ArticleItemDto>>> getArticleItemList(Integer postType, Integer page) {
        return mApiService.getArticleItemList(postType, page);
    }

    // 提交帖子
    public Observable<Result<Long>> doPost(RequestBody body) {
        return mApiService.doPost(body);
    }

    // 获取七嘴八舌模块下发帖类型标签 选择列表
    public Observable<Result<PageList<LabelDto>>> getPostLabelType() {
        return mApiService.getPostLabelType();
    }

    //增加不敢兴趣记录
    public Observable<Result<Boolean>> addNoInterest(String userId, Integer postId) {
        return mApiService.addNoInterest(userId, postId);
    }

    // 获取点赞记录
    public Observable<Result<PageList<UpvoteItemDto>>> getUserUpvote(Integer page, String userId) {
        return mApiService.getUserUpvote(page, userId);
    }

    // 获取我的收藏记录
    public Observable<Result<PageList<HotItemDto>>> getCollect(Integer page, String userId) {
        return mApiService.getCollect(page, userId);
    }

    // 获取用户权限
    public Observable<Result<Boolean>> getAuthorization() {
        return mApiService.getAuthorization();
    }

    // 获取用户未读评论数
    public Observable<Result<Integer>> getUnreadCommentCount() {
        return mApiService.getUnreadCommentCount();
    }

    // 获取用户未读点赞数
    public Observable<Result<Integer>> getUnreadUpvoteCount() {
        return mApiService.getUnreadUpvoteCount();
    }

    // 获取用户未读数
    public Observable<Result<UnreadDto>> getUnreadCount() {
        return mApiService.getUnreadCount();
    }

}
