package app.campus.heart.com.campus.data.bean;

/**
 * 登录情况 bean
 * @author: Veyron
 * @date：2017/11/24
 */

public class LoginRequestBean {
    /**
     * 用户学号
     */
    private String userId;
    /**
     * 用户密码
     */
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "LoginRequestBean{" +
                "userId='" + userId + '\'' +
                ", userPassword='" + password + '\'' +
                '}';
    }
}
