package app.campus.heart.com.campus.ui.activity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.donkingliang.labels.LabelsView;
import com.yalantis.ucrop.UCrop;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.PostPresenter;
import app.campus.heart.com.campus.data.bean.PostRequestBean;
import app.campus.heart.com.campus.data.dto.LabelDto;
import app.campus.heart.com.campus.data.dto.UserDto;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dmax.dialog.SpotsDialog;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class PostingActivity extends BaseActivity {

    @BindView(R.id.labels)
    LabelsView mLabels;
    @BindView(R.id.go_back)
    ImageView mGoBack;
    @BindView(R.id.go_post)
    ImageView mGoPost;
    @BindView(R.id.no_img_layout)
    RelativeLayout mNoImgLayout;
    @BindView(R.id.cover_img)
    ImageView mCoverImg;
    @BindView(R.id.post_title)
    EditText mPostTitle;
    @BindView(R.id.post_content)
    EditText mPostContent;
    private Retrofit retrofit;
    private PostPresenter mPresenter;
    private SpotsDialog mDialog;
    private Integer labelId = 1;
    Result<UserDto> result;

    private List<LabelDto> dataList;

    private static final int REQUEST_SELECT_PICTURE = 0x01;
    private static final String SAMPLE_CROPPED_IMAGE_NAME = "SampleCropImage";

    Uri resultUri; // 一个临时图片文件url
    File saveFile; // 保存截取并压缩的图片文件
    Boolean isCoverImgOk = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posting);
        ButterKnife.bind(this);

        initRetrofit();
        initData();

        mDialog = new SpotsDialog(
                PostingActivity.this, "正在提交");

    }

    private void initData() {
        result = (Result<UserDto>) SharePresUtil
                .getObjectFromSharePres(this, "userObject");

        // 获取发帖标签 数据
        mPresenter = new PostPresenter(new CallBack<PageList<LabelDto>>() {
            @Override
            public void showResult(Result<PageList<LabelDto>> result) {
                LogUtil.E(result.getContent().getDataList().toString());
                dataList = result.getContent().getDataList();

                setLabelData();
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {

            }

            @Override
            public void showSuccess(String msg) {

            }
        }, retrofit);
        mPresenter.getPostLabelType();
    }

    private void setLabelData() {
        // 标签 list
        ArrayList<String> label = new ArrayList<>();

        for (int i = dataList.size() - 1; i >= 0; i--) {
            label.add(dataList.get(i).getLabel());
        }

        mLabels.setLabels(label);
        mLabels.setSelectType(LabelsView.SelectType.SINGLE_IRREVOCABLY);
        mLabels.setOnLabelClickListener(new LabelsView.OnLabelClickListener() {
            @Override
            public void onLabelClick(View label, String labelText, int position) {

                labelId = position + 1;
                LogUtil.E("position: " + labelId);
            }
        });
    }

    private void initRetrofit() {
        retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }

    @OnClick({R.id.go_back, R.id.go_post, R.id.no_img_layout, R.id.cover_img})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.go_back:
                finish();
                break;
            case R.id.go_post:
                // 检验 输入项 合理性
                // 提交
                checkInputAndCommit();
                break;
            case R.id.no_img_layout:
                // 点击获取图片
                pickFromGallery();
                break;
            case R.id.cover_img:
                // 点击重新获取图片
                pickFromGallery();
                break;
        }
    }

    /**
     * 获取图片
     */
    private void pickFromGallery() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN
                && ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermission(Manifest.permission.READ_EXTERNAL_STORAGE,
                    getString(R.string.permission_read_storage_rationale),
                    REQUEST_STORAGE_READ_ACCESS_PERMISSION);
        } else {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser
                            (intent, getString(R.string.label_select_picture))
                    , REQUEST_SELECT_PICTURE);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_SELECT_PICTURE) {
                final Uri selectedUri = data.getData();
                if (selectedUri != null) {
                    startCropActivity(data.getData());
                } else {
                    Toast.makeText(PostingActivity.this,
                            R.string.toast_cannot_retrieve_selected_image,
                            Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == UCrop.REQUEST_CROP) {
                handleCropResult(data);
            }
        }
        if (resultCode == UCrop.RESULT_ERROR) {
            handleCropError(data);
        }
    }

    // 开启截图 Activity
    private void startCropActivity(@NonNull Uri uri) {
        String destinationFileName = SAMPLE_CROPPED_IMAGE_NAME;

        //destinationFileName += ".png";
        destinationFileName += ".jpg";
        // 压缩格式选择了 jpg

        UCrop uCrop = UCrop.of(uri, Uri.fromFile(
                new File(getCacheDir(), destinationFileName)));

        uCrop = basisConfig(uCrop);   // 基础配置
        uCrop = advancedConfig(uCrop);// 高级配置
        uCrop.start(PostingActivity.this);
    }

    // 基础配置
    private UCrop basisConfig(@NonNull UCrop uCrop) {
        // 可以选择压缩大小
        try {
            int maxWidth = Integer.valueOf(640);
            int maxHeight = Integer.valueOf(300);
            if (maxWidth > 0 && maxHeight > 0) {
                uCrop = uCrop.withMaxResultSize(maxWidth, maxHeight);
            }
        } catch (NumberFormatException e) {
            LogUtil.E("Number please", e.toString());
        }

        return uCrop;
    }

    // 高级配置
    private UCrop advancedConfig(@NonNull UCrop uCrop) {
        UCrop.Options options = new UCrop.Options();

        // 压缩格式
        // options.setCompressionFormat(Bitmap.CompressFormat.PNG);
        options.setCompressionFormat(Bitmap.CompressFormat.JPEG);

        // 压缩质量
        options.setCompressionQuality(100);

        //比例
        options.withAspectRatio(16,9);

        options.setHideBottomControls(false);    //是否隐藏裁剪界面控制页面
        options.setFreeStyleCropEnabled(false);  //是否设置自由模式进行裁剪

        return uCrop.withOptions(options);
    }

    /**
     * 回调裁剪结果
     *
     * @param result
     */
    private void handleCropResult(@NonNull Intent result) {
        resultUri = UCrop.getOutput(result);
        if (resultUri != null) {
            LogUtil.E("结果返回：" + resultUri);
            // 隐藏 指引添加封面 的布局
            mNoImgLayout.setVisibility(View.INVISIBLE);

            // 加载所选择的图片，内存缓存、磁盘缓存均不使用
            Glide.with(PostingActivity.this).
                    load(resultUri).
                    diskCacheStrategy(DiskCacheStrategy.NONE)
                    .skipMemoryCache(true).into(mCoverImg);

            // 显示
            mCoverImg.setVisibility(View.VISIBLE);

            // 把截取的保存起来，以便发送请求（发帖）
            saveCroppedImage();

        } else {
            Toast.makeText(PostingActivity.this,
                    R.string.toast_cannot_retrieve_cropped_image,
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void saveCroppedImage() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    getString(R.string.permission_write_storage_rationale),
                    REQUEST_STORAGE_WRITE_ACCESS_PERMISSION);
        } else {
            Uri imageUri = resultUri;
            if (imageUri != null && imageUri.getScheme().equals("file")) {
                try {
                    copyFileToDownloads(resultUri);
                } catch (Exception e) {
                    Toast.makeText(PostingActivity.this,
                            e.getMessage(), Toast.LENGTH_SHORT).show();
                    LogUtil.E(e.toString());
                }
            } else {
                Toast.makeText(PostingActivity.this,
                        getString(R.string.toast_unexpected_error),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void copyFileToDownloads(Uri croppedFileUri) throws Exception {
        String downloadsDirectoryPath = Environment
                .getExternalStoragePublicDirectory
                        (Environment.DIRECTORY_DOWNLOADS).getAbsolutePath();
        String filename = String
                .format("%d_%s", Calendar.getInstance()
                        .getTimeInMillis(), croppedFileUri.getLastPathSegment());

        saveFile = new File(downloadsDirectoryPath, filename);

        FileInputStream inStream = new FileInputStream
                (new File(croppedFileUri.getPath()));
        FileOutputStream outStream = new FileOutputStream(saveFile);
        FileChannel inChannel = inStream.getChannel();
        FileChannel outChannel = outStream.getChannel();
        inChannel.transferTo(0, inChannel.size(), outChannel);
        inStream.close();
        outStream.close();

        // 设置标志位：图片已经保存

        isCoverImgOk = true;

        //showNotification(saveFile);
    }

    @SuppressWarnings("ThrowableResultOfMethodCallIgnored")
    private void handleCropError(@NonNull Intent result) {
        final Throwable cropError = UCrop.getError(result);
        if (cropError != null) {
            LogUtil.E("handleCropError: " + cropError);
            Toast.makeText(PostingActivity.this,
                    cropError.getMessage(), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(PostingActivity.this,
                    R.string.toast_unexpected_error, Toast.LENGTH_SHORT).show();
        }
    }


    private void checkInputAndCommit() {
        mDialog.show();

        mPresenter = new PostPresenter(new CallBack() {
            @Override
            public void showResult(Result result) {

            }

            @Override
            public void showLodading() {
                mDialog.show();
            }

            @Override
            public void dimissLoading() {
                mDialog.dismiss();
            }

            @Override
            public void showError(String msg) {
                LogUtil.E("showError " + msg);
                Toast.makeText(PostingActivity.this,
                        "发帖失败", Toast.LENGTH_LONG).show();
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E("showSuccess " + msg);
                Toast.makeText(PostingActivity.this, "发帖成功",
                        Toast.LENGTH_LONG).show();

                Intent i1 = new Intent();
                i1.putExtra("refresh", "1");
                setResult(1, i1);

                finish();
            }
        }, retrofit);
        // 检查输入项
        if (inPutAllOk()) {

            // 构造发帖请求bean
            PostRequestBean bean = new PostRequestBean();
            bean.setUserId(result.getContent().getUserId());
            //获取类型
            int postType = getIntent().getIntExtra("postType",1);
            bean.setPostType(postType);
            bean.setTitle(mPostTitle.getText().toString().trim());
            bean.setContent(mPostContent.getText().toString().trim());
            bean.setLabelId(labelId);

            bean.setCoverImg(saveFile);

            //构建body
            RequestBody requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("userId", bean.getUserId())
                    .addFormDataPart("postType", bean.getPostType() + "")
                    .addFormDataPart("title", bean.getTitle())
                    .addFormDataPart("content", bean.getContent())
                    .addFormDataPart("labelId", bean.getLabelId() + "")
                    .addFormDataPart("coverImg", bean.getCoverImg().getName(),
                            RequestBody.create(MediaType.parse("image/*"), bean.getCoverImg()))
                    .build();


            mPresenter.doPost(requestBody);
        } else {
            mDialog.dismiss();
        }
    }

    private boolean inPutAllOk() {
        if (!isCoverImgOk) {
            Toast.makeText(this, "请选择一张美美哒封面吧", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (mPostTitle.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "标题不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (labelId == null) {
            Toast.makeText(this, "发帖类型不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (mPostContent.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "内容不能为空", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
