package app.campus.heart.com.campus.ui.activity;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.ui.adapter.MyViewPagerAdapter;
import app.campus.heart.com.campus.ui.fragment.infragment.AccountLoginFragment;
import app.campus.heart.com.campus.ui.fragment.base.BaseFragment;
import app.campus.heart.com.campus.ui.fragment.infragment.PhoneAuthCodeFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * 登录页面： 账号登录、手机验证登录
 *
 * @author: Veyron
 * @date：2017/11/22
 */
public class LoginActivity extends AppCompatActivity {

    @BindView(R.id.login_cancel)
    TextView mLoginCancel;
    @BindView(R.id.tabLayout)
    TabLayout mTabLayout;
    @BindView(R.id.viewPager)
    ViewPager mViewPager;
//    @BindView(R.id.quick_register)
//    Button mQuickRegister;

    ArrayList<BaseFragment> mFragments;
    MyViewPagerAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        initData();
    }

    private void initData() {
        //初始化数据
        mFragments = new ArrayList<>();
        mFragments.add(new AccountLoginFragment("账号登录","1"));
       // mFragments.add(new PhoneAuthCodeFragment("手机验证码登录","2"));

        //设置ViewPager的适配器

        //adapter = new ViewPagerAdapter(getSupportFragmentManager(),fragments);
        mAdapter=new MyViewPagerAdapter(getSupportFragmentManager(),mFragments);
        mViewPager.setAdapter(mAdapter);
        //关联ViewPager
        mTabLayout.setupWithViewPager(mViewPager);
        //设置固定的
        mTabLayout.setTabMode(TabLayout.MODE_FIXED);
        //设置滑动的。
        //tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);


    }

    @OnClick({R.id.login_cancel})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.login_cancel:
                finish();
                break;
        }
    }
//    @OnClick({R.id.login_cancel, R.id.quick_register})
//    public void onClick(View view) {
//        switch (view.getId()) {
//            case R.id.login_cancel:
//                finish();
//                break;
//            case R.id.quick_register:
//                //调到快速注册页面
//                break;
//        }
//    }
}
