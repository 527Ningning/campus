package app.campus.heart.com.campus.data.api;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.dto.MyCommentDto;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import rx.Observable;


/**
 * @author: Veyron
 * @date：2018/2/2
 */

public interface CommentApiService {

    // 拉取用户的 所有评论
    @GET("post/myComment")
    Observable<Result<PageList<MyCommentDto>>>
    getAllComments(@Query("page") Integer page
            ,@Query("userId") String userId);

    // 删除 评论管理 模块 中 可删除的评论item
    @POST("post/deleteComment")
    Observable<Result<Boolean>>
    deleteCommentItem(@Query("userId") String userId,
                      @Query("password") String password,
                      @Query("commentId") Long commentId);
}
