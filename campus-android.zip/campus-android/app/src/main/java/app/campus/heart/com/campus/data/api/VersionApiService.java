package app.campus.heart.com.campus.data.api;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.dto.AppVersionDto;
import retrofit2.http.GET;
import rx.Observable;

/**
 * @author: Veyron
 * @date：2018/4/4
 */

public interface VersionApiService {
    // 获取首页广告数据
    @GET("appversion/getNewAppVersion")
    Observable<Result<AppVersionDto>>
    getNewAppVersion();
}
