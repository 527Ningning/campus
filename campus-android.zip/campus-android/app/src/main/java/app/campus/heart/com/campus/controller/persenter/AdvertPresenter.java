package app.campus.heart.com.campus.controller.persenter;


import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.data.api.AdvertApiService;
import app.campus.heart.com.campus.data.dto.AdvertDto;
import app.campus.heart.com.campus.data.model.AdvertModel;
import retrofit2.Retrofit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * 获取广告数据的 Presenter
 *
 * @author: Veyron
 * @date：2018/1/6
 */

public class AdvertPresenter {
    private AdvertApiService mAdvertApiService;
    private AdvertModel mModel;
    private CallBack callBack;

    public AdvertPresenter(CallBack callBack, Retrofit retrofit) {
        this.callBack = callBack;
        mAdvertApiService = retrofit.create(AdvertApiService.class);
        mModel = new AdvertModel(mAdvertApiService);
    }

    // 获取首页用户数据
    public void getAdvertDatas() {
        mModel.getAdvertDatas()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<AdvertDto>>>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError("请求出错：" + e.toString());
                    }

                    @Override
                    public void onNext(Result<PageList<AdvertDto>> result) {

                        if (result.isSuccess() == true) {
                            callBack.showResult(result);
                            callBack.showSuccess("获取首页广告数据成功");
                        } else {
                            callBack.showError("获取首页广告数据失败:" + result.getErrMessage());

                        }
                    }
                });
    }


    // 获取校园头条广告信息
    public void getCampusAdvertDatas() {
        mModel.getCampusAdvertDatas()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<AdvertDto>>>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError("请求出错：" + e.toString());
                    }

                    @Override
                    public void onNext(Result<PageList<AdvertDto>> result) {

                        if (result.isSuccess() == true) {
                            callBack.showResult(result);
                            callBack.showSuccess("获取校园广告数据成功");
                        } else {
                            callBack.showError("获取校园广告数据失败:" + result.getErrMessage());

                        }
                    }
                });
    }
}
