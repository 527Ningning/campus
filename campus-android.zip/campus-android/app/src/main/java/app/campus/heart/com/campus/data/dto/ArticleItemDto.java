package app.campus.heart.com.campus.data.dto;

import java.io.Serializable;

/**
 * 帖子item
 *
 * @author: yuwu
 * @date: 2017/12/19
 */

public class ArticleItemDto implements Serializable {

    /**
     * 用户名字
     */
    private String userName;

    /**
     * 用户头像
     */
    private String userLogo;

    /**
     * 用户学院
     */
    private String userSchool;

    /**
     * 帖子标题
     */
    private String title;

    /**
     * 帖子阅读量
     */
    private int    visitCount;

    /**
     * 帖子评论数
     */
    private int    commentCount;

    /**
     * 帖子ID,这里是Long类型
     */
    private Long   postId;

    /**
     * 帖子点赞数
     */
    private int    upvoteCount;

    /**
     * 日期
     */
    private String date;

    /**
     * 标签ID
     */
    private Long labelId;

    /**
     * 封面
     */
    private String coverImg;

    /**
     * 帖子内容
     */
    private String content;

    public Long getLabelId() {
        return labelId;
    }

    public void setLabelId(Long labelId) {
        this.labelId = labelId;
    }

    public Integer getUpvoteCount() {
        return upvoteCount;
    }

    public void setUpvoteCount(Integer upvoteCount) {
        this.upvoteCount = upvoteCount;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserLogo() {
        return userLogo;
    }

    public void setUserLogo(String userLogo) {
        this.userLogo = userLogo;
    }

    public String getUserSchool() {
        return userSchool;
    }

    public void setUserSchool(String userSchool) {
        this.userSchool = userSchool;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Integer getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(Integer visitCount) {
        this.visitCount = visitCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getCoverImg() {
        return coverImg;
    }

    public void setCoverImg(String coverImg) {
        this.coverImg = coverImg;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}
