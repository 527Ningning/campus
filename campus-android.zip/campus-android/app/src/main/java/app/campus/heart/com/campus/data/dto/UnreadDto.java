package app.campus.heart.com.campus.data.dto;

/**
 * @author: yuwu
 * @date: 2018/5/11
 */
public class UnreadDto {

    /**
     * 未读评论数
     */
    private Integer commentCount;

    /**
     * 未读点赞数
     */
    private Integer upvoteCount;

    public UnreadDto(Integer commentCount, Integer upvoteCount) {
        this.commentCount = commentCount;
        this.upvoteCount = upvoteCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    public Integer getUpvoteCount() {
        return upvoteCount;
    }

    public void setUpvoteCount(Integer upvoteCount) {
        this.upvoteCount = upvoteCount;
    }

    @Override
    public String toString() {
        return "UnreadDto{" +
                "commentCount=" + commentCount +
                ", upvoteCount=" + upvoteCount +
                '}';
    }
}
