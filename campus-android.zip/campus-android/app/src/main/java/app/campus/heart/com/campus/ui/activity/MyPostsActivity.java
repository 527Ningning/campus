package app.campus.heart.com.campus.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.generator.SpotDialogGenerator;
import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.token.RetrofitGenerateor;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.LoginUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.PostPresenter;
import app.campus.heart.com.campus.data.dto.MyArticleItemDto;
import app.campus.heart.com.campus.ui.adapter.MyPostRviewAdapter;
import app.campus.heart.com.campus.ui.adapter.RecycleViewDivider;
import app.campus.heart.com.campus.ui.customs.PostListItemRemoveRecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dmax.dialog.SpotsDialog;
import retrofit2.Retrofit;

/**
 * @author: Veyron
 * @date：2018/01/10
 */
public class MyPostsActivity extends AppCompatActivity
        implements SwipeRefreshLayout.OnRefreshListener {

    @BindView(R.id.go_back)
    ImageView mGoBack;
    @BindView(R.id.post_search)
    ImageView mPostSearch;
    @BindView(R.id.my_postlist)
    PostListItemRemoveRecyclerView mMyPostlist;

    @BindView(R.id.swipe_common)
    SwipeRefreshLayout mSwipeCommon;
    PostPresenter mPresenter;
    PostPresenter mPresenterDetele;
    MyPostRviewAdapter mAdapter;
    List<MyArticleItemDto> mList = new ArrayList<>();

    private boolean isLoading = false;  //判断是否加载更多，避免重复请求网络
    private Integer currentPage = 1;
    private Integer nextPage = 1;
    private Integer lastPage = 1;

    //创建一个线性布局管理器
    LinearLayoutManager layoutManager;
    private Handler handler = new Handler();

    private int index = 1;

    private Retrofit retrofit;

    private SpotsDialog mDialog;
    private SpotsDialog mRefreshingDialog;
    private String userId;
    private String password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_posts);
        ButterKnife.bind(this);
        userId = getIntent().getStringExtra("userId");
        password = getIntent().getStringExtra("password");
        mDialog = new SpotsDialog(this, "夺命加载中....");
        mRefreshingDialog = SpotDialogGenerator.refreshSpotsDialog(this);
        initView();
        initData();
        initMyPostLists();
    }

    private void initData() {
        initRetrofit();
        layoutManager = new LinearLayoutManager(this);
        mMyPostlist.setLayoutManager(layoutManager);
        mMyPostlist.setFocusable(false);
        // 取消列表的焦点，解决切换fragment时自动下滑列表导致的bug
        //添加分割线
        mMyPostlist.addItemDecoration(new RecycleViewDivider(this, R.drawable.divider_mileage));
        //mMyPostlist.setNestedScrollingEnabled(false);//解决滑动缓慢问题


        //mHotPostlist.setItemAnimator(new DefaultItemAnimator());
        ((SimpleItemAnimator) mMyPostlist.getItemAnimator())
                .setSupportsChangeAnimations(false);  //解决刷新抖动问题

        mMyPostlist.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_STATE_SETTLING) {
                    int lastVisiableItemPosition = layoutManager.findLastVisibleItemPosition();
                    if (lastVisiableItemPosition + 2 >= mAdapter.getItemCount()) {
                        if (!isLoading) {
                            isLoading = true;
                            //setLoadingFooter(isLoading);
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    loadMoreData();
                                    isLoading = false;
                                }
                            }, 10);
                        }
                    }
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    LogUtil.E("dy:== " + dy + "");
                    if (dy > 55) {
                        setLoadingFooter(true);
                    }
                }
            }
        });
    }

    private void initMyPostLists() {
        mPresenter = new PostPresenter(new CallBack<PageList<MyArticleItemDto>>() {
            @Override
            public void showResult(Result<PageList<MyArticleItemDto>> result) {
                currentPage = result.getContent().getPaginator().getPage();
                nextPage = result.getContent().getPaginator().getNextPage();
                lastPage = result.getContent().getPaginator().getLastPage();

                if (currentPage == 1) {
                    mList = result.getContent().getDataList();
                    LogUtil.E("拉取的数据： " + mList.toString());
                    mAdapter = new MyPostRviewAdapter(MyPostsActivity.this, mList);
                    mMyPostlist.setAdapter(mAdapter);
                    isLoading = false;
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);

                    mMyPostlist.setOnItemClickListener(new PostListItemRemoveRecyclerView.OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, int position) {
                            Long postId = mAdapter.getList().get(position).getPostId();
                            LogUtil.E("Hot 点击事件" + postId);
                            Intent intent = new Intent(
                                    MyPostsActivity.this, ArticleActivity.class);
                            intent.putExtra("postId", postId);
                            startActivity(intent);
                        }

                        @Override
                        public void onDeleteClick(int position) {
                            LogUtil.E("item 点击删除");
                            Long postId = mAdapter.getList().get(position).getPostId();
                            deleteItem(position, postId.intValue());
                        }
                    });

                    mRefreshingDialog.dismiss();
                } else if (currentPage < result.getContent().getPaginator().getPages()) {
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);
                    //mAdapter.notifyDataSetChanged();
                    mAdapter.notifyItemChanged(1, 1);
                    isLoading = false;
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);
                } else if (currentPage == lastPage) {
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);

                    //mAdapter.notifyDataSetChanged();
                    mAdapter.notifyItemChanged(1, 1);
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);
                }

            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {
                mDialog.dismiss();
            }

            @Override
            public void showError(String msg) {
                LogUtil.E("错误信息： " + msg.toString());
                finish();
                LoginUtil.requestLogin(MyPostsActivity.this);
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E("成功信息： " + msg.toString());
            }
        }, retrofit);
        getData();
    }

    //点击删除
    private void deleteItem(final int position, Integer postId) {
        if (mPresenterDetele != null) {
            mPresenterDetele = new PostPresenter(new CallBack() {
                @Override
                public void showResult(Result result) {

                }

                @Override
                public void showLodading() {

                }

                @Override
                public void dimissLoading() {

                }

                @Override
                public void showError(String msg) {
                    LogUtil.E(msg);
                    finish();
                    LoginUtil.requestLogin(MyPostsActivity.this);
                }

                @Override
                public void showSuccess(String msg) {
                    LogUtil.E(msg);
                    // 更新列表
                    mAdapter.removeItem(position);
                }
            }, retrofit);
        }
        // 发起删除
        mPresenterDetele.deleteItem(userId, password, postId);
    }

    private void setLoadingFooter(Boolean loading) {
        if (loading) {
            mAdapter.setLoadingFooter(true);
        }
        if (loading && mAdapter.getItemCount() > 5) {
            mAdapter.setLoadingFooter(true);
        } else {
            mAdapter.setLoadingFooter(false);
        }


    }

    private void getData() {
        LogUtil.E("刷新数据");
        if (!mList.isEmpty()) {
            mList.clear();
        }
        mPresenter.getMyPostLists(userId, null, null);
        mSwipeCommon.setRefreshing(false);
        index = 1;
    }

    private void loadMoreData() {
        index++;
        //mSwipe.setRefreshing(true);
        //setLoadingFooter(true);
        if (index > lastPage) {
            setLoadingFooter(false);
            LogUtil.E("已经没有新的了");
            //Toast.makeText(this, "已经没有新的了", Toast.LENGTH_SHORT).show();
            mAdapter.notifyItemRemoved(mAdapter.getItemCount());

            //mSwipe.setRefreshing(false);
        } else {
            LogUtil.E("加载更多数据");
            mPresenter.getMyPostLists(userId, null, nextPage);
        }
    }

    private void initRetrofit() {
        retrofit = RetrofitGenerateor.generateAuthorization(MyPostsActivity.this);
    }

    private void initView() {
        mDialog.show();
        mSwipeCommon.setOnRefreshListener(this);
        mSwipeCommon.setColorSchemeResources
                (R.color.colorAccent, R.color.colorPrimary, R.color.colorPrimaryDark);
    }

    @OnClick({R.id.go_back, R.id.post_search})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.go_back:
                finish();
                break;
            case R.id.post_search:
                Toast.makeText(this, "程序员正在开发中",
                        Toast.LENGTH_SHORT).show();
                break;
        }
    }

    /**
     * 刷新回调方法
     */
    @Override
    public void onRefresh() {
        // 开始刷新，设置当前为刷新状态
        mSwipeCommon.setRefreshing(true);

        mRefreshingDialog.show();

        isLoading = false;

        // 下拉刷新操作：获取新数据
        getData();
    }

}