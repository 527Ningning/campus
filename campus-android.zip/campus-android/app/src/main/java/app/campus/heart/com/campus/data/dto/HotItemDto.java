package app.campus.heart.com.campus.data.dto;

import java.io.Serializable;

/**
 * 首页精品帖子Dto
 *
 * @author: yuwu
 * @date: 2017/12/19
 */

public class HotItemDto implements Serializable {

    /**
     * 用户名字
     */
    private String userName;

    /**
     * 用户头像
     */
    private String userLogo;

    /**
     * 用户学院
     */
    private String userSchool;

    /**
     * 帖子标
     */
    private String title;

    /**
     * 帖子内容(截取后的)
     */
    private String content;

    /**
     * 帖子类型
     */
    private int postType;

    /**
     * 帖子阅读量
     */
    private int visitCount;

    /**
     * 帖子评论数
     */
    private int commentCount;

    /**
     * 帖子ID,这里是Long类型
     */
    private Long postId;

    /**
     * 帖子点赞数
     */
    private int upvoteCount;

    /**
     * 封面照片
     */
    private String coverImg;

    /**
     * 标签类型
     */
    private int tag;

    /**
     * 日期
     */
    private String date;

    /**
     * 标签ID
     */
    private Long labelId;

    public Long getLabelId() {
        return labelId;
    }

    public void setLabelId(Long labelId) {
        this.labelId = labelId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserLogo() {
        return userLogo;
    }

    public void setUserLogo(String userLogo) {
        this.userLogo = userLogo;
    }

    public String getUserSchool() {
        return userSchool;
    }

    public void setUserSchool(String userSchool) {
        this.userSchool = userSchool;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getPostType() {
        return postType;
    }

    public void setPostType(int postType) {
        this.postType = postType;
    }

    public int getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(int visitCount) {
        this.visitCount = visitCount;
    }

    public int getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(int commentCount) {
        this.commentCount = commentCount;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public int getUpvoteCount() {
        return upvoteCount;
    }

    public void setUpvoteCount(int upvoteCount) {
        this.upvoteCount = upvoteCount;
    }

    public String getCoverImg() {
        return coverImg;
    }

    public void setCoverImg(String coverImg) {
        this.coverImg = coverImg;
    }

    public int getTag() {
        return tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "HotItemDto{" +
                "userName='" + userName + '\'' +
                ", userLogo='" + userLogo + '\'' +
                ", userSchool='" + userSchool + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", postType=" + postType +
                ", visitCount=" + visitCount +
                ", commentCount=" + commentCount +
                ", postId=" + postId +
                ", upvoteCount=" + upvoteCount +
                ", coverImg='" + coverImg + '\'' +
                ", tag=" + tag +
                ", date='" + date + '\'' +
                '}';
    }
}
