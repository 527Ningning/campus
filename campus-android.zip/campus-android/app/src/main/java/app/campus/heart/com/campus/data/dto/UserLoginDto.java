package app.campus.heart.com.campus.data.dto;

import app.campus.heart.com.campus.common.token.TokenModel;

/**
 * @author: yuwu
 * @date: 2018/5/7
 */
public class UserLoginDto {

    /**
     * 用户模型
     */
    private UserDto userModel;
    /**
     * token模型
     */
    private TokenModel tokenModel;

    public UserDto getUserModel() {
        return userModel;
    }

    public void setUserModel(UserDto userModel) {
        this.userModel = userModel;
    }

    public TokenModel getTokenModel() {
        return tokenModel;
    }

    public void setTokenModel(TokenModel tokenModel) {
        this.tokenModel = tokenModel;
    }

    public UserLoginDto(UserDto userModel, TokenModel tokenModel) {
        this.userModel = userModel;
        this.tokenModel = tokenModel;
    }
}
