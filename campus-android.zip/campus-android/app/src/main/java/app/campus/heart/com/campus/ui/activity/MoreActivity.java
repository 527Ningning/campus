package app.campus.heart.com.campus.ui.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.enums.ModuleEnum;
import app.campus.heart.com.campus.common.utils.LogUtil;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * 更多
 */
public class MoreActivity extends AppCompatActivity {

    @BindView(R.id.go_back)
    ImageView mGoBack;

    @BindView(R.id.more_baike)
    TextView mBaikeModule;
    @BindView(R.id.more_lecture)
    TextView mLectureModule;
    @BindView(R.id.more_sports)
    TextView mSportsModule;
    @BindView(R.id.more_couple)
    TextView mLoveModule;
    @BindView(R.id.more_welfare)
    TextView mWelfareModule;
    @BindView(R.id.more_express)
    TextView mExpressModule;
    @BindView(R.id.more_party)
    TextView mPartyModule;
    @BindView(R.id.more_feedback)
    TextView mFeedBackModule;
    @BindView(R.id.more_graduate)
    TextView mGraduateModule;
    @BindView(R.id.more_photo)
    TextView mPhotoModule;
    @BindView(R.id.more_food)
    TextView mFoodModule;
    @BindView(R.id.more_music)
    TextView mMusicModule;
    @BindView(R.id.more_car)
    TextView mShcoolBusModule;
    @BindView(R.id.more_class)
    TextView mClassModule;
    @BindView(R.id.more_contest)
    TextView mContestModule;
    @BindView(R.id.more_table)
    TextView mClassTableModule;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more);
        ButterKnife.bind(this);
    }

    @OnClick({R.id.go_back, R.id.more_baike, R.id.more_lecture, R.id.more_sports, R.id.more_couple, R.id.more_welfare, R.id.more_express,
            R.id.more_party, R.id.more_feedback, R.id.more_graduate, R.id.more_photo, R.id.more_food, R.id.more_music, R.id.more_car,
            R.id.more_class, R.id.more_contest, R.id.more_table})
    public void onClick(View view) {
        LogUtil.E("点击");
        switch (view.getId()) {
            case R.id.go_back:
                finish();
                break;
            case R.id.more_baike:
                goToModule(ModuleEnum.校园百科);
                break;
            case R.id.more_lecture:
                goToModule(ModuleEnum.讲座分享);
                break;
            case R.id.more_sports:
                goToModule(ModuleEnum.运动健身);
                break;
            case R.id.more_couple:
                //goToModule(ModuleEnum.校园表白);
                break;
            case R.id.more_welfare:
                goToModule(ModuleEnum.校园公益);
                break;
            case R.id.more_express:
                //goToModule(ModuleEnum.代领快递);
                break;
            case R.id.more_car:
                //goToModule(ModuleEnum.校车资讯);
                break;
            case R.id.more_contest:
                goToModule(ModuleEnum.比赛资讯);
                break;
            case R.id.more_class:
                goToModule(ModuleEnum.培训课程);
                break;
            case R.id.more_feedback:
                goToModule(ModuleEnum.信息反馈);
                break;
            case R.id.more_food:
                goToModule(ModuleEnum.我是吃货);
                break;
            case R.id.more_graduate:
                goToModule(ModuleEnum.毕业季节);
                break;
            case R.id.more_music:
                goToModule(ModuleEnum.知音之地);
                break;
            case R.id.more_party:
                goToModule(ModuleEnum.社团天地);
                break;
            case R.id.more_photo:
                goToModule(ModuleEnum.西大摄影);
                break;
        }
    }

    public void goToModule(ModuleEnum moduleEnum) {
        Intent intent = new Intent(this, ModuleActivity.class);
        intent.putExtra("postType", moduleEnum.getValue());
        intent.putExtra("moduleName", moduleEnum.getModuleName());
        startActivity(intent);
    }
//
//    /**
//     * 对主页 8 个 分类的点击监听事件
//     *
//     * @param view
//     */
//    @OnClick({R.id.main_qgjx, R.id.main_2sjy, R.id.main_forjob, R.id.main_xsdt, R.id.main_talking, R.id.main_playing, R.id.main_why, R.id.main_bbx})
//    public void onClick(View view) {
//        switch (view.getId()) {
//            case R.id.main_qgjx:
//                // 勤工俭学
//                //Toast.makeText(getActivity(), "勤工俭学", Toast.LENGTH_SHORT).show();
//                Intent intent2 = new Intent(getActivity(), WorkActivity.class);
//                startActivity(intent2);
//                break;
//            case R.id.main_2sjy:
//                // 二手市场
//                //Toast.makeText(getActivity(), "二手市场", Toast.LENGTH_SHORT).show();
//                Intent intent4 = new Intent(getActivity(), MarketActivity.class);
//                startActivity(intent4);
//                break;
//            case R.id.main_forjob:
//                // 求职天地
//                //Toast.makeText(getActivity(), "求职天地", Toast.LENGTH_SHORT).show();
//                Intent intent7 = new Intent(getActivity(), Jobctivity.class);
//                startActivity(intent7);
//                break;
//            case R.id.main_xsdt:
//                // 学术殿堂
//                //Toast.makeText(getActivity(), "学术殿堂", Toast.LENGTH_SHORT).show();
//                Intent intent1 = new Intent(getActivity(), StudyingActivity.class);
//                startActivity(intent1);
//                break;
//            case R.id.main_talking:
//                // 七嘴八舌
//                //Toast.makeText(getActivity(), "七嘴八舌", Toast.LENGTH_SHORT).show();
//                Intent intent = new Intent(getActivity(), TalkingAnywayActivity.class);
//                startActivity(intent);
//
//                break;
//            case R.id.main_playing:
//                // 约喝约玩
//                //Toast.makeText(getActivity(), "约喝约玩", Toast.LENGTH_SHORT).show();
//                Intent intent3 = new Intent(getActivity(), PlayingActivity.class);
//                startActivity(intent3);
//                break;
//            case R.id.main_why:
//                // 问答
//                //Toast.makeText(getActivity(), "失物招领", Toast.LENGTH_SHORT).show();
//                Intent intent5 = new Intent(getActivity(), FindActivity.class);
//                startActivity(intent5);
//                break;
//            case R.id.main_bbx:
//                // 百宝箱
//                //Toast.makeText(getActivity(), "校园百科", Toast.LENGTH_SHORT).show();
//                Intent intent8 = new Intent(getActivity(), MoreActivity.class);
//                startActivity(intent8);
//                break;
//        }
//    }

}
