package app.campus.heart.com.campus.common.token;

import android.content.Context;

import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.utils.SharePresUtil;

/**
 * 管理Token
 *
 * @author: yuwu
 * @date: 2018/5/7
 */
public class TokenManager {

    /**
     * 获取当前token
     *
     * @param context
     * @return
     */
    public static String getCurrentToken(Context context) {
        if (SharePresUtil.getObjectFromSharePres(context, Constants.TAKEN_ID) != null) {
            return (String) SharePresUtil.getObjectFromSharePres(context, Constants.TAKEN_ID);
        }
        return "";
    }

    /**
     * 设置当前token
     *
     * @param context
     * @param token
     */
    public static void setCurrentToken(Context context, String token) {
        SharePresUtil.setObject2SharePres(context, token, Constants.TAKEN_ID);
    }

    /**
     * 删除当前token
     *
     * @param context
     */
    public static void delteCurrentToken(Context context) {
        SharePresUtil.setObject2SharePres(context, null, Constants.TAKEN_ID);
    }
}
