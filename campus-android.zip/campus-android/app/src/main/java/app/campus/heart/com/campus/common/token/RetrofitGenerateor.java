package app.campus.heart.com.campus.common.token;

import android.content.Context;

import java.io.IOException;

import app.campus.heart.com.campus.common.Constants;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * @author: yuwu
 * @date: 2018/5/7
 */
public class RetrofitGenerateor {

    /**
     * 获取一般请求的Retrofit
     *
     * @return
     */
    public static Retrofit generateCommon() {
        return new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }

    /**
     * 获取token认证类型的Retrofit
     * @param context
     * @return
     */
    public static Retrofit generateAuthorization(final Context context) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.addInterceptor(new Interceptor() {
            @Override
            public Response intercept(Chain chain) throws IOException {
                Request originalRequest = chain.request();
                Request authorised = originalRequest.newBuilder()
                        .header(Constants.AUTHORIZATION, TokenManager.getCurrentToken(context))
                        .build();
                return chain.proceed(authorised);
            }
        });
        return new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()).client(builder.build())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }


}
