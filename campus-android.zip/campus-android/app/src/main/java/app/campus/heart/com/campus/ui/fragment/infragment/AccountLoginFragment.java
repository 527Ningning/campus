package app.campus.heart.com.campus.ui.fragment.infragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.controller.persenter.LoginPresenter;
import app.campus.heart.com.campus.data.bean.LoginRequestBean;
import app.campus.heart.com.campus.ui.fragment.base.BaseView;
import app.campus.heart.com.campus.ui.activity.MainActivity;
import app.campus.heart.com.campus.ui.activity.RegisterActivity;
import app.campus.heart.com.campus.ui.fragment.base.BaseFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dmax.dialog.SpotsDialog;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 账号登录页面
 *
 * @author: Veyron
 * @date：2017/11/23
 */

public class AccountLoginFragment extends BaseFragment implements BaseView{


    @BindView(R.id.num_email)
    AutoCompleteTextView mNumEmail;
    @BindView(R.id.password)
    EditText mPassword;
    @BindView(R.id.go_register)
    TextView mGoRegister;
    @BindView(R.id.go_findpassword)
    TextView mGoFindpassword;
    @BindView(R.id.just_login)
    Button mJustLogin;

    private LoginPresenter mPresenter;
    private SpotsDialog mSpotsDialog;

    @SuppressLint("ValidFragment")
    public AccountLoginFragment(String title, String content) {
        super(title, content);
    }

    public AccountLoginFragment() {
    }

    @Override
    protected View initView() {
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        View contentView = mInflater.inflate(R.layout.layout_account_login, null);

        return contentView;
    }

    @Override
    protected void initData() {
        super.initData();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.ACCOUNT_LOGIN_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

        mPresenter = new LoginPresenter(mContext,this,retrofit);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        ButterKnife.bind(this, rootView);
        return rootView;
    }

    @OnClick({R.id.go_register, R.id.go_findpassword, R.id.just_login})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.go_register:
                Intent intent = new Intent(mContext, RegisterActivity.class);
                startActivity(intent);
                break;
            case R.id.go_findpassword:
                break;
            case R.id.just_login:
                if (checkInput()){

                    //构建请求参数
                    LoginRequestBean requestBean = new LoginRequestBean();
                    requestBean.setUserId(mNumEmail.getText().toString());

                    // 将输入的密码转为 MD5 传给服务器
                    requestBean.setPassword(mPassword.getText().toString());
                    mPresenter.Login(requestBean);
                }
                break;
        }
    }

    // 输入项校验方法
    private boolean checkInput() {
        if (isInputEmpty()){
            return false;
        }
        return true;
    }

    private boolean isInputEmpty() {
        if (mNumEmail.getText().toString().trim().isEmpty()
                || mPassword.getText().toString().trim().isEmpty()){
            Toast.makeText(getActivity(),"输入项不允许为空",Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }


    @Override
    public void showLodading() {
        mSpotsDialog = new SpotsDialog(getActivity(),"登录...");
        mSpotsDialog.show();
    }

    @Override
    public void dimissLoading() {
        mSpotsDialog.cancel();
    }

    @Override
    public void showError(String msg) {
        mSpotsDialog.cancel();
        Toast.makeText(getActivity(),msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showSuccess(String msg) {
        mSpotsDialog.cancel();
        Toast.makeText(getActivity(),msg,Toast.LENGTH_SHORT).show();


        // 登录成功，跳转到主页面
        Intent intent = new Intent(getActivity(), MainActivity.class);
        startActivity(intent);
    }

}
