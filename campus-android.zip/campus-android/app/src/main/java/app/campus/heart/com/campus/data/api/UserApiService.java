package app.campus.heart.com.campus.data.api;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.bean.UpDateRequestBean;
import app.campus.heart.com.campus.data.dto.PostTypeDto;
import app.campus.heart.com.campus.data.dto.UserDto;
import app.campus.heart.com.campus.data.dto.UserLoginDto;
import okhttp3.RequestBody;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;
import rx.Observable;



/**
 * User 相关的 ApiService
 *
 * @author: Veyron
 * @date：2017/11/21
 */
public interface UserApiService {

    //登录接口
    @POST("loginByCommon")
    @FormUrlEncoded
     Observable<Result<UserLoginDto>> login(@Field("userId") String userId
            , @Field("password") String password);

    //注册接口
    @POST("registerByCommon")
    @FormUrlEncoded
    Observable<Result<Long>> register(@Field("userId") String userId,
                                      @Field("name") String name,
                                      @Field("gender") Integer gender,
                                      @Field("password") String password,
                                      @Field("phone") String phone,
                                      @Field("school") String school,
                                      @Field("subject") String subject,
                                      @Field("address") String address
                                      );

    //用户修改接口
    @PUT("user")
    @FormUrlEncoded
    Observable<Result<UserDto>> modified(@Field("id") Long id,
                                         @Field("userId") String userId,
                                         @Field("oldPassword") String oldPassword,
                                         @Field("newPassword") String newPassword,
                                         @Field("name") String name,
                                         @Field("gender") Integer gender,
                                         @Field("phone") String phone,
                                         @Field("school") String school,
                                         @Field("subject") String subject,
                                          @Field("address") String address);



    // 根据学号拉取用户信息
    @GET("user")
    Observable<Result<UserDto>> getUser(@Query("userId") String userId);

    // 修改用户头像
    @POST("user/uploadImg")
    Observable<Result<String>> upLoadImg(@Body RequestBody Body);

}
