package app.campus.heart.com.campus.controller.persenter;

/**
 *
 *
 * @author: Veyron
 * @date：2017/11/21
 */

public interface BasePresenter {

}
