package app.campus.heart.com.campus.data.model;

import java.io.File;
import java.util.List;
import java.util.Map;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.api.UserApiService;
import app.campus.heart.com.campus.data.bean.UpDateRequestBean;
import app.campus.heart.com.campus.data.dto.TopArticleDto;
import app.campus.heart.com.campus.data.dto.UserDto;
import okhttp3.RequestBody;
import rx.Observable;

/**
 * @author: Veyron
 * @date：2017/12/26
 */

public class UserModel {
    private UserApiService mApiService;

    public UserModel(UserApiService apiService) {
        mApiService = apiService;
    }

    // 修改用户头像
    public Observable<Result<String>> upLoadImg(RequestBody body){
        return mApiService.upLoadImg(body);
    }

    // 修改用户信息
    public Observable<Result<UserDto>> upDateUserMsg(UpDateRequestBean bean){
        return mApiService.modified(
                                        bean.getId(),
                                        bean.getUserId(),
                                        bean.getOldPassword(),
                                        bean.getNewPassword(),
                                        bean.getName(),
                                        bean.getGender(),
                                        bean.getPhone(),
                                        bean.getSchool(),
                                        bean.getSubject(),
                                        bean.getAddress());
    }
}
