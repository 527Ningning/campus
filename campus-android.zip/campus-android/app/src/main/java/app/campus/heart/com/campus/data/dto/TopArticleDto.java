package app.campus.heart.com.campus.data.dto;

/**
 * 头条文章 Dto 类,泛指用于展示层与服务层之间的数据传输对象。
 *
 * @author: Veyron
 * @date：2017/11/29
 */

public class TopArticleDto {
    /**
     * 帖子ID
     */
    private Long postId;
    /**
     * 展示图片URL
     */
    private String picUrl;
    /**
     * 头条帖子名称
     */
    private String title;
    /**
     * 用户名称
     */
    private String userName;
    /**
     * 用户地点
     */
    private String site;

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }


    @Override
    public String toString() {
        return "TopArticleDto{" +
                "postId=" + postId +
                ", picUrl='" + picUrl + '\'' +
                ", title='" + title + '\'' +
                ", userName='" + userName + '\'' +
                ", site='" + site + '\'' +
                '}';
    }
}
