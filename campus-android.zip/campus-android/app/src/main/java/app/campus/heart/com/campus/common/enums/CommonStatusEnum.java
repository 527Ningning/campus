package app.campus.heart.com.campus.common.enums;

/**
 * 通用状态枚举
 *
 * @author: yuwu
 * @date: 2017/11/23
 */
public enum CommonStatusEnum {
    /**
     * 正常
     */
    NORMAL(0),

    /**
     * 删除
     */
    DELETE(1);

    Integer value;

    CommonStatusEnum(Integer value) {
        this.value = value;
    }

    public Integer getValue() {
        return value;
    }

}


