package app.campus.heart.com.campus.data.dto;

/**
 * 评论我的
 *
 * @author: yuwu
 * @date: 2018/1/25
 */
public class MyCommentDto {
    
    /**
     * 评论用户ID
     */
    private String userId;
    /**
     * 评论ID
     */
    private Long commentId;

    /**
     * 评论用户名字
     */
    private String userName;

    /**
     * 评论用户头像
     */
    private String userLogo;

    /**
     * 评论用户学院
     */
    private String school;

    /**
     * 评论内容
     */
    private String content;

    /**
     * 帖子ID
     */
    private Long postId;

    /**
     * 回复 用户 名字
     */
    private String replyUserName;

    /**
     * 回复 用户 学院
     */
    private String replyUserSchool;

    /**
     * 帖子封面
     */
    private String coverImg;


    /**
     * 回复用户ID;
     */
    private String replyUserId;

    /**
     * 评论时间
     */
    private String date;

    /**
     * 是否可删除位,true表示可删除,false表示不可删除
     */
    private Boolean deleteState;
    
    public Boolean getDeleteState() {
        return deleteState;
    }

    public void setDeleteState(Boolean deleteState) {
        this.deleteState = deleteState;
    }

    public String getReplyUserId() {
        return replyUserId;
    }

    public void setReplyUserId(String replyUserId) {
        this.replyUserId = replyUserId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserLogo() {
        return userLogo;
    }

    public void setUserLogo(String userLogo) {
        this.userLogo = userLogo;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public String getReplyUserName() {
        return replyUserName;
    }

    public void setReplyUserName(String replyUserName) {
        this.replyUserName = replyUserName;
    }

    public String getReplyUserSchool() {
        return replyUserSchool;
    }

    public void setReplyUserSchool(String replyUserSchool) {
        this.replyUserSchool = replyUserSchool;
    }

    public String getCoverImg() {
        return coverImg;
    }

    public void setCoverImg(String coverImg) {
        this.coverImg = coverImg;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "MyCommentDto{" +
                "userId='" + userId + '\'' +
                ", commentId=" + commentId +
                ", userName='" + userName + '\'' +
                ", userLogo='" + userLogo + '\'' +
                ", school='" + school + '\'' +
                ", content='" + content + '\'' +
                ", postId=" + postId +
                ", replyUserName='" + replyUserName + '\'' +
                ", replyUserSchool='" + replyUserSchool + '\'' +
                ", coverImg='" + coverImg + '\'' +
                ", replyUserId='" + replyUserId + '\'' +
                ", date='" + date + '\'' +
                ", deleteState=" + deleteState +
                '}';
    }
}
