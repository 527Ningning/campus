package app.campus.heart.com.campus.controller.persenter;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.data.api.VersionApiService;
import app.campus.heart.com.campus.data.dto.AppVersionDto;
import app.campus.heart.com.campus.data.model.VersionModel;
import retrofit2.Retrofit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * @author: Veyron
 * @date：2018/4/4
 */

public class AppVersionPresenter {
    private CallBack callBack;
    private VersionApiService mVersionApiService;
    private VersionModel mVersionModel;

    public AppVersionPresenter(CallBack callBack, Retrofit retrofit) {
        this.callBack = callBack;
        mVersionApiService = retrofit.create(VersionApiService.class);
        mVersionModel = new VersionModel(mVersionApiService);
    }
    // 获取最新版本信息
    public void getNewAppVerison() {
        mVersionModel.getNewAppVersion()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<AppVersionDto>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError("请求出错：" + e.toString());
                    }

                    @Override
                    public void onNext(Result<AppVersionDto> result) {
                        if (result.isSuccess() == true) {
                            callBack.showResult(result);
                            callBack.showSuccess("获取最新版本信息成功");
                        } else {
                            callBack.showError("获取最新版本信息失败:" + result.getErrMessage());

                        }
                    }
                });
    }

}
