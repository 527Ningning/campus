package app.campus.heart.com.campus.controller.contact;

/**
 * @author: yuwu
 * @date: 2018/5/10
 */
public interface CallBackHandle<T> {

    void showError(T content, String... failMessages);//显示错误信息

    void showSuccess(T content, String... successfulMessages);//显示成功信息

    void showLinkError(String message);//显示中断失败消息

}
