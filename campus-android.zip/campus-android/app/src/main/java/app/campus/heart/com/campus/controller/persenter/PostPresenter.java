package app.campus.heart.com.campus.controller.persenter;

import java.util.List;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.contact.CallBackHandle;
import app.campus.heart.com.campus.data.api.PostApiService;
import app.campus.heart.com.campus.data.dto.ArticleItemDto;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import app.campus.heart.com.campus.data.dto.LabelDto;
import app.campus.heart.com.campus.data.dto.MyArticleItemDto;
import app.campus.heart.com.campus.data.dto.TopArticleDto;
import app.campus.heart.com.campus.data.dto.UnreadDto;
import app.campus.heart.com.campus.data.dto.UpvoteItemDto;
import app.campus.heart.com.campus.data.model.PostModel;
import okhttp3.RequestBody;
import retrofit2.Retrofit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * @author: Veyron
 * @date：2017/12/1
 */
public class PostPresenter {
    private PostModel mPostModel;
    //private BaseContact.View mView;
    private PostApiService mApiService;
    private CallBack callBack;

    public PostPresenter(Retrofit retrofit) {
        mApiService = retrofit.create(PostApiService.class);
        mPostModel = new PostModel(mApiService);
    }

    public PostPresenter(CallBack callBack, Retrofit retrofit) {
        //mView = view;
        this.callBack = callBack;
        mApiService = retrofit.create(PostApiService.class);
        mPostModel = new PostModel(mApiService);
    }

    // 我的帖子模块，用户删除帖子
    public void deleteItem(String userId, String password, Integer postId) {
        mPostModel.deleteItem(userId, password, postId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<Boolean>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.dimissLoading();
                        callBack.showError("删除帖子发生异常：" + e.toString());
                    }

                    @Override
                    public void onNext(Result<Boolean> result) {
                        if (result.isSuccess()) {
                            callBack.showSuccess("删除 帖子 成功");
                        } else {
                            callBack.showError("删除 帖子 失败");
                        }
                    }
                });
    }

    // 我的帖子模块，根据用户信息获取用户发帖数据列表
    public void getMyPostLists(String userId, Integer postType, Integer page) {
        mPostModel.getMyPostLists(userId, postType, page)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<MyArticleItemDto>>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError("拉取帖子失败:" + e.toString());
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onNext(Result<PageList<MyArticleItemDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取 我的帖子 成功");
                        } else {
                            callBack.showError("拉取 我的帖子 失败");
                        }

                    }
                });
    }

    // 获取 七嘴八舌模块下发帖类型
    public void getPostLabelType() {
        mPostModel.getPostLabelType()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<LabelDto>>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onNext(Result<PageList<LabelDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("获取所有标签成功");
                        } else {
                            callBack.showError("获取所有标签失败");
                        }
                    }
                });
    }

    // 用户 发帖
    public void doPost(RequestBody body) {
        mPostModel.doPost(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<Long>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onNext(Result<Long> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("发帖成功");
                        } else {
                            callBack.showError("发帖失败");
                        }
                    }
                });
    }

    //推荐帖子
    public void getHotItemList(String userId, Integer page) {
        mPostModel.getHotItemList(userId, page)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<HotItemDto>>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<PageList<HotItemDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    //获取校园头条
    public void getCampusHeadLines(Integer page) {
        mPostModel.getCampusHeadLines(page)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<HotItemDto>>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<PageList<HotItemDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    // 获取 5 个热门帖子
    public void getTopArticle(int postType) {

        mPostModel.getTopArticle(postType)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<List<TopArticleDto>>>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        //mView.showError(e.toString());
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<List<TopArticleDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    public void getArticleItemList(Integer postType, Integer page) {
        mPostModel.getArticleItemList(postType, page)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<ArticleItemDto>>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<PageList<ArticleItemDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    public void addNoInterest(String userId, Integer postId) {
        mPostModel.addNoInterest(userId, postId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<Boolean>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<Boolean> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    public void getUserUpvote(Integer page, String userId) {
        mPostModel.getUserUpvote(page, userId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<UpvoteItemDto>>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<PageList<UpvoteItemDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    public void getCollect(Integer page, String userId) {
        mPostModel.getCollect(page, userId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<HotItemDto>>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<PageList<HotItemDto>> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }


    public void getAuthorization() {
        mPostModel.getAuthorization()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<Boolean>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<Boolean> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    /**
     * 获取用户未读评论数
     */
    public void getUnreadCommentCount() {
        mPostModel.getUnreadCommentCount()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<Integer>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<Integer> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    /**
     * 获取用户未读点赞数
     */
    public void getUnreadUpvoteCount() {
        mPostModel.getUnreadUpvoteCount()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<Integer>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.showError(e.toString());
                    }

                    @Override
                    public void onNext(Result<Integer> result) {
                        if (result.isSuccess()) {
                            callBack.showResult(result);
                            callBack.showSuccess("拉取数据成功");
                        } else {
                            callBack.showError("拉取数据失败");
                        }
                    }
                });
    }

    /**
     * 获取用户未读数
     */
    public void getUnreadCount(final CallBackHandle callBackHandle) {
        mPostModel.getUnreadCount()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<UnreadDto>>() {
                    @Override
                    public void onCompleted() {
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBackHandle.showLinkError(e.toString());
                    }

                    @Override
                    public void onNext(Result<UnreadDto> result) {
                        if (result.isSuccess()) {
                            callBackHandle.showSuccess(result, "拉取用户未读数成功");
                        } else {
                            callBackHandle.showError(result, "拉取用户未读数成功");
                        }
                    }
                });
    }
}
