package app.campus.heart.com.campus.common.enums;

import app.campus.heart.com.campus.common.utils.StringUtil;

/**
 * 通用错误枚举
 *
 * @author: yuwu
 * @date: 2017/11/23
 */
public enum ErrorCodeEnum {
    /**
     * 未知错误
     */
    UNKNOWN("CB000000"),
    /**
     * 参数为空
     */
    PARAM_IS_NULL("CB000001"),
    /**
     * 参数非法
     */
    PARAM_IS_INVALID("CB000002"),
    /**
     * 服务异常
     */
    SERVICE_IS_ERROR("CB000003"),
    /**
     * 结果为空
     */
    RESULT_IS_NULL("CB000004"),
    /**
     * 操作者为空
     */
    OPERATOR_IS_NULL("CB000005"),
    /**
     * 数组超出限制
     */
    ARRAY_SIZE_OUT("CB000006"),
    /**
     * 集合超出限制
     */
    COLLECTION_SIZE_OUT("CB000007"),

    /**
     * 用户学号重复
     */
    USER_ID_DUPLICATE("CB000008"),

    /**
     * 用户账号或密码错误
     */
    USER_LOGIN_INVALID("CB000009"),

    /**
     * 操作非法
     */
    OPERATION_IS_INVALID("CB000010"),

    /**
     * 需要用户重新登录
     */
    USER_LOGIN_TIMEOUT("CB000011"),

    /**
     * 需要用户重新登录
     */
    USER_TOKEN_NO_EXIST("CB000012");
    private String code;

    ErrorCodeEnum(String code) {
        this.code = code;
    }

    /**
     * <strong>描述：</strong>获取errCode <br>
     * <strong>功能：</strong>获取errCode<br>
     * <strong>使用场景：</strong>服务实现内部需要返回错误code时使用<br>
     * <strong>注意事项：</strong>
     * <ol>
     * <li>字符均为大写</li>
     * </ol>
     * <strong>调用举例：</strong>
     * <p/>
     * <pre>
     * ErrorCodeEnum.xxx.getCode()
     * </pre>
     *
     * @return errCode
     * @author slf 2017年2月8日 上午11:35:12
     */
    public String getCode() {
        return this.code;
    }

    /**
     * <strong>描述：</strong>获取errMsg <br>
     * <strong>功能：</strong>获取errMSg<br>
     * <strong>使用场景：</strong>服务实现内部需要返回错误message时使用<br>
     * <strong>注意事项：</strong>
     * <ol>
     * <li>字符均为大写</li>
     * </ol>
     * <strong>调用举例：</strong>
     * <p/>
     * <pre>
     * ErrorCodeEnum.xxx.getMessage()
     * </pre>
     *
     * @return errMsg
     * @author slf 2017年2月8日 上午11:35:12
     */
    public String getMessage() {
        return this.name();
    }

    /**
     * <strong>描述：</strong>获取枚举类 <br>
     * <strong>功能：</strong>通过errCode获取对应的枚举<br>
     * <strong>使用场景：</strong>通过code获取错误说明信息<br>
     * <strong>注意事项：</strong>
     * <ol>
     * <li>返回结果可能为null</li>
     * </ol>
     * <strong>调用举例：</strong>
     * <p/>
     * <pre>
     * ErrorCodeEnum.parseCode("CB000000");
     * </pre>
     *
     * @param code 错误code
     * @return 枚举类
     * @author slf 2017年2月8日 上午11:30:43
     */
    public static ErrorCodeEnum parseCode(String code) {
        if (StringUtil.isBlank(code)) {
            return null;
        }
        for (ErrorCodeEnum e : ErrorCodeEnum.values()) {
            if (e.getCode().equals(code)) {
                return e;
            }
        }
        return null;
    }

    /**
     * <strong>描述：</strong>获取枚举类 <br>
     * <strong>功能：</strong>通过name获取对应的枚举<br>
     * <strong>使用场景：</strong>通过name获取code或说明信息时<br>
     * <strong>注意事项：</strong>
     * <ol>
     * <li>返回结果可能为null</li>
     * </ol>
     * <strong>调用举例：</strong>
     * <p/>
     * <pre>
     * ErrorCodeEnum.parseName("PARAM_IS_NULL");
     * </pre>
     *
     * @param name 错误名称
     * @return 枚举类
     * @author slf 2017年2月8日 上午11:30:39
     */
    public static ErrorCodeEnum parseName(String name) {
        if (StringUtil.isBlank(name)) {
            return null;
        }
        for (ErrorCodeEnum e : ErrorCodeEnum.values()) {
            if (e.name().equalsIgnoreCase(name)) {
                return e;
            }
        }
        return null;
    }
}

