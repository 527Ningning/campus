package app.campus.heart.com.campus.ui.fragment.infragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.utils.CheckInputUtil;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.controller.persenter.RegisterPresenter;
import app.campus.heart.com.campus.data.bean.RegisterRequestBean;
import app.campus.heart.com.campus.ui.activity.LoginActivity;
import app.campus.heart.com.campus.ui.fragment.base.BaseView;
import app.campus.heart.com.campus.ui.fragment.base.BaseFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dmax.dialog.SpotsDialog;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 账号注册页面
 *
 * @author: Veyron
 * @date：2017/11/23
 */

public class AccountRegisterFragment extends BaseFragment implements BaseView {

    @BindView(R.id.user_name)
    AutoCompleteTextView mUserName;
    @BindView(R.id.password)
    EditText mPassword;
    @BindView(R.id.re_password)
    AutoCompleteTextView mRePassword;
    @BindView(R.id.stuno)
    AutoCompleteTextView mStuno;
    @BindView(R.id.college)
    AutoCompleteTextView mCollege;
    @BindView(R.id.major)
    AutoCompleteTextView mMajor;
    @BindView(R.id.phone)
    AutoCompleteTextView mPhone;
    @BindView(R.id.spinner)
    Spinner mSpinner;
    @BindView(R.id.dormitory)
    AutoCompleteTextView mDormitory;
    @BindView(R.id.just_register)
    Button mJustRegister;

    private Integer gender;
    private RegisterPresenter mPresenter;
    private SpotsDialog mDialog;

    @SuppressLint("ValidFragment")
    public AccountRegisterFragment(String title, String content) {
        super(title, content);

    }

    public AccountRegisterFragment() {
    }

    @Override
    protected View initView() {
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        View view = mInflater.inflate(R.layout.layout_account_register, null);

        return view;
    }

    @Override
    protected void initData() {
        super.initData();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.ACCOUNT_REGISTER_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

        mPresenter = new RegisterPresenter(this, retrofit);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO: inflate a fragment view
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        ButterKnife.bind(this, rootView);
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                gender = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        return rootView;
    }

    @OnClick(R.id.just_register)
    public void onClick() {
        //校验输入项
        if (checkInput()) {
            //发起注册
            //构建请求对象
            RegisterRequestBean bean = new RegisterRequestBean();
            bean.setName(mUserName.getText().toString());
            bean.setPassword(mPassword.getText().toString());
            bean.setUserId(mStuno.getText().toString());
            bean.setSchool(mCollege.getText().toString());
            bean.setSubject(mMajor.getText().toString());
            bean.setGender(gender);
            bean.setPhone(mPhone.getText().toString());
            bean.setAddress(mDormitory.getText().toString());

            LogUtil.E(bean.toString());
            mPresenter.Register(bean);
        }
    }

    //输入项校验方法
    private boolean checkInput() {
        if (!isPasswordOk()) {
            return false;
        }
        if (isInputEmpty()) {
            return false;
        }
        if (!CheckInputUtil.isPhoneValid(mPhone.getText().toString())) {
            Toast.makeText(getActivity(), "手机号码非法", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (!CheckInputUtil.isPasswordValid(mPassword.getText().toString())) {
            Toast.makeText(getActivity(), "密码安全性太低，请重新输入", Toast.LENGTH_SHORT).show();
            mPassword.setText("");
            mRePassword.setText("");

            return false;
        }
        // 单纯进行非空校验
        if (mUserName.getText().toString().trim().isEmpty() || mUserName.getText().toString().length() > 4) {
            Toast.makeText(getActivity(),
                    "名字最多不能超过4个字,请检查", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mStuno.getText().toString().trim().isEmpty() || mStuno.getText().toString().trim().length() > 16) {
            Toast.makeText(getActivity(),
                    "学号不能超过16个数字,请检查", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mCollege.getText().toString().trim().isEmpty() || mCollege.getText().toString().trim().length() > 5) {
            Toast.makeText(getActivity(),
                    "学院长度不能超过5个字，建议使用简称", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mMajor.getText().toString().trim().isEmpty() || mMajor.getText().toString().trim().length() > 8) {
            Toast.makeText(getActivity(),
                    "专业名称不能超过8个字，建议使用简称", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mPhone.getText().toString().trim().isEmpty() || mPhone.getText().toString().trim().length() > 11) {
            Toast.makeText(getActivity(),
                    "手机号码不能超过11个数字，请检查", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mDormitory.getText().toString().trim().isEmpty() || mDormitory.getText().toString().trim().length() > 12) {
            Toast.makeText(getActivity(),
                    "宿舍地址不能超过12个字，请检查", Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

    private boolean isInputEmpty() {
        if (mUserName.getText().toString().isEmpty()
                || mPassword.getText().toString().isEmpty()
                || mStuno.getText().toString().isEmpty()
                || mCollege.getText().toString().isEmpty()
                || mMajor.getText().toString().isEmpty()
                || mPhone.getText().toString().isEmpty()
                || mDormitory.getText().toString().isEmpty()) {
            Toast.makeText(getActivity(), "输入项不允许为空", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    private boolean isPasswordOk() {
        if (mPassword.getText().toString().trim()
                .equals(mRePassword.getText().toString().trim())
                ) {
            return true;
        } else {
            mPassword.setText("");
            mRePassword.setText("");
            Toast.makeText(getActivity(), "两次密码输入不一致", Toast.LENGTH_SHORT).show();
        }
        return false;
    }


    /**
     * 实现 BaseView 接口的回调方法（在 presenter 中发起调用）
     */
    @Override
    public void showLodading() {
        mDialog = new SpotsDialog(getActivity(), "注册...");
        mDialog.show();
    }

    @Override
    public void dimissLoading() {
        mDialog.cancel();
    }

    @Override
    public void showError(String msg) {
        mDialog.cancel();
        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showSuccess(String msg) {
        mDialog.cancel();
        Toast.makeText(getActivity(), "注册成功，你是第" + msg + "位用户", Toast.LENGTH_SHORT).show();

        getActivity().finish();
    }

}
