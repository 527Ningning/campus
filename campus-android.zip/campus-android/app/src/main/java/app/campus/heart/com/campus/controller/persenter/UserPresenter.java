package app.campus.heart.com.campus.controller.persenter;



import android.content.Intent;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.data.api.UserApiService;
import app.campus.heart.com.campus.data.bean.UpDateRequestBean;
import app.campus.heart.com.campus.data.dto.UserDto;
import app.campus.heart.com.campus.data.model.UserModel;
import app.campus.heart.com.campus.ui.activity.RegisterActivity;
import okhttp3.RequestBody;
import retrofit2.Retrofit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * @author: Veyron
 * @date：2017/12/26
 */

public class UserPresenter {
    private UserModel mUserModel;
    private UserApiService mUserApiService;
    private CallBack callBack;

    public UserPresenter(CallBack callBack, Retrofit retrofit) {
        this.callBack = callBack;
        mUserApiService = retrofit.create(UserApiService.class);
        mUserModel = new UserModel(mUserApiService);
    }

    // 修改用户信息
    public void upDateUserMsg(UpDateRequestBean bean){
        callBack.showLodading();

        mUserModel.upDateUserMsg(bean)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<UserDto>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.dimissLoading();
                        callBack.showError("请求出错："+e.toString());
                    }

                    @Override
                    public void onNext(Result<UserDto> result) {
                        if (result.isSuccess() == true){
                            callBack.showResult(result);
                            callBack.showSuccess("修改成功");
                        }else {
                            callBack.showError("修改失败:"+result.getErrMessage());

                        }
                    }
                });
    }

    // 修改用户头像
    public void upLoadImg(RequestBody body){
        callBack.showLodading();

        mUserModel.upLoadImg(body)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<String>>() {
                    @Override
                    public void onCompleted() {
                        callBack.dimissLoading();
                    }

                    @Override
                    public void onError(Throwable e) {
                        callBack.dimissLoading();
                        callBack.showError("请求出错："+e.toString());
                    }

                    @Override
                    public void onNext(Result<String> result) {
                        if (result.isSuccess()){
                            callBack.showResult(result);
                            callBack.showSuccess("修改图片成功");
                        }else {
                            callBack.showError("修改图片失败");
                        }

                    }
                });
    }
}