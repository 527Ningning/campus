package app.campus.heart.com.campus.ui.activity;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.enums.ErrorCodeEnum;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.token.RetrofitGenerateor;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.common.utils.VersionCheckUtils;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.contact.CallBackHandle;
import app.campus.heart.com.campus.controller.persenter.AppVersionPresenter;
import app.campus.heart.com.campus.controller.persenter.PostPresenter;
import app.campus.heart.com.campus.data.dto.AppVersionDto;
import app.campus.heart.com.campus.data.dto.UnreadDto;
import app.campus.heart.com.campus.ui.fragment.CommunityFragment;
import app.campus.heart.com.campus.ui.fragment.MessageFragment;
import app.campus.heart.com.campus.ui.fragment.MyDdFragment;
import app.campus.heart.com.campus.ui.fragment.base.BaseFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 应用主页面： 承载三个 Fragment 页面
 *
 * @author: Veyron
 * @date：2017/11/22
 */

public class MainActivity extends AppCompatActivity {
    long ExitTime;
    private RadioGroup mRg_main;
    private List<BaseFragment> mBaseFragment;
    /**
     * 选中的Fragment的对应的位置
     */
    private int position;
    /**
     * 上次切换的Fragment
     */
    private Fragment mContent;

    private Retrofit mRetrofit;
    private AppVersionPresenter mPresenter;
    private PostPresenter mUnreadPresenter;
    private Handler handler = new Handler();
    private Runnable task;
    CallBackHandle<Result<UnreadDto>> callBackHandle;

    //从服务器获得最新的版本号
    Integer newVersionCode;
    // 从服务器获得的最新版本apk 的下载url
    String newApkUrl;
    // 软件版本描述
    String desc;

    TextView mUnreadTextView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //初始化View
        initView();

        //ButterKnife.bind(this);
        //初始化Fragment
        initFragment();
        //设置RadioGroup的监听
        setListener();

        // 检查是否有新版本
        checkIfNewVersion();

        //未读数状态显示
        initUnreadCheck();
    }

    private void initUnreadCheck() {
        mUnreadTextView = (TextView) findViewById(R.id.unread_count);
        mUnreadPresenter = new PostPresenter(RetrofitGenerateor.generateAuthorization(MainActivity.this));
        callBackHandle = new CallBackHandle<Result<UnreadDto>>() {
            @Override
            public void showError(Result<UnreadDto> content, String... failMessages) {
                for (String failMessage : failMessages) {
                    LogUtil.E(failMessage);
                }
                mUnreadTextView.setVisibility(View.INVISIBLE);
                ErrorCodeEnum errorCodeEnum = ErrorCodeEnum.parseName(content.getErrMessage());
                switch (errorCodeEnum) {
                    case RESULT_IS_NULL:
                        break;
                    case USER_TOKEN_NO_EXIST:
                        break;
                    default:
                        break;
                }
                SharePresUtil.setUnreadComment(MainActivity.this, null);
                SharePresUtil.setUnreadUpvote(MainActivity.this, null);
                mUnreadTextView.setVisibility(View.INVISIBLE);
            }

            @Override
            public void showSuccess(Result<UnreadDto> content, String... successfulMessages) {
                for (String successfulMessage : successfulMessages) {
                    LogUtil.E(successfulMessage);
                }
                LogUtil.E(content.toString());
                if (SharePresUtil.getObjectFromSharePres(MainActivity.this, "userObject") != null) {
                    mUnreadTextView.setVisibility(View.VISIBLE);
                    if (content.getContent().getCommentCount() + content.getContent().getUpvoteCount() > 99) {
                        mUnreadTextView.setText("..");
                    } else {
                        mUnreadTextView.setText(String.valueOf(content.getContent().getCommentCount().intValue()
                                + content.getContent().getUpvoteCount().intValue()));
                    }
                    SharePresUtil.setUnreadComment(MainActivity.this, content.getContent().getCommentCount());
                    SharePresUtil.setUnreadUpvote(MainActivity.this, content.getContent().getUpvoteCount());
                }
            }

            @Override
            public void showLinkError(String message) {
                LogUtil.E(message.toString());
            }
        };
        initTimerTask();
    }

    private void initTimerTask() {
        if (task == null) {
            task = new Runnable() {
                @Override
                public void run() {
                    mUnreadPresenter.getUnreadCount(callBackHandle);
                    LogUtil.E("Main:5秒运行一次,拉取未读状态");
                    handler.postDelayed(this, 4500);
                }
            };
        }
        handler.postDelayed(task, 1000);
    }

    private void checkIfNewVersion() {
        initRetrofit();
        mPresenter = new AppVersionPresenter(new CallBack<AppVersionDto>() {
            @Override
            public void showResult(Result<AppVersionDto> result) {
                newVersionCode = result.getContent().getId().intValue();
                if (VersionCheckUtils.isNewVersion
                        (newVersionCode, MainActivity.this)) {
                    newApkUrl = result.getContent().getFilePath();
                    desc = result.getContent().getDesc();
                    //执行更行操作
                    //弹出对话框
                    Dialog dialog = new AlertDialog.Builder(MainActivity.this)
                            .setTitle("软件更新")
                            .setMessage(desc)
                            // 设置内容
                            .setPositiveButton("更新",// 设置确定按钮
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog,
                                                            int which) {
                                            VersionCheckUtils.goUpdate(MainActivity.this, newApkUrl);
                                            Toast.makeText(MainActivity.this, "正在更新", Toast.LENGTH_SHORT).show();
                                        }
                                    })
                            .setNegativeButton("暂不更新",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog,
                                                            int whichButton) {
                                            // 点击"取消"按钮之后退出程序
                                            //finish();
                                        }
                                    }).create();// 创建
                    // 显示对话框
                    dialog.show();
                }
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {

            }

            @Override
            public void showSuccess(String msg) {

            }
        }, mRetrofit);

        mPresenter.getNewAppVerison();

    }

    private void initRetrofit() {
        mRetrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }

    private void initView() {
        setContentView(R.layout.activity_main);
        mRg_main = (RadioGroup) findViewById(R.id.rg_main);
        //Tony Add
        Drawable drawable1 = getResources().getDrawable(R.drawable.rb_main_frame_drawable_selector);
        drawable1.setBounds(0, 5, 20, 20);
    }

    private void initFragment() {
        mBaseFragment = new ArrayList<>();
        mBaseFragment.add(new CommunityFragment());
        mBaseFragment.add(new MessageFragment());
        mBaseFragment.add(new MyDdFragment());
    }

    private void setListener() {
        mRg_main.setOnCheckedChangeListener(new MyOnCheckedChangeListener());
        //设置默认选中常用框架
        mRg_main.check(R.id.rb_main_frame);
    }

    /**
     * 根据位置得到对应的Fragment
     *
     * @return
     */
    private BaseFragment getFragment() {
        BaseFragment fragment = mBaseFragment.get(position);
        return fragment;
    }

    class MyOnCheckedChangeListener implements RadioGroup.OnCheckedChangeListener {

        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            switch (checkedId) {
                case R.id.rb_main_frame://
                    position = 0;
                    break;
                case R.id.rb_message_frame://
                    position = 1;
                    break;
                case R.id.rb_mine_frame://
                    position = 2;
                    break;
                default:
                    position = 0;
                    break;
            }

            //根据位置得到对应的Fragment
            BaseFragment to = getFragment();
            //替换
            switchFrament(mContent, to);

        }
    }

    /**
     * @param from 刚显示的Fragment,马上就要被隐藏了
     * @param to   马上要切换到的Fragment，一会要显示
     */
    private void switchFrament(Fragment from, Fragment to) {
        if (from != to) {
            mContent = to;
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            //才切换
            //判断有没有被添加
            if (!to.isAdded()) {
                //to没有被添加
                //from隐藏
                if (from != null) {
                    ft.hide(from);
                }
                //添加to
                if (to != null) {
                    ft.add(R.id.fl_content, to).commit();
                }
            } else {
                //to已经被添加
                // from隐藏
                if (from != null) {
                    ft.hide(from);
                }
                //显示to
                if (to != null) {
                    ft.show(to).commit();
                }
            }
        }

    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode != 4 || event.getRepeatCount() != 0) {
            return super.onKeyDown(keyCode, event);
        }
        if (System.currentTimeMillis() - this.ExitTime > 2000) {


            this.ExitTime = System.currentTimeMillis();
            Toast.makeText(this, "再按一次退出应用", Toast.LENGTH_SHORT).show();
        } else {
            finish();
        }
        return true;
    }
}
