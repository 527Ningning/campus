package app.campus.heart.com.campus.data.dto;

import java.io.Serializable;

/**
 * 我的帖子Dto
 *
 * @author: yuwu
 * @date: 2018/1/8
 */
public class MyArticleItemDto implements Serializable {

    /**
     * 帖子ID
     */
    private Long    postId;

    /**
     * 帖子类型
     */
    private Integer postType;

    /**
     * 标签ID
     */
    private Long    labelId;

    /**
     * 帖子标题
     */
    private String  title;

    /**
     * 时间
     */
    private String  date;

    /**
     * 帖子浏览数
     */
    private Integer visitCount;

    /**
     * 帖子点赞数
     */
    private Integer upvoteCount;

    /**
     * 帖子评论数
     */
    private Integer commentCount;

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public Integer getPostType() {
        return postType;
    }

    public void setPostType(Integer postType) {
        this.postType = postType;
    }

    public Long getLabelId() {
        return labelId;
    }

    public void setLabelId(Long labelId) {
        this.labelId = labelId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Integer getVisitCount() {
        return visitCount;
    }

    public void setVisitCount(Integer visitCount) {
        this.visitCount = visitCount;
    }

    public Integer getUpvoteCount() {
        return upvoteCount;
    }

    public void setUpvoteCount(Integer upvoteCount) {
        this.upvoteCount = upvoteCount;
    }

    public Integer getCommentCount() {
        return commentCount;
    }

    public void setCommentCount(Integer commentCount) {
        this.commentCount = commentCount;
    }

    @Override
    public String toString() {
        return "MyArticleItemDto{" +
                "postId=" + postId +
                ", postType=" + postType +
                ", labelId=" + labelId +
                ", title='" + title + '\'' +
                ", date='" + date + '\'' +
                ", visitCount=" + visitCount +
                ", upvoteCount=" + upvoteCount +
                ", commentCount=" + commentCount +
                '}';
    }
}
