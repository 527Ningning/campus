package app.campus.heart.com.campus.data.model;

import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.api.CommentApiService;
import app.campus.heart.com.campus.data.dto.MyCommentDto;
import rx.Observable;


/**
 * @author: Veyron
 * @date：2018/2/2
 */

public class CommentModel {
    private CommentApiService mApiService;
    public CommentModel(CommentApiService apiService) {
        mApiService = apiService;
    }
    // 拉取用户 的 所有评论
    public Observable<Result<PageList<MyCommentDto>>> getAllComment(Integer page, String userId){
        return mApiService.getAllComments(page,userId);
    }

    // 删除 评论管理  模块 中  能被删除的 item
    public Observable<Result<Boolean>> deleteCommentItem(String userId,String password,Long commentId){
        return mApiService.deleteCommentItem(userId,password,commentId);
    }

}
