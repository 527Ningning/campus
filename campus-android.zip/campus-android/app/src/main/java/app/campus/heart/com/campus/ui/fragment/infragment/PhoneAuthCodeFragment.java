package app.campus.heart.com.campus.ui.fragment.infragment;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import java.util.concurrent.TimeUnit;
import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.ui.fragment.base.BaseFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;


import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action0;
import rx.functions.Func1;
import rx.schedulers.Schedulers;


/**
 * 手机验证码登录页面
 *
 * @author: Veyron
 * @date：2017/11/23
 */

public class PhoneAuthCodeFragment extends BaseFragment {

    @BindView(R.id.phone)
    AutoCompleteTextView mPhone;
    @BindView(R.id.authcode)
    EditText mAuthcode;
    @BindView(R.id.get_authcode)
    Button mGetAuthcode;
    @BindView(R.id.just_login)
    Button mJustLogin;

    @SuppressLint("ValidFragment")
    public PhoneAuthCodeFragment(String title, String content) {
        super(title, content);
    }

    public PhoneAuthCodeFragment() {
    }

    @Override
    protected View initView() {
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        View contentView = mInflater.inflate(R.layout.layout_phone_authcode_login, null);
        return contentView;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO: inflate a fragment view
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        ButterKnife.bind(this, rootView);
        return rootView;
    }

    @OnClick({R.id.get_authcode, R.id.just_login})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.get_authcode:
                //获取验证码
                rxJavaGetAuthCode();
                break;
            case R.id.just_login:
                //执行登录

                break;
        }
    }

    private void rxJavaGetAuthCode() {
        final int count = 10;
        Observable.interval(0,1, TimeUnit.SECONDS)
                .take(count+1)
                .map(new Func1<Long, Long>() {
                    @Override
                    public Long call(Long aLong) {
                        return count - aLong;
                    }
                }).subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnSubscribe(new Action0() {
                    @Override
                    public void call() {
                        mGetAuthcode.setEnabled(false);
                        mGetAuthcode.setTextColor(Color.BLACK);
                    }
                })
                .subscribe(new Subscriber<Long>() {
                    @Override
                    public void onCompleted() {
                        mGetAuthcode.setEnabled(true);
                        //mGetAuthcode.setTextColor(Color.parseColor("#FA9D26"));
                        mGetAuthcode.setText("获取验证码");
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onNext(Long num) {
                        mGetAuthcode.setText("剩余"+ num +"秒");
                    }
                });
    }
}
