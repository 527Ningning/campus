package app.campus.heart.com.campus.controller.contact;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.ui.fragment.base.BaseView;

/**
 * ShowResult接口
 *
 * @author: yuwu
 * @date: 2017/12/19
 */
public interface CallBack<T> extends BaseView {

    void showResult(Result<T> result);

}

