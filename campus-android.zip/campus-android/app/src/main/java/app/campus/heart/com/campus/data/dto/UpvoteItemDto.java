package app.campus.heart.com.campus.data.dto;

/**
 * @author: yuwu
 * @date: 2018/4/19
 */
public class UpvoteItemDto {
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserLogo() {
        return userLogo;
    }

    public void setUserLogo(String userLogo) {
        this.userLogo = userLogo;
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public Long getPostId() {
        return postId;
    }

    public void setPostId(Long postId) {
        this.postId = postId;
    }

    public String getCoverImg() {
        return coverImg;
    }

    public void setCoverImg(String coverImg) {
        this.coverImg = coverImg;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    /**
     * 评论用户ID
     */
    private String  userId;

    /**
     * 评论用户名字
     */
    private String  userName;

    /**
     * 评论用户头像
     */
    private String  userLogo;

    /**
     * 评论用户学院
     */
    private String  school;

    /**
     * 帖子ID
     */
    private Long    postId;

    /**
     * 帖子封面
     */
    private String  coverImg;

    /**
     * 点赞时间
     */
    private String  date;

}
