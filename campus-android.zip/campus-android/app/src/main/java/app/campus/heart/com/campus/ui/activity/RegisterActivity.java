package app.campus.heart.com.campus.ui.activity;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.ArrayList;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.ui.adapter.MyViewPagerAdapter;
import app.campus.heart.com.campus.ui.fragment.infragment.AccountRegisterFragment;
import app.campus.heart.com.campus.ui.fragment.base.BaseFragment;
import app.campus.heart.com.campus.ui.fragment.infragment.PhoneRegisterFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class RegisterActivity extends AppCompatActivity {
    ArrayList<BaseFragment> mFragments;
    MyViewPagerAdapter mAdapter;
    @BindView(R.id.login_cancel)
    TextView mLoginCancel;
    @BindView(R.id.tabLayout)
    TabLayout mTabLayout;
    @BindView(R.id.viewPager)
    ViewPager mViewPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);

        initData();
    }

    private void initData() {
        //初始化数据
        mFragments = new ArrayList<>();
        mFragments.add(new AccountRegisterFragment("账号注册","1"));
        //mFragments.add(new PhoneRegisterFragment("手机注册","2"));

        //设置ViewPager的适配器

        //adapter = new ViewPagerAdapter(getSupportFragmentManager(),fragments);
        mAdapter=new MyViewPagerAdapter(getSupportFragmentManager(),mFragments);
        mViewPager.setAdapter(mAdapter);
        //关联ViewPager
        mTabLayout.setupWithViewPager(mViewPager);
        //设置固定的
        mTabLayout.setTabMode(TabLayout.MODE_FIXED);
        //设置滑动的。
        //tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);

    }

    @OnClick(R.id.login_cancel)
    public void onClick() {
        finish();
    }
}
