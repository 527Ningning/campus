package app.campus.heart.com.campus.data.dto;

import app.campus.heart.com.campus.common.domain.AbstractModel;

/**
 * 帖子类型模型类
 *
 * @author: yuwu
 * @date: 2017/11/23
 */
public class PostTypeDto extends AbstractModel {

    /**
     * 帖子类型描述
     */
    private String desc;

    /**
     * 删除标志位
     */
    private Integer status;

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "PostTypeDto{" + "desc='" + desc + '\'' + ", status=" + status + '}';
    }

}
