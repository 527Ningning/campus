package app.campus.heart.com.campus.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.getbase.floatingactionbutton.AddFloatingActionButton;
import com.youth.banner.listener.OnBannerListener;

import java.util.ArrayList;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.token.RetrofitGenerateor;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.RxTimerUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.PostPresenter;
import app.campus.heart.com.campus.data.dto.ArticleItemDto;
import app.campus.heart.com.campus.data.dto.TopArticleDto;
import app.campus.heart.com.campus.data.dto.UserDto;
import app.campus.heart.com.campus.ui.adapter.ImageCardViewPagerAdapter;
import app.campus.heart.com.campus.ui.adapter.QzbsRecyclerviewAdapter;
import app.campus.heart.com.campus.ui.adapter.RecycleViewDivider;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 通用模块 页面
 *
 * @author: Veyron
 * @date：2017/11/30
 */
public class ModuleActivity extends AppCompatActivity
        implements Toolbar.OnMenuItemClickListener, AdapterView.OnItemSelectedListener, SwipeRefreshLayout.OnRefreshListener
        , OnBannerListener {

    @BindView(R.id.viewPager)
    ViewPager mViewPager;
    @BindView(R.id.viewcard1)
    ImageView mViewcard1;
    @BindView(R.id.viewcard2)
    ImageView mViewcard2;
    @BindView(R.id.viewcard3)
    ImageView mViewcard3;
    @BindView(R.id.viewcard4)
    ImageView mViewcard4;
    @BindView(R.id.viewcard5)
    ImageView mViewcard5;
    @BindView(R.id.viewcard1_bg)
    FrameLayout mViewcard1Bg;
    @BindView(R.id.viewcard2_bg)
    FrameLayout mViewcard2Bg;
    @BindView(R.id.viewcard3_bg)
    FrameLayout mViewcard3Bg;
    @BindView(R.id.viewcard4_bg)
    FrameLayout mViewcard4Bg;
    @BindView(R.id.viewcard5_bg)
    FrameLayout mViewcard5Bg;

    @BindView(R.id.blurView)
    ImageView mBlurView;       //背景，采用高斯模糊

    @BindView(R.id.swipe_common)
    SwipeRefreshLayout mSwipe;

    @BindView(R.id.hot_postlist_common)
    RecyclerView mHotPostlist;

    @BindView(R.id.scrollView_common)
    NestedScrollView mScrollView;

    @BindView(R.id.add_orders)
    AddFloatingActionButton mAddOrders;

    @BindView(R.id.module_name)
    TextView mModuleName;

    QzbsRecyclerviewAdapter mAdapter;
    List<ArticleItemDto> mList = new ArrayList<>();

    private int postType = 1;
    private boolean isLoading = false;  //判断是否加载更多，避免重复请求网络
    private boolean isLogined = false;  //判断是否登录
    private Integer currentPage = 1;
    private Integer nextPage = 1;
    private Integer lastPage = 1;

    //创建一个线性布局管理器
    LinearLayoutManager layoutManager;

    List<TopArticleDto> mBeenList = new ArrayList<>();

    ImageCardViewPagerAdapter mCardViewPagerAdapter;

    List<FrameLayout> mViewCardBgList = new ArrayList<>();

    private int currentPosition;

    private PostPresenter mPresenter;

    private Handler handler = new Handler();

    private int index = 1;

    Result<UserDto> mResult;

    private Context mContext = ModuleActivity.this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_module);
        ButterKnife.bind(this);

        mSwipe.setOnRefreshListener(this);
        mSwipe.setColorSchemeResources(R.color.colorAccent, R.color.colorPrimary, R.color.colorPrimaryDark);

        initLoginCheck();

        initData();

        initView();

        setListener();

        setTimer(8000);//定时器，让 viewPager 自动变换

    }

    /**
     * 定时器，让 viewPager 自动变换
     *
     * @param time
     */
    private void setTimer(int time) {
        RxTimerUtil.interval(time, new RxTimerUtil.IRxNext() {
            @Override
            public void doNext(long number) {
                int count = mCardViewPagerAdapter.getCount();
                if (count > 2) {
                    int index = mViewPager.getCurrentItem();
                    index = index + 1;
                    mViewPager.setCurrentItem(index, true);
                }
            }
        });
    }

    /**
     * 初始化数据
     */
    private void initData() {

        postType = getIntent().getIntExtra(Constants.POSTTYPE, 1);

        mModuleName.setText(getIntent().getStringExtra("moduleName"));

        mResult = (Result<UserDto>) SharePresUtil.getObjectFromSharePres(this, "userObject");

        mPresenter = new PostPresenter(new CallBack<List<TopArticleDto>>() {
            @Override
            public void showResult(Result<List<TopArticleDto>> result) {
                LogUtil.E(result.toString());
                if (result.getContent() != null) {
                    mBeenList = result.getContent();
                    mBeenList.add(0, result.getContent().get(4));
                    mBeenList.add(result.getContent().get(0));

                    mCardViewPagerAdapter = new ImageCardViewPagerAdapter(mContext, mBeenList);
                    mViewPager.setAdapter(mCardViewPagerAdapter);
                    mViewPager.setCurrentItem(1);
                }
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {
                LogUtil.E("showError " + msg);

                TopArticleDto bean1 = new TopArticleDto();
                bean1.setPicUrl("http://oo3blvlgf.bkt.clouddn.com/test_pic.png");
                bean1.setUserName("1龙");
                bean1.setSite("天津1");
                bean1.setTitle("怎么说起，又怎能忘记，有怎能..");

                TopArticleDto bean2 = new TopArticleDto();
                bean2.setPicUrl("http://oo3blvlgf.bkt.clouddn.com/test_pic2.png");
                bean2.setUserName("2龙");
                bean2.setSite("天津2");
                bean2.setTitle("怎么说起，又怎能忘记，有怎能..");

                TopArticleDto bean3 = new TopArticleDto();
                bean3.setPicUrl("http://oo3blvlgf.bkt.clouddn.com/test_pic3.png");
                bean3.setUserName("3龙");
                bean3.setSite("天津3");
                bean3.setTitle("怎么说起，又怎能忘记，有怎能..");

                TopArticleDto bean4 = new TopArticleDto();
                bean4.setPicUrl("http://oo3blvlgf.bkt.clouddn.com/test_pic4.jpg");
                bean4.setUserName("4龙");
                bean4.setSite("天津4");
                bean4.setTitle("怎么说起，又怎能忘记，有怎能..");

                TopArticleDto bean5 = new TopArticleDto();
                bean5.setPicUrl("http://oo3blvlgf.bkt.clouddn.com/test_pic5.png");
                bean5.setUserName("5龙");
                bean5.setSite("天津5");
                bean5.setTitle("怎么说起，又怎能忘记，有怎能..");

                mBeenList.add(bean5);
                mBeenList.add(bean1);
                mBeenList.add(bean2);
                mBeenList.add(bean3);
                mBeenList.add(bean4);
                mBeenList.add(bean5);
                mBeenList.add(bean1);

                initSmallViewCard();

                mCardViewPagerAdapter = new ImageCardViewPagerAdapter(getApplicationContext(), mBeenList);
                mViewPager.setAdapter(mCardViewPagerAdapter);
                mViewPager.setCurrentItem(1);
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E(msg);
                initSmallViewCard();
            }
        }, RetrofitGenerateor.generateCommon());
        mPresenter.getTopArticle(postType);


        mViewCardBgList.add(mViewcard1Bg);
        mViewCardBgList.add(mViewcard2Bg);
        mViewCardBgList.add(mViewcard3Bg);
        mViewCardBgList.add(mViewcard4Bg);
        mViewCardBgList.add(mViewcard5Bg);


        //创建一个线性布局管理器
        layoutManager = new LinearLayoutManager(this);
        mHotPostlist.setLayoutManager(layoutManager);
        mHotPostlist.setFocusable(false);
        // 取消列表的焦点，解决切换fragment时自动下滑列表导致的bug

        //添加分割线
        mHotPostlist.addItemDecoration(new RecycleViewDivider(getApplicationContext(), R.drawable.divider_mileage));
        mHotPostlist.setNestedScrollingEnabled(false);//解决滑动缓慢问题

        ((SimpleItemAnimator) mHotPostlist.getItemAnimator())
                .setSupportsChangeAnimations(false);  //解决刷新抖动问题

        // 对 mScrollView 的滑动监听
        if (mScrollView != null) {

            mScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {
                @Override
                public void onScrollChange(NestedScrollView v, int scrollX,
                                           int scrollY, int oldScrollX, int oldScrollY) {

                    if (scrollY > oldScrollY) {
                        LogUtil.E("下滑...");
                        mAddOrders.setAlpha(0.2f);
                    }
                    if (scrollY < oldScrollY) {
                        LogUtil.E("上滑");
                        mAddOrders.setAlpha(0.2f);
                    }

                    if (scrollY == 0) {
                        LogUtil.E("滑动到顶部");
                        mAddOrders.setAlpha(1f);
                    }

                    if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {
                        LogUtil.E("滑动到底部");

                        // 当前屏幕所看到的子项个数
                        int lastVisibleItemPosition = layoutManager.findLastVisibleItemPosition();
                        // 再次判断是否滑动到 recycleView 显示当前页数据的底部
                        if (lastVisibleItemPosition + 1 == mAdapter.getItemCount()) {
                            if (!isLoading) {
                                isLoading = true;
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        isLoading = false;
                                        loadMoreData();
                                    }
                                }, 10);
                            }
                        }
                    }

                }
            });
        }
        initItemList();

        mScrollView.setFocusable(true);
        mScrollView.setFocusableInTouchMode(true);
        mScrollView.requestFocus();
        mScrollView.scrollTo(0, 0);  // 保证滑动到顶部
    }

    private void initItemList() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

        mPresenter = new PostPresenter(new CallBack<PageList<ArticleItemDto>>() {
            @Override
            public void showResult(final Result<PageList<ArticleItemDto>> result) {
                currentPage = result.getContent().getPaginator().getPage();
                nextPage = result.getContent().getPaginator().getNextPage();
                lastPage = result.getContent().getPaginator().getLastPage();

                if (currentPage == 1) {
                    mList = result.getContent().getDataList();
                    LogUtil.E("拉取的数据： " + mList.toString());
                    mAdapter = new QzbsRecyclerviewAdapter(mContext, mList);
                    mHotPostlist.setAdapter(mAdapter);
                    isLoading = false;
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);

                    mAdapter.setOnItemClickListener(new QzbsRecyclerviewAdapter.OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, int position) {
                            LogUtil.E("Hot 点击事件" + mAdapter.getList().get(position).getPostId());
                            //先判断是否登录
                            if (mResult == null) {
                                Toast.makeText(mContext,
                                        "您未登录,请先登录", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(
                                        mContext, LoginActivity.class));

                            } else {
                                isLogined = true;
                                Long postId = mAdapter.getList().get(position).getPostId();
                                LogUtil.E("Hot 点击事件" + postId);
                                Intent intent = new Intent(mContext, ArticleActivity.class);
                                intent.putExtra("postId", postId);
                                startActivity(intent);
                            }
                        }

                        @Override
                        public void onItemLongClick(View view, int position) {
                        }
                    });

                } else if (currentPage < result.getContent().getPaginator().getPages()) {
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);
                    mAdapter.notifyItemChanged(1, 1);
                    isLoading = false;
                } else if (currentPage == lastPage) {
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);
                    mAdapter.notifyItemChanged(1, 1);
                }
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {
                LogUtil.E("错误信息： " + msg.toString());
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E("成功信息： " + msg.toString());
            }
        }, retrofit);

        getData();
    }

    private void initSmallViewCard() {
        Glide.with(this).load(mBeenList.get(1).getPicUrl()).into(mViewcard1);
        Glide.with(this).load(mBeenList.get(2).getPicUrl()).into(mViewcard2);
        Glide.with(this).load(mBeenList.get(3).getPicUrl()).into(mViewcard3);
        Glide.with(this).load(mBeenList.get(4).getPicUrl()).into(mViewcard4);
        Glide.with(this).load(mBeenList.get(5).getPicUrl()).into(mViewcard5);
    }


    private void initView() {
        ButterKnife.bind(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        this.setSupportActionBar(toolbar);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setDisplayShowTitleEnabled(false);
        }

        toolbar.setOnMenuItemClickListener(this);
        // 设置点击事件监听
        mAddOrders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 先判断用户是否登录
                if (mResult == null) {
                    Toast.makeText(mContext,
                            "您未登录,请先登录", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(
                            mContext, LoginActivity.class));

                } else {
                    Intent intent = new Intent(mContext, PostingActivity.class);
                    intent.putExtra("postType", postType);
                    startActivityForResult(intent, postType);
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // 发帖成功，返回七嘴八舌页面后刷新列表
        if (requestCode == 1 && resultCode == 1) {
            String s = data.getStringExtra("refresh");
            if (s.equals("1")) {
                getData();
            }
        }
    }

    private void setListener() {
        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                LogUtil.E("onPageSelected:" + position);
                currentPosition = position;

                setSmallCardViewBorder(currentPosition);
                //initBlurBackground(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                if (state == ViewPager.SCROLL_STATE_IDLE) {
                    if (currentPosition == mViewPager.getAdapter().getCount() - 1) {
                        mViewPager.setCurrentItem(1, false);
                    } else if (currentPosition == 0) {
                        mViewPager.setCurrentItem(mViewPager.getAdapter().getCount() - 2, false);
                    }
                }
            }
        });
    }

    private void setSmallCardViewBorder(int position) {
        if (position == 0) {
            mViewCardBgList.get(4).setBackgroundResource(R.drawable.small_viewcard_boder);
        } else {
            mViewCardBgList.get(4).setBackgroundResource(R.drawable.null_viewcard_boder);
        }
        if (position == 6) {
            mViewCardBgList.get(0).setBackgroundResource(R.drawable.small_viewcard_boder);
        } else {
            mViewCardBgList.get(0).setBackgroundResource(R.drawable.null_viewcard_boder);
        }

        for (int i = 0; i < 5; i++) {
            if (i == position - 1) {
                mViewCardBgList.get(i).setBackgroundResource(R.drawable.small_viewcard_boder);
            } else {
                mViewCardBgList.get(i).setBackgroundResource(R.drawable.null_viewcard_boder);
            }
        }
    }

    @Override
    protected void onDestroy() {
        RxTimerUtil.cancel();
        super.onDestroy();
    }

    @OnClick({R.id.viewcard1, R.id.viewcard2, R.id.viewcard3, R.id.viewcard4, R.id.viewcard5})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.viewcard1:
                mViewPager.setCurrentItem(1, false);
                break;
            case R.id.viewcard2:
                mViewPager.setCurrentItem(2, false);
                break;
            case R.id.viewcard3:
                mViewPager.setCurrentItem(3, false);
                break;
            case R.id.viewcard4:
                mViewPager.setCurrentItem(4, false);
                break;
            case R.id.viewcard5:
                mViewPager.setCurrentItem(5, false);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void OnBannerClick(int position) {
        Toast.makeText(this, "Banner点击事件" + position, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRefresh() {
        // 开始刷新，设置当前为刷新状态
        mSwipe.setRefreshing(true);

        isLoading = false;

        // 下拉刷新操作：获取新数据
        getData();
    }

    private void getData() {
        LogUtil.E("刷新数据");
        if (!mList.isEmpty()) {
            mList.clear();
        }
        mPresenter.getArticleItemList(postType, null);
        mSwipe.setRefreshing(false);
        index = 1;
        setLoadingFooter(true);
    }


    private void loadMoreData() {
        index++;

        if (index > lastPage) {
            LogUtil.E("已经没有新的了");
            setLoadingFooter(false);
            mAdapter.notifyItemRemoved(mAdapter.getItemCount());
        } else {
            LogUtil.E("加载更多数据");
            setLoadingFooter(true);
            mPresenter.getArticleItemList(postType, nextPage);
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    private void initLoginCheck() {
        mResult = (Result<UserDto>) SharePresUtil.getObjectFromSharePres(this, "userObject");
        if (mResult != null) {
            isLogined = true;
        }
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_search:
                Intent intent = new Intent(getApplicationContext(), SearchActivity.class);
                startActivity(intent);
        }
        return false;
    }

    /**
     * 菜单栏功能选择
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            mAdapter.setLoadingFooter(true);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * 设置底部是否显示"已加载完毕"
     * @param loading
     */
    private void setLoadingFooter(Boolean loading) {
        if (mAdapter != null) {
            if (loading) {
                mAdapter.setLoadingFooter(true);
            }
            if (loading && mAdapter.getItemCount() > 5) {
                mAdapter.setLoadingFooter(true);
            } else {
                mAdapter.setLoadingFooter(false);
            }
        }
    }
}
