package app.campus.heart.com.campus.controller.persenter;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.controller.contact.BaseContact;
import app.campus.heart.com.campus.data.api.UserApiService;
import app.campus.heart.com.campus.data.bean.RegisterRequestBean;
import app.campus.heart.com.campus.data.model.RegisterModel;
import app.campus.heart.com.campus.ui.fragment.base.BaseView;
import retrofit2.Retrofit;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * 注册 Presenter
 *
 * @author: Veyron
 * @date：2017/11/21
 */
public class RegisterPresenter implements BaseContact.RegisterPersenter{
    private RegisterModel mRegisterModel;
    private BaseView mBaseView;
    private UserApiService mApiService;

    public RegisterPresenter(BaseView baseView,Retrofit retrofit) {
        mBaseView = baseView;
        mApiService = retrofit.create(UserApiService.class);
        mRegisterModel = new RegisterModel(mApiService);
    }


    @Override
    public void Register(RegisterRequestBean bean) {
        /**
         *  使用Rxjava 链式调用
         */
     mRegisterModel.register(bean)
             .subscribeOn(Schedulers.io())
             .observeOn(AndroidSchedulers.mainThread())
             .subscribe(new Subscriber<Result<Long>>() {
                 @Override
                 public void onStart() {
                     mBaseView.showLodading();
                     super.onStart();
                 }

                 @Override
                 public void onCompleted() {
                     mBaseView.dimissLoading();
                 }

                 @Override
                 public void onError(Throwable e) {
                      mBaseView.dimissLoading();
                      mBaseView.showError(e.toString());
                 }

                 @Override
                 public void onNext(Result<Long> result) {

                           if (result.isSuccess()){
                               mBaseView.showSuccess(result.getContent().toString());
                           }else{
                               mBaseView.showError("注册失败");
                           }

                 }
             });
    }
}
