package app.campus.heart.com.campus.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.OrientationHelper;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.generator.SpotDialogGenerator;
import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.token.RetrofitGenerateor;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.LoginUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.contact.CallBackHandle;
import app.campus.heart.com.campus.controller.persenter.CommentPresenter;
import app.campus.heart.com.campus.data.dto.MyCommentDto;
import app.campus.heart.com.campus.ui.adapter.CommentsRviewAdapter;
import app.campus.heart.com.campus.ui.adapter.RecycleViewDivider;
import app.campus.heart.com.campus.ui.customs.CommentListItemRemoveRecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dmax.dialog.SpotsDialog;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class CommentsActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    @BindView(R.id.go_back)
    ImageView mGoBack;
    @BindView(R.id.comment_search)
    ImageView mCommentSearch;
    @BindView(R.id.swipe_common)
    SwipeRefreshLayout mSwipeCommon;
    @BindView(R.id.commentlist)
    CommentListItemRemoveRecyclerView mCommentlist;

    CommentPresenter mPresenter;
    CommentsRviewAdapter mAdapter;

    List<MyCommentDto> mList = new ArrayList<>();

    private boolean isLoading = false;  //判断是否加载更多，避免重复请求网络
    private Integer currentPage = 1;
    private Integer nextPage = 1;
    private Integer lastPage = 1;

    //创建一个线性布局管理器
    LinearLayoutManager mLayoutManager;

    private Handler handler = new Handler();

    private int index = 1;

    private Retrofit retrofit;

    private SpotsDialog mDialog;
    private SpotsDialog mRefreshingDialog;
    private String userId;
    private String password;

    CallBackHandle<Result<PageList<MyCommentDto>>> callBackHandle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comments);
        ButterKnife.bind(this);
        userId = getIntent().getStringExtra("userId");
        password = getIntent().getStringExtra("password");

        mDialog = new SpotsDialog(this, "夺命加载中....");
        mRefreshingDialog = SpotDialogGenerator.refreshSpotsDialog(this);

        initView();
        initData();

        mAdapter = new CommentsRviewAdapter(CommentsActivity.this, mList);
        mCommentlist.setAdapter(mAdapter);

        initCommentLists();
    }

    private void initData() {
        initRetrofit();
        mLayoutManager = new LinearLayoutManager(this);
        mLayoutManager.setOrientation(OrientationHelper.VERTICAL);
        mCommentlist.setLayoutManager(mLayoutManager);
        mCommentlist.setFocusable(false);
        // 取消列表的焦点，解决切换fragment时自动下滑列表导致的bug
        //添加分割线
        mCommentlist.addItemDecoration(new RecycleViewDivider(this, R.drawable.divider_mileage));
        //mMyPostlist.setNestedScrollingEnabled(false);//解决滑动缓慢问题


        //mHotPostlist.setItemAnimator(new DefaultItemAnimator());
        ((SimpleItemAnimator) mCommentlist.getItemAnimator())
                .setSupportsChangeAnimations(false);  //解决刷新抖动问题

        mCommentlist.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_STATE_SETTLING) {
                    int lastVisiableItemPosition = mLayoutManager.findLastVisibleItemPosition();
                    if (lastVisiableItemPosition + 2 >= mAdapter.getItemCount() && index <= lastPage) {
                        if (!isLoading) {
                            isLoading = true;
                            //setLoadingFooter(isLoading);
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    loadMoreData();
                                    isLoading = false;
                                }
                            }, 10);
                        }
                    }
                }
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if (dy > 0) {
                    LogUtil.E("dy:== " + dy + "");
                    if (dy > 55) {
                        setLoadingFooter(true);
                    }
                }
            }
        });
    }

    private void initCommentLists() {

        //Tony Add
        callBackHandle = new CallBackHandle<Result<PageList<MyCommentDto>>>() {
            @Override
            public void showError(Result<PageList<MyCommentDto>> result, String... failMessages) {
                for (String failMessage : failMessages) {
                    LogUtil.E("请求失败", failMessage);
                    finish();
                    LoginUtil.requestLogin(CommentsActivity.this);
                }
            }

            @Override
            public void showSuccess(Result<PageList<MyCommentDto>> result, String... successfulMessages) {
                currentPage = result.getContent().getPaginator().getPage();
                nextPage = result.getContent().getPaginator().getNextPage();
                lastPage = result.getContent().getPaginator().getLastPage();

                if (currentPage == 1) {
                    mList = result.getContent().getDataList();
                    LogUtil.E("拉取的数据： " + mList.toString());
                    mAdapter = new CommentsRviewAdapter(CommentsActivity.this, mList);
                    mCommentlist.setAdapter(mAdapter);
                    isLoading = false;
                    mCommentlist.setOnItemClickListener(new CommentListItemRemoveRecyclerView
                            .OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, int position) {
                            Long postId = mAdapter.getList().get(position).getPostId();
                            LogUtil.E("Hot 点击事件" + postId);
                            Intent intent = new Intent(
                                    CommentsActivity.this, ArticleActivity.class);
                            intent.putExtra("postId", postId);
                            startActivity(intent);
                        }

                        @Override
                        public void onDeleteClick(int position) {
                            LogUtil.E("item 点击删除");
                            if (mAdapter.getList().get(position).getDeleteState()) {
                                LogUtil.E("item 执行 删除");
                                Long commentId = mAdapter.getList().get(position).getCommentId();
                                deleteItem(position, commentId.intValue());
                            }
                        }
                    });
                    mRefreshingDialog.dismiss();
                } else if (currentPage < result.getContent().getPaginator().getPages()) {
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);
                    mAdapter.notifyItemChanged(1, 1);
                    isLoading = false;
                } else if (currentPage == lastPage) {
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);
                    mAdapter.notifyItemChanged(1, 1);
                }
                mDialog.cancel();
            }

            @Override
            public void showLinkError(String message) {
                LogUtil.E("拉取的数据： " + mList.toString());
            }
        };
        //Tony End


        mPresenter = new CommentPresenter(new CallBack<PageList<MyCommentDto>>() {
            @Override
            public void showResult(Result<PageList<MyCommentDto>> result) {
                currentPage = result.getContent().getPaginator().getPage();
                nextPage = result.getContent().getPaginator().getNextPage();
                lastPage = result.getContent().getPaginator().getLastPage();


                if (currentPage == 1) {
                    mList = result.getContent().getDataList();
                    LogUtil.E("拉取的数据： " + mList.toString());
//                    mAdapter.addAll(mList);
//                    mAdapter.notifyDataSetChanged();
                    mAdapter = new CommentsRviewAdapter(CommentsActivity.this, mList);
                    mCommentlist.setAdapter(mAdapter);

                    isLoading = false;
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);

                    mCommentlist.setOnItemClickListener(new CommentListItemRemoveRecyclerView
                            .OnItemClickListener() {
                        @Override
                        public void onItemClick(View view, int position) {
                            Long postId = mAdapter.getList().get(position).getPostId();
                            LogUtil.E("Hot 点击事件" + postId);
                            Intent intent = new Intent(
                                    CommentsActivity.this, ArticleActivity.class);
                            intent.putExtra("postId", postId);
                            startActivity(intent);
                        }

                        @Override
                        public void onDeleteClick(int position) {
                            LogUtil.E("item 点击删除");
                            if (mAdapter.getList().get(position).getDeleteState()) {
                                LogUtil.E("item 执行 删除");
                                Long commentId = mAdapter.getList().get(position).getCommentId();
                                deleteItem(position, commentId.intValue());
                            }
                        }
                    });
                    mRefreshingDialog.dismiss();
                } else if (currentPage < result.getContent().getPaginator().getPages()) {
                    mList = result.getContent().getDataList();

                    mAdapter.addAll(mList);
                    //mAdapter.notifyDataSetChanged();
                    mAdapter.notifyItemChanged(1, 1);
                    isLoading = false;
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);
                } else if (currentPage == lastPage) {
                    mList = result.getContent().getDataList();
                    mAdapter.addAll(mList);

                    //mAdapter.notifyDataSetChanged();
                    mAdapter.notifyItemChanged(1, 1);
                    //请求完成结束刷新状态
                    //mSwipe.setRefreshing(false);
                }
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {
                mDialog.cancel();
            }

            @Override
            public void showError(String msg) {
                //LogUtil.E("错误信息： " + msg.toString());
                finish();
                LoginUtil.requestLogin(CommentsActivity.this);
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E("成功信息： " + msg.toString());
            }
        }, retrofit);
        getData();
    }

    //点击删除
    private void deleteItem(final int position, Integer commentId) {
        LogUtil.E("准备发起删除: " + commentId);

        mPresenter = new CommentPresenter(new CallBack() {
            @Override
            public void showResult(Result result) {

            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {
                LogUtil.E(msg);
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E(msg);
                // 更新列表
                mAdapter.removeItem(position);
            }
        }, retrofit);
        // 发起删除

        LogUtil.E("用户ID: " + userId + "密码: " + password + "评论ID: " + commentId.longValue());
        mPresenter.deleteItem(userId, password, commentId.longValue());
    }

    private void setLoadingFooter(Boolean loading) {
        if (loading) {
            mAdapter.setLoadingFooter(true);
        }
        if (loading && mAdapter.getItemCount() > 5) {
            mAdapter.setLoadingFooter(true);
        } else {
            mAdapter.setLoadingFooter(false);
        }
    }

    private void getData() {
        LogUtil.E("刷新数据");
        if (!mList.isEmpty()) {
            mList.clear();
        }
        //mPresenter.getAllComments(1, userId);
        mPresenter.getAllCommentsNew(callBackHandle, 1, userId);
        mSwipeCommon.setRefreshing(false);
        index = 1;
    }

    private void loadMoreData() {
        index++;
        //mSwipe.setRefreshing(true);
        //setLoadingFooter(true);
        if (index > lastPage) {
            setLoadingFooter(false);
            LogUtil.E("已经没有新的了");
            //Toast.makeText(this, "已经没有新的了", Toast.LENGTH_SHORT).show();
            mAdapter.notifyItemRemoved(mAdapter.getItemCount());
            //mSwipe.setRefreshing(false);
        } else {
            LogUtil.E("加载更多数据");
            //mPresenter.getAllComments(nextPage, userId);
            mPresenter.getAllCommentsNew(callBackHandle, nextPage, userId);
        }
    }

    private void initRetrofit() {
        retrofit = RetrofitGenerateor.generateAuthorization(CommentsActivity.this);
    }

    private void initView() {
        mDialog.show();
        mSwipeCommon.setOnRefreshListener(this);
        mSwipeCommon.setColorSchemeResources
                (R.color.colorAccent, R.color.colorPrimary, R.color.colorPrimaryDark);
    }

    @OnClick({R.id.go_back, R.id.comment_search})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.go_back:
                finish();
                break;
            case R.id.comment_search:
                Toast.makeText(this, "别急，先玩其他功能嘛", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public void onRefresh() {
        // 开始刷新，设置当前为刷新状态
        mSwipeCommon.setRefreshing(true);

        isLoading = false;

        mRefreshingDialog.show();
        // 下拉刷新操作：获取新数据
        getData();
    }
}
