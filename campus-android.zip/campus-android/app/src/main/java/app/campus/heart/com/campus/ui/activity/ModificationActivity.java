package app.campus.heart.com.campus.ui.activity;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestManager;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.File;
import java.util.ArrayList;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.token.RetrofitGenerateor;
import app.campus.heart.com.campus.common.utils.KeyBoardUtil;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.LoginUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.UserPresenter;
import app.campus.heart.com.campus.data.bean.UpDateRequestBean;
import app.campus.heart.com.campus.data.dto.UserDto;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dmax.dialog.SpotsDialog;
import gun0912.tedbottompicker.TedBottomPicker;
import jp.wasabeef.glide.transformations.CropCircleTransformation;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

public class ModificationActivity extends AppCompatActivity {

    @BindView(R.id.cancel)
    TextView mCancel;
    @BindView(R.id.icon)
    ImageView mIcon;
    @BindView(R.id.ly_icon)
    LinearLayout mLyIcon;
    @BindView(R.id.user_name)
    EditText mUserName;

    @BindView(R.id.re_password)
    EditText mRePassword;
    @BindView(R.id.stuno)
    EditText mStuno;
    @BindView(R.id.college)
    EditText mCollege;
    @BindView(R.id.major)
    EditText mMajor;
    @BindView(R.id.phone)
    EditText mPhone;
    @BindView(R.id.spinner_sex)
    Spinner mSpinnerSex;
    @BindView(R.id.dormitory)
    EditText mDormitory;
    @BindView(R.id.just_modified)
    Button mJustModified;

    public RequestManager mGlideRequestManager;
    Uri selectedUri;
    @BindView(R.id.re_password_layout)
    TextInputLayout re_mPasswordLayout;
    @BindView(R.id.new_password_layout)
    TextInputLayout mNewPasswordLayout;
    @BindView(R.id.old_password)
    EditText mOldPassword;
    @BindView(R.id.new_password)
    EditText mNewPassword;


    private Retrofit retrofit;
    private UserPresenter mPresenter;

    Result<UserDto> result;
    private SpotsDialog mDialog;

    private Boolean isUpDateImgSuccess = false;

    private Boolean isUpDatePassword = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modification);
        ButterKnife.bind(this);
        mGlideRequestManager = Glide.with(this);

        initData();
        initRetrofit();
        initPswListener();

        mDialog = new SpotsDialog(
                ModificationActivity.this, "正在提交");

    }

    private void initPswListener() {
        mOldPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // 将 确认密码  布局  显示出来
                re_mPasswordLayout.setVisibility(View.VISIBLE);
                mNewPasswordLayout.setVisibility(View.VISIBLE);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // 将  确认密码  布局  隐藏起来
                if (s.toString().trim().isEmpty()) {
                    re_mPasswordLayout.setVisibility(View.GONE);
                    mNewPasswordLayout.setVisibility(View.GONE);
                    mRePassword.setText("");
                    mNewPassword.setText("");
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    // 数据回显
    private void initData() {

        result = (Result<UserDto>) SharePresUtil
                .getObjectFromSharePres(this, "userObject");

        if (result != null) {
            Glide.with(this).load(result.getContent()
                    .getUserLogo()).bitmapTransform(new
                    CropCircleTransformation(this)).override(48, 48)
                    .error(R.drawable.login_icon)
                    .skipMemoryCache(true).diskCacheStrategy
                    (DiskCacheStrategy.NONE).into(mIcon);

            mUserName.setText(result.getContent().getUserName());
            mStuno.setText(result.getContent().getUserId());
            mCollege.setText(result.getContent().getUserSchool());
            mMajor.setText(result.getContent().getUserSubject());
            mPhone.setText(result.getContent().getUserPhone());
            mSpinnerSex.setSelection(result.getContent().getUserGender());
            mDormitory.setText(result.getContent().getUserAddress());
        }
    }

    private void initRetrofit() {
        retrofit = RetrofitGenerateor.generateAuthorization(ModificationActivity.this);
    }

    @OnClick({R.id.cancel, R.id.ly_icon, R.id.just_modified})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cancel:
                finish();
                break;
            case R.id.ly_icon:
                // 点击修改头像
                getIcon();
                break;
            case R.id.just_modified:
                // 提交修改

                Intent i = new Intent();
                i.putExtra("refresh", "1");
                setResult(1, i);

                checkInputAndCommit();
                break;
        }
    }

    private void checkInputAndCommit() {
        // 检查无误发起修改请求
        mPresenter = new UserPresenter(new CallBack() {
            @Override
            public void showResult(Result result) {
                // 返回结果，更新 全局对象 Resutl<userDto>
                SharePresUtil.setObject2SharePres(
                        ModificationActivity.this, result, "userObject");
            }

            @Override
            public void showLodading() {
                mDialog.show();
            }

            @Override
            public void dimissLoading() {
                mDialog.dismiss();
            }

            @Override
            public void showError(String msg) {
                LogUtil.E("个人信息修改失败信息：" + msg);
                Toast.makeText(ModificationActivity.this,
                        "请求失败", Toast.LENGTH_LONG).show();
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E("个人信息修改成功信息：" + msg);
                Toast.makeText(ModificationActivity.this,
                        "修改成功", Toast.LENGTH_LONG).show();
                isUpDateImgSuccess = true;

                KeyBoardUtil.hideSoftInputMethod(ModificationActivity.this);
            }
        }, retrofit);

        // 校验输入项
        if (inPutAllOk()) {
            // 构建请求参数
            UpDateRequestBean bean = new UpDateRequestBean();
            bean.setId(result.getContent().getId());     //唯一id,根据登录返回的 result 获取
            bean.setName(mUserName.getText().toString());
            bean.setUserId(mStuno.getText().toString());
            bean.setPhone(mPhone.getText().toString());
            bean.setAddress(mDormitory.getText().toString());
            bean.setSubject(mMajor.getText().toString());
            bean.setSchool(mCollege.getText().toString());
            //bean.setGender(1);//暂时使用默认性别
            bean.setGender(mSpinnerSex.getSelectedItemPosition());

            if (isUpDatePassword) {
                bean.setOldPassword(mOldPassword.getText().toString());   // 尴尬的设计
                bean.setNewPassword(mNewPassword.getText().toString());   // 尴尬的设计
            } else {
                // 使用原来密码
                bean.setOldPassword(result.getContent().getUserPassword());
                bean.setNewPassword(result.getContent().getUserPassword());
            }

            LogUtil.E("修改请求参数bean " + bean.toString());
            mPresenter.upDateUserMsg(bean);
        }
    }

    private boolean inPutAllOk() {
        // 单纯进行非空校验
        if (mUserName.getText().toString().trim().isEmpty() || mUserName.getText().toString().length() > 4) {
            Toast.makeText(ModificationActivity.this,
                    "名字最多不能超过4个字,请检查", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mStuno.getText().toString().trim().isEmpty() || mStuno.getText().toString().trim().length() > 16) {
            Toast.makeText(ModificationActivity.this,
                    "学号不能超过16个数字,请检查", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mCollege.getText().toString().trim().isEmpty() || mCollege.getText().toString().trim().length() > 5) {
            Toast.makeText(ModificationActivity.this,
                    "学院长度不能超过5个字，建议使用简称", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mMajor.getText().toString().trim().isEmpty() || mMajor.getText().toString().trim().length() > 8) {
            Toast.makeText(ModificationActivity.this,
                    "专业名称不能超过8个字，建议使用简称", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mPhone.getText().toString().trim().isEmpty() || mPhone.getText().toString().trim().length() > 11) {
            Toast.makeText(ModificationActivity.this,
                    "手机号码不能超过11个数字，请检查", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mDormitory.getText().toString().trim().isEmpty() || mDormitory.getText().toString().trim().length() > 12) {

            Toast.makeText(ModificationActivity.this,
                    "宿舍地址不能超过12个字，请检查", Toast.LENGTH_LONG).show();
            return false;
        }
        if (mOldPassword.getText().toString().trim().isEmpty()
                && mNewPassword.getText().toString().trim().isEmpty()) {
            //mOldPassword.setText(result.getContent().getUserPassword()); // 用回原来的密码
            //mNewPassword.setText(result.getContent().getUserPassword()); // 用回原来的密码

            // 隐藏
            //re_mPasswordLayout.setVisibility(View.GONE);
            //mNewPasswordLayout.setVisibility(View.GONE);

            isUpDatePassword = false;

            return true;
        } else if (!mOldPassword.getText().toString().trim().isEmpty()
                && !mRePassword.getText().toString().trim().isEmpty()
                && !mNewPassword.getText().toString().trim().isEmpty()) {

            if (mRePassword.getText().toString().trim().
                    equals(mNewPassword.getText().toString().trim())) {

                return true;

            } else {

                Toast.makeText(ModificationActivity.this,
                        "新密码与确认密码不相同，请检查", Toast.LENGTH_LONG).show();
                return false;
            }

        } else {
            Toast.makeText(ModificationActivity.this,
                    "密码输入项不能为空", Toast.LENGTH_LONG).show();
        }
        return false;
    }

    private void getIcon() {
        PermissionListener permissionlistener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {

                TedBottomPicker bottomSheetDialogFragment = new TedBottomPicker.Builder(ModificationActivity.this)
                        .setOnImageSelectedListener(new TedBottomPicker.OnImageSelectedListener() {
                            @Override
                            public void onImageSelected(final Uri uri) {
                                LogUtil.E("uri: " + uri);
                                LogUtil.E("uri.getPath(): " + uri.getPath());
                                LogUtil.E("environment " + Environment.getExternalStorageDirectory());

                                selectedUri = uri;

                                upLoadImg(uri.getPath());
                            }

                        })
                        //.setPeekHeight(getResources().getDisplayMetrics().heightPixels/2)
                        .setSelectedUri(selectedUri)
                        .setPeekHeight(600)
                        .create();

                bottomSheetDialogFragment.show(getSupportFragmentManager());
            }

            @Override
            public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                Toast.makeText(ModificationActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
            }
        };

        new TedPermission(ModificationActivity.this)
                .setPermissionListener(permissionlistener)
                .setDeniedMessage("If you reject permission,you can not use this service\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                .check();

    }

    // 真正发起网络请求
    private void upLoadImg(String url) {
        mPresenter = new UserPresenter(new CallBack() {
            @Override
            public void showResult(Result s) {
                LogUtil.E(s.getContent() + "");
                result.getContent().setUserLogo((String) s.getContent());
                Boolean t = SharePresUtil.setObject2SharePres(
                        ModificationActivity.this, result, "userObject");
                LogUtil.E("修改完头像后,sp返回值 " + t);
                LogUtil.E(result.toString());
            }

            @Override
            public void showLodading() {
                mDialog.show();
            }

            @Override
            public void dimissLoading() {
                mDialog.dismiss();
            }

            @Override
            public void showError(String msg) {
                LogUtil.E("错误信息 " + msg);
                Toast.makeText(ModificationActivity.this, msg, Toast.LENGTH_LONG).show();
                finish();
                LoginUtil.requestLogin(ModificationActivity.this);
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E(msg);
                Toast.makeText(ModificationActivity.this,
                        "修改头像成功", Toast.LENGTH_LONG).show();
                isUpDateImgSuccess = true;
                setNewImg();

                // 修改成功才然后 我的 页面刷新头像
                Intent i2 = new Intent();
                i2.putExtra("refresh", "1");
                setResult(1, i2);
            }
        }, retrofit);

        File file = new File(url);

        LogUtil.E("文件大小：" + file.length());
        if (file.length() / 1024 > 200) {
            Toast.makeText(ModificationActivity.this,
                    "暂时不支持大于200KB的图片", Toast.LENGTH_LONG).show();
        } else {
            //构建body
            RequestBody requestBody = new MultipartBody.Builder().setType(MultipartBody.FORM)
                    .addFormDataPart("userId", result.getContent().getUserId())
                    .addFormDataPart("password", result.getContent().getUserPassword())
                    .addFormDataPart("img", file.getName(), RequestBody.create(MediaType.parse("image/*"), file))
                    .build();

            mPresenter.upLoadImg(requestBody);
        }
    }

    private void setNewImg() {
        // 确实上传成功才渲染
        if (isUpDateImgSuccess) {
            mIcon.post(new Runnable() {
                @Override
                public void run() {
                    if (selectedUri != null) {
                        mGlideRequestManager
                                .load(selectedUri)
                                .bitmapTransform(new
                                        CropCircleTransformation(ModificationActivity.this))//成功设置圆型
                                .into(mIcon);//把图片设置进 image 里面
                    }
                }
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        /*Glide.with(this).load(result.getContent()
                .getUserLogo()).bitmapTransform(new
                CropCircleTransformation(this)).override(48, 48)
                .error(R.drawable.login_icon)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .skipMemoryCache(true).into(mIcon);*/
    }
}
