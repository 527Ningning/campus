package app.campus.heart.com.campus.common.enums;

import app.campus.heart.com.campus.common.utils.StringUtil;

/**
 * 功能模块枚举类
 *
 * @author: yuwu
 * @date: 2018/5/13
 */
public enum ModuleEnum {

    七嘴八舌(1),
    约喝约玩(2),
    二手市场(3),
    勤工俭学(4),
    求职天地(5),
    学术殿堂(6),
    失物招领(7),
    校园百科(8),
    校园头条(9),
    讲座分享(10),
    运动健身(11),
    校园表白(12),
    校园公益(13),
    代领快递(14),
    社团天地(15),
    信息反馈(16),
    毕业季节(17),
    西大摄影(18),
    我是吃货(19),
    知音之地(20),
    校车资讯(21),
    培训课程(22),
    比赛资讯(23),
    课程信息(24);

    //校园百科(8)
    private Integer postType;

    ModuleEnum(Integer postType) {
        this.postType = postType;
    }

    public String getModuleName() {
        return this.name();
    }

    public Integer getValue() {
        return postType;
    }

    public static ModuleEnum parseName(Integer value) {
        if (value == null) {
            return null;
        }
        for (ModuleEnum e : ModuleEnum.values()) {
            if (e.getValue().equals(value)) {
                return e;
            }
        }
        return null;
    }
}
