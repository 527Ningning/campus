package app.campus.heart.com.campus.ui.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.token.RetrofitGenerateor;
import app.campus.heart.com.campus.common.token.TokenManager;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.LoginUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.PostPresenter;
import app.campus.heart.com.campus.data.dto.UserDto;
import app.campus.heart.com.campus.ui.activity.CommentsActivity;
import app.campus.heart.com.campus.ui.activity.LoginActivity;
import app.campus.heart.com.campus.ui.activity.ModificationActivity;
import app.campus.heart.com.campus.ui.activity.MyCollectActivity;
import app.campus.heart.com.campus.ui.activity.MyPostsActivity;
import app.campus.heart.com.campus.ui.activity.MyUpvoteActivity;
import app.campus.heart.com.campus.ui.fragment.base.BaseFragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import jp.wasabeef.glide.transformations.CropCircleTransformation;


/**
 * MyDdFragment，主页第三个栏目：我的叮叮
 *
 * @author: Veyron
 * @date：2017/11/22
 */

public class MyDdFragment extends BaseFragment {

    @BindView(R.id.mine_setting)
    ImageView mMineSetting;
    @BindView(R.id.mine_msg)
    ImageView mMineMsg;
    @BindView(R.id.user_icon)
    ImageView mUserIcon;
    @BindView(R.id.user_name)
    TextView mUserName;
    @BindView(R.id.user_school)
    TextView mUserSchool;
    @BindView(R.id.click_login)
    LinearLayout mClickLogin;
    @BindView(R.id.mine_mymsg)
    LinearLayout mMineMymsg;
    @BindView(R.id.mine_mypost)
    LinearLayout mMineMypost;
    @BindView(R.id.mine_mysave)
    LinearLayout mMineMysave;
    @BindView(R.id.mine_comments)
    LinearLayout mMineComments;
    @BindView(R.id.mine_contribution)
    LinearLayout mMineContribution;
    @BindView(R.id.mine_my_answer)
    LinearLayout mMineMyAnswer;
    @BindView(R.id.mine_myactive)
    LinearLayout mMineMyactive;
    @BindView(R.id.mine_logout)
    LinearLayout mMineLogout;

    @BindView(R.id.comment_unread_count)
    TextView mUnreadCommentCount;

    @BindView(R.id.upvote_unread_count)
    TextView mUnreadUpvoteCount;

    Result<UserDto> result;

    Boolean isLogined = true;

    PostPresenter mComentCountPresenter;
    PostPresenter mUpvoteCountPresenter;

    private Handler handler = new Handler();
    private Runnable task;

    @Override
    protected View initView() {
        LayoutInflater mInflater = LayoutInflater.from(mContext);
        View contentView = mInflater.inflate(R.layout.fragment_layout_mydd, null);
        return contentView;
    }

    @Override
    protected void initData() {
        super.initData();

        if (SharePresUtil.getObjectFromSharePres(mContext, "userObject") != null) {

            result = (Result<UserDto>)
                    SharePresUtil.getObjectFromSharePres(mContext, "userObject");

            if (result != null) {

                mUserName.setText(result.getContent().getUserName());
                mUserSchool.setText(result.getContent().getUserSchool());
                Glide.with(mContext).load(result.getContent()
                        .getUserLogo()).bitmapTransform(new
                        CropCircleTransformation(mContext))
                        .override(90, 90).error(R.drawable.login_icon)
                        .skipMemoryCache(true).diskCacheStrategy
                        (DiskCacheStrategy.NONE).into(mUserIcon);
            }
        } else {
            // 未登录
            isLogined = false;
        }

        mComentCountPresenter = new PostPresenter(new CallBack<Integer>() {
            @Override
            public void showResult(Result<Integer> result) {
                LogUtil.E(result.toString());
                if (result.getContent() != 0) {
                    mUnreadCommentCount.setVisibility(View.VISIBLE);
                    mUnreadCommentCount.setText(String.valueOf(result.getContent().intValue()));
                } else {
                    mUnreadCommentCount.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {
                LogUtil.E("showError " + msg);
                //finish();
                //LoginUtil.requestLogin(mContext);
            }

            @Override
            public void showSuccess(String msg) {
                //initWebview();
            }
        }, RetrofitGenerateor.generateAuthorization(mContext));

        mUpvoteCountPresenter = new PostPresenter(new CallBack<Integer>() {
            @Override
            public void showResult(Result<Integer> result) {
                LogUtil.E(result.toString());
                if (result.getContent() != 0) {
                    mUnreadUpvoteCount.setVisibility(View.VISIBLE);
                    mUnreadUpvoteCount.setText(String.valueOf(result.getContent().intValue()));
                } else {
                    mUnreadUpvoteCount.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {
                LogUtil.E("showError " + msg);
                //finish();
                //LoginUtil.requestLogin(mContext);
            }

            @Override
            public void showSuccess(String msg) {
                //initWebview();
            }
        }, RetrofitGenerateor.generateAuthorization(mContext));
        //initTimerTask();

    }

    private void initTimerTask() {
        if (task == null) {
            task = new Runnable() {
                @Override
                public void run() {
                    // mComentCountPresenter.getUnreadCommentCount();
                    //mUpvoteCountPresenter.getUnreadUpvoteCount();
                    if (SharePresUtil.getUnreadComment(mContext) != null && ((Integer) SharePresUtil.getUnreadComment(mContext)) != 0) {
                        mUnreadCommentCount.setVisibility(View.VISIBLE);
                        mUnreadCommentCount.setText(String.valueOf(SharePresUtil.getUnreadComment(mContext)));
                    } else {
                        mUnreadCommentCount.setVisibility(View.INVISIBLE);
                    }
                    if (SharePresUtil.getUnreadUpvote(mContext) != null && ((Integer) SharePresUtil.getUnreadUpvote(mContext)) != 0) {
                        mUnreadUpvoteCount.setVisibility(View.VISIBLE);
                        mUnreadUpvoteCount.setText(String.valueOf(SharePresUtil.getUnreadUpvote(mContext)));
                    } else {
                        mUnreadUpvoteCount.setVisibility(View.INVISIBLE);
                    }

                    LogUtil.E("5秒运行一次");
                    handler.postDelayed(this, 4000);
                }
            };
        }
        handler.postDelayed(task, 100);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (SharePresUtil.getObjectFromSharePres(mContext, "userObject") == null) {
            refreshIcon();
            isLogined = false;
            handler.removeCallbacks(task);
        } else {
            initTimerTask();
            //handler.postDelayed(task, 3000);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(task);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO: inflate a fragment view
        View rootView = super.onCreateView(inflater, container, savedInstanceState);
        ButterKnife.bind(this, rootView);
        return rootView;
    }


    @OnClick({R.id.user_icon, R.id.go_info_modified, R.id.mine_setting, R.id.mine_msg, R.id.click_login, R.id.mine_mymsg, R.id.mine_mypost, R.id.mine_mysave, R.id.mine_comments, R.id.mine_contribution, R.id.mine_my_answer, R.id.mine_myactive, R.id.mine_logout})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.user_icon:
                if (isLogined) {
                    Intent intent_msg = new Intent(mContext, ModificationActivity.class);
                    startActivityForResult(intent_msg, 1);
                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.go_info_modified:
                if (isLogined) {
                    Intent intent_msg = new Intent(mContext, ModificationActivity.class);
                    startActivityForResult(intent_msg, 1);
                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;

            case R.id.mine_setting:
                // 设置
                if (isLogined) {

                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.mine_msg:
                //消息
                if (isLogined) {

                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.click_login:
                //先判断是否已经登录
                if (isLogined) {
                    Toast.makeText(mContext, "您已经登录，别瞎点了", Toast.LENGTH_LONG).show();
                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.mine_mymsg:
                // 我的消息
                LogUtil.E("我的信息");
                //先判断是否登录
                if (isLogined) {
                    Intent intent_msg = new Intent(mContext, ModificationActivity.class);
                    startActivityForResult(intent_msg, 1);
                } else {
                    Intent intent_login = new Intent(mContext, LoginActivity.class);
                    startActivity(intent_login);
                }
                break;
            case R.id.mine_mypost:
                // 我的帖子
                if (isLogined) {
                    LogUtil.E("进入我的帖子页面");
                    Intent myPostIntent = new Intent(mContext, MyPostsActivity.class);
                    myPostIntent.putExtra("userId", result.getContent().getUserId());
                    myPostIntent.putExtra("password", result.getContent().getUserPassword());
                    startActivity(myPostIntent);
                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.mine_mysave:
                // 点赞我的
                if (isLogined) {
                    LogUtil.E("进点赞我的页面");
                    Intent intent_comment = new Intent(mContext, MyUpvoteActivity.class);
                    intent_comment.putExtra("userId", result.getContent().getUserId());
                    intent_comment.putExtra("password", result.getContent().getUserPassword());
                    startActivity(intent_comment);
                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.mine_comments:
                // 评论管理
                if (isLogined) {
                    LogUtil.E("进入评论管理页面");
                    Intent intent_comment = new Intent(mContext, CommentsActivity.class);
                    intent_comment.putExtra("userId", result.getContent().getUserId());
                    intent_comment.putExtra("password", result.getContent().getUserPassword());
                    startActivity(intent_comment);
                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.mine_contribution:
                // 我的贡献
                if (isLogined) {
                    LogUtil.E("进我的收藏页面");
                    Intent intent_comment = new Intent(mContext, MyCollectActivity.class);
                    intent_comment.putExtra("userId", result.getContent().getUserId());
                    //intent_comment.putExtra("password",result.getContent().getUserPassword());
                    startActivity(intent_comment);
                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.mine_my_answer:
                // 我的回答
                if (isLogined) {

                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.mine_myactive:
                // 我的活动
                if (isLogined) {

                } else {
                    LogUtil.E("跳转登录页面");
                    Intent intent = new Intent(mContext, LoginActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.mine_logout:
                // 退出登录
                LogUtil.E("退出登录");
                if (isLogined) {
                    SharePresUtil.setObject2SharePres(mContext, null, "userObject");
                    TokenManager.delteCurrentToken(mContext);
                    refreshIcon();
                    refreshUnreadCount();
                    isLogined = false;
                    Toast.makeText(mContext, "已退出登录", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(mContext, "您歇会儿，都还没登录呢", Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 1) {
            String s = data.getStringExtra("refresh");
            if (s.equals("1")) {
                refreshIcon();
            }
        }
    }


    private void refreshUnreadCount() {
        handler.removeCallbacks(task);
        //把未读消息清空
        mUnreadUpvoteCount.setVisibility(View.INVISIBLE);
        mUnreadCommentCount.setVisibility(View.INVISIBLE);
    }

    private void refreshIcon() {

        if (SharePresUtil.getObjectFromSharePres(mContext, "userObject") != null) {

            result = (Result<UserDto>)
                    SharePresUtil.getObjectFromSharePres(mContext, "userObject");

            if (result != null) {
                mUserName.setText(result.getContent().getUserName());

                Glide.with(mContext).load(result.getContent()
                        .getUserLogo()).bitmapTransform(new
                        CropCircleTransformation(mContext))
                        .override(90, 90).error(R.drawable.login_icon)
                        .skipMemoryCache(true).diskCacheStrategy
                        (DiskCacheStrategy.NONE).into(mUserIcon);
            }
        } else {
            mUserName.setText("请登录");
            mUserSchool.setText("");
            Glide.with(mContext).load(R.drawable.login_icon).bitmapTransform(new
                    CropCircleTransformation(mContext))
                    .override(90, 90)
                    .skipMemoryCache(true).diskCacheStrategy
                    (DiskCacheStrategy.NONE).into(mUserIcon);
        }

    }

    @Override
    public void onHiddenChanged(boolean hidd) {
        if (!hidd) {//当fragment从隐藏到出现的时候
            //refreshIcon();
        }
    }
}
