package app.campus.heart.com.campus.ui.customs;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import app.campus.heart.com.campus.R;

/**
 * @author: Veyron
 * @date：2018/02/03
 */
public class CommentListViewHolder extends RecyclerView.ViewHolder {
    public TextView  common1,common2,content,date,click_delete,flag_delete;
    public ImageView userIcon,coverImg;
    public LinearLayout layout,reply_layout;

    public CommentListViewHolder(View view) {
        super(view);
        layout = (LinearLayout) view.findViewById(R.id.item_layout);
        reply_layout = (LinearLayout) view.findViewById(R.id.reply_layout);
        userIcon = (ImageView)view.findViewById(R.id.userIcon);
        coverImg = (ImageView)view.findViewById(R.id.coverImg);
        common1 = (TextView) view.findViewById(R.id.common1);
        common2 = (TextView) view.findViewById(R.id.common2);
        date = (TextView) view.findViewById(R.id.date);
        click_delete = (TextView) view.findViewById(R.id.click_delete);
        content = (TextView)view.findViewById(R.id.content);
        flag_delete = (TextView)view.findViewById(R.id.item_delete);
    }
}
