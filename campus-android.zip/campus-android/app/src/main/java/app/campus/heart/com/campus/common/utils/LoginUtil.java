package app.campus.heart.com.campus.common.utils;

import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import app.campus.heart.com.campus.common.token.TokenManager;
import app.campus.heart.com.campus.ui.activity.LoginActivity;

/**
 * @author: yuwu
 * @date: 2018/5/7
 */
public class LoginUtil {

    public static void requestLogin(Context context){
        TokenManager.delteCurrentToken(context);
        SharePresUtil.setObject2SharePres(context, null, "userObject");
        Intent intent = new Intent(context, LoginActivity.class);
        context.startActivity(intent);
        Toast.makeText(context, "您的登录会话已过期, 请重新登录", Toast.LENGTH_LONG).show();
    }
}
