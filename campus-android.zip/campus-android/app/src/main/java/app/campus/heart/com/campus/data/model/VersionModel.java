package app.campus.heart.com.campus.data.model;

import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.data.api.VersionApiService;
import app.campus.heart.com.campus.data.dto.AppVersionDto;
import rx.Observable;

/**
 * @author: Veyron
 * @date：2018/4/4
 */

public class VersionModel {
    private VersionApiService mService;

    public VersionModel(VersionApiService service) {
        mService = service;
    }

    public Observable<Result<AppVersionDto>> getNewAppVersion(){
        return mService.getNewAppVersion();
    }
}
