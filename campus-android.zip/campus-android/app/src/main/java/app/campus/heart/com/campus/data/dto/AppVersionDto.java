package app.campus.heart.com.campus.data.dto;

import app.campus.heart.com.campus.common.domain.AbstractModel;

/**
 * @author: Veyron
 * @date：2018/4/4
 */

public class AppVersionDto extends AbstractModel {
    /**
     * 版本号
     */
    private String  version;

    /**
     * 存放路径
     */
    private String  filePath;

    /**
     * 版本描述
     */
    private String  desc;

    /**
     * 删除逻辑位
     */
    private Integer status;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
