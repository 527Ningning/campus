package app.campus.heart.com.campus.ui.activity;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.donkingliang.labels.LabelsView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import app.campus.heart.com.campus.R;
import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.utils.KeyBoardUtil;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.common.utils.SharePresUtil;
import app.campus.heart.com.campus.common.utils.StringUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.SearchPresenter;
import app.campus.heart.com.campus.data.dto.HotItemDto;
import app.campus.heart.com.campus.data.dto.LabelDto;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import dmax.dialog.SpotsDialog;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;


/**
 * 搜索页面
 *
 * @author: Veyron
 * @date：2018/04/26
 */
public class SearchActivity extends AppCompatActivity {

    @BindView(R.id.go_back)
    ImageView mGoBack;
    @BindView(R.id.edit_search)
    EditText mEditSearch;
    @BindView(R.id.edit_reset)
    TextView mEditReset;

    @BindView(R.id.labels_post_hot)
    LabelsView mLabels;

    @BindView(R.id.labels_most_hot)
    LabelsView mMostHotLabels;

    @BindView(R.id.labels_history)
    LabelsView mHistoryLabels;

    @BindView(R.id.delete_history_search)
    TextView mDeteleHistorySearch;

    @BindView(R.id.change_next_hot_post)
    TextView mChangeNextHotPost;

    @BindView(R.id.change_next_most_hot)
    TextView mChangeNextMostHot;

    private SearchPresenter mPresenter;

    private String userId;
    private String tmpUserId;

    private Retrofit mRetrofit;
    private SpotsDialog mDialog;
    private String key;
    private Boolean isLogined = false;

    private List<LabelDto> dataList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        ButterKnife.bind(this);
        mDialog = new SpotsDialog(this, "拼命搜索中....");

        Intent i = getIntent();
        isLogined = i.getBooleanExtra("isLogined", false);
        if (isLogined) {
            userId = i.getStringExtra("userId");
        } else {
            tmpUserId = i.getStringExtra("tmpUserId");
            userId = tmpUserId;//这样操作，后面都用 userId 即可。反正都有id
        }
        initRetrofit();
        initView();
        initEditCondition();
        //直接在界面SearchView搜索
        if (i.getStringExtra("key") != null) {
            key = i.getStringExtra("key");
            goToSearch(key);
        }
        setLabelData();
    }

    private void setLabelData() {
        LinkedList<String> historyLabels;
        //SharePresUtil.setObject2SharePres(SearchActivity.this, null, "searchHistory");
        // 标签 list
        if (SharePresUtil.getObjectFromSharePres(this, "searchHistory") != null) {
            historyLabels = (LinkedList<String>) SharePresUtil.getObjectFromSharePres(this, "searchHistory");
            mHistoryLabels.setLabels(historyLabels);
            mHistoryLabels.setSelectType(LabelsView.SelectType.SINGLE_IRREVOCABLY);
            mHistoryLabels.setOnLabelClickListener(new LabelsView.OnLabelClickListener() {
                @Override
                public void onLabelClick(View label, String labelText, int position) {
                    LogUtil.E("position: " + mHistoryLabels.getLabels().get(position));
                    key = mHistoryLabels.getLabels().get(position);
                    goToSearch(key);
                }
            });
        }
        ArrayList<String> label = new ArrayList<>();
        ArrayList<String> hotLabel = new ArrayList<>();

        label.add("洪崖洞");
        label.add("取快递");
        label.add("王者荣耀");
        label.add("青年节");
        label.add("健身达人");
        label.add("读书节");
        label.add("荔枝");
        label.add("图书馆");
        label.add("摄影约拍");
        label.add("相约烤吧");

        hotLabel.add("25教");
        hotLabel.add("大疆宣讲会");
        hotLabel.add("奇妙干锅");
        hotLabel.add("毕业季");
        hotLabel.add("校运会");
        hotLabel.add("二号门");
        hotLabel.add("绝味鸭脖");
        hotLabel.add("五一");
        hotLabel.add("父亲节");
        hotLabel.add("西大航拍");
        hotLabel.add("西南大学");
        hotLabel.add("计信院");
        hotLabel.add("贸易战");
        hotLabel.add("火锅");

        mLabels.setLabels(label);
        mLabels.setSelectType(LabelsView.SelectType.SINGLE_IRREVOCABLY);
        mLabels.setOnLabelClickListener(new LabelsView.OnLabelClickListener() {
            @Override
            public void onLabelClick(View label, String labelText, int position) {
                LogUtil.E("position: " + mLabels.getLabels().get(position));
                key = mLabels.getLabels().get(position);
                goToSearch(key);
            }
        });

        mMostHotLabels.setLabels(hotLabel);
        mMostHotLabels.setSelectType(LabelsView.SelectType.SINGLE_IRREVOCABLY);
        mMostHotLabels.setOnLabelClickListener(new LabelsView.OnLabelClickListener() {
            @Override
            public void onLabelClick(View label, String labelText, int position) {
                LogUtil.E("position: " + mMostHotLabels.getLabels().get(position));
                key = mMostHotLabels.getLabels().get(position);
                goToSearch(key);
            }
        });


    }

    private void initRetrofit() {
        mRetrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }

    // 预留着，以后用
    private void initView() {

    }

    private void initEditCondition() {
        mEditSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    KeyBoardUtil.hideSoftInputMethod(SearchActivity.this);
                    key = v.getText().toString();
                    //Toast.makeText(SearchActivity.this,key,Toast.LENGTH_SHORT).show();
                    goToSearch(key);
                    return true;
                }
                return false;
            }
        });
    }

    // 发起搜索请求
    private void goToSearch(final String key) {
        mDialog.show();
        mPresenter = new SearchPresenter(new CallBack<PageList<HotItemDto>>() {
            @Override
            public void showResult(Result<PageList<HotItemDto>> result) {
                //拿到数据，把数据传到 SearchResultActivity页面展示
                // 开启另一个页面
                goToShowResults(result);
                LinkedList<String> tmpList;
                if (SharePresUtil.getObjectFromSharePres(SearchActivity.this, "searchHistory") == null) {
                    tmpList = new LinkedList<>();
                    tmpList.add(key);
                } else {
                    tmpList = (LinkedList<String>) SharePresUtil.getObjectFromSharePres(SearchActivity.this, "searchHistory");
                    if (!tmpList.contains(key)) {
                        if (tmpList.size() > 10) {
                            tmpList.removeFirst();
                        }
                        tmpList.add(key);
                    }
                }
                SharePresUtil.setObject2SharePres(SearchActivity.this, tmpList, "searchHistory");
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {
                mDialog.dismiss();
            }

            @Override
            public void showError(String msg) {
                Toast.makeText(SearchActivity.this, "π_π..找不到结果", Toast.LENGTH_SHORT).show();
                LogUtil.E(msg);
            }

            @Override
            public void showSuccess(String msg) {

            }
        }, mRetrofit);
//                LogUtil.E("userId", userId);
            LogUtil.E("key", key);
            mPresenter.getSearchResults(userId, 1, key);
    }

    private void goToShowResults(Result<PageList<HotItemDto>> result) {

        Intent intent = new Intent(SearchActivity.this, SearchResultsActivity.class);

        intent.putExtra("userId", userId);
        intent.putExtra("key", key);
        intent.putExtra("result", result);
        startActivity(intent);
    }

    @OnClick({R.id.go_back, R.id.edit_reset, R.id.delete_history_search, R.id.change_next_most_hot, R.id.change_next_hot_post})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.delete_history_search:
                SharePresUtil.setObject2SharePres(SearchActivity.this, null, "searchHistory");
                mHistoryLabels.setLabels(null);
                break;
            case R.id.go_back:
                finish();
                break;
            case R.id.edit_reset:
                finish();
                break;
            case R.id.change_next_most_hot:
                List<String> tmpList = new ArrayList<>(Arrays.asList(new String[mMostHotLabels.getLabels()
                        .size()]));
                Collections.copy(tmpList, mMostHotLabels.getLabels());
                Collections.shuffle(tmpList);
                //LogUtil.E("most_hot_size = ", String.valueOf(tmpList.size()));
                mMostHotLabels.setLabels(tmpList);
                mMostHotLabels.setOnLabelClickListener(new LabelsView.OnLabelClickListener() {
                    @Override
                    public void onLabelClick(View label, String labelText, int position) {
                        LogUtil.E("position: " + mMostHotLabels.getLabels().get(position));
                        key = mMostHotLabels.getLabels().get(position);
                        goToSearch(key);
                    }
                });
                //mMostHotLabels.setLabels(Collections.shuffle(mMostHotLabels.getLabels()));
                break;
            case R.id.change_next_hot_post:
                List<String> tmpList1 = new ArrayList<>(Arrays.asList(new String[mLabels.getLabels()
                        .size()]));
                Collections.copy(tmpList1, mLabels.getLabels());
                Collections.shuffle(tmpList1);
                LogUtil.E("hot_size = ", String.valueOf(tmpList1.size()));
                mLabels.setLabels(tmpList1);
                mLabels.setOnLabelClickListener(new LabelsView.OnLabelClickListener() {
                    @Override
                    public void onLabelClick(View label, String labelText, int position) {
                        LogUtil.E("position: " + mLabels.getLabels().get(position));
                        key = mLabels.getLabels().get(position);
                        goToSearch(key);
                    }
                });
                //mMostHotLabels.setLabels(Collections.shuffle(mMostHotLabels.getLabels()));
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setLabelData();
    }
}
