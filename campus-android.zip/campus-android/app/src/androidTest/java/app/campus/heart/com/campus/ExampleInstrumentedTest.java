package app.campus.heart.com.campus;

import android.content.Context;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import app.campus.heart.com.campus.common.Constants;
import app.campus.heart.com.campus.common.page.PageList;
import app.campus.heart.com.campus.common.result.Result;
import app.campus.heart.com.campus.common.utils.LogUtil;
import app.campus.heart.com.campus.controller.contact.CallBack;
import app.campus.heart.com.campus.controller.persenter.PostPresenter;
import app.campus.heart.com.campus.data.api.PostApiService;
import app.campus.heart.com.campus.data.api.UserApiService;
import app.campus.heart.com.campus.data.dto.MyArticleItemDto;
import app.campus.heart.com.campus.data.dto.PostTypeDto;
import app.campus.heart.com.campus.data.dto.TopArticleDto;
import app.campus.heart.com.campus.data.dto.UserDto;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

import static org.junit.Assert.*;

/**
 * Instrumentation test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    @Test
    public void useAppContext() throws Exception {
        // Context of the app under test.
        Context appContext = InstrumentationRegistry.getTargetContext();

        assertEquals("app.campus.heart.com.campus", appContext.getPackageName());
    }

    // 测试 我的帖子  接口
    @Test
    public void test_myPosts() throws Exception {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
        PostPresenter mPresenter = new PostPresenter(new CallBack<PageList<MyArticleItemDto>>() {
            @Override
            public void showResult(Result<PageList<MyArticleItemDto>> result) {
                LogUtil.E(result.getContent().getDataList().toString());
            }

            @Override
            public void showLodading() {

            }

            @Override
            public void dimissLoading() {

            }

            @Override
            public void showError(String msg) {
                LogUtil.E(msg);
            }

            @Override
            public void showSuccess(String msg) {
                LogUtil.E(msg);
            }
        },retrofit);
        mPresenter.getMyPostLists("201411672127",1,1);
    }


    // 测试 根据学号获取用户信息  接口
    @Test
    public void getUserByStuno(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

        UserApiService mApiService = retrofit.create(UserApiService.class);

        mApiService.getUser("201411672128")
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<UserDto>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                         LogUtil.E(e.toString());
                    }

                    @Override
                    public void onNext(Result<UserDto> result) {
                         LogUtil.E(result.toString());
                    }
                });
    }


    // 测试 获取所有帖子类型  接口
    @Test
    public void getAllPostType(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

        PostApiService mApiService = retrofit.create(PostApiService.class);

        mApiService.getAllPostType()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<PageList<PostTypeDto>>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {

                    }

                    @Override
                    public void onNext(Result<PageList<PostTypeDto>> result) {
                         LogUtil.E(result.toString());
                    }
                });
    }

    @Test
    public void getTopArticle(){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

        PostApiService mApiService = retrofit.create(PostApiService.class);

        mApiService.getTopArticle(1)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Subscriber<Result<List<TopArticleDto>>>() {
                    @Override
                    public void onCompleted() {

                    }

                    @Override
                    public void onError(Throwable e) {
                        LogUtil.E(e.toString());
                    }

                    @Override
                    public void onNext(Result<List<TopArticleDto>> result) {
                            LogUtil.E(result.toString());
                    }
                });
    }
}
