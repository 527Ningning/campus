# campus-android

## 项目名称
`Campus Android App`

**西南大学校园信息共享平台**
## Author
- 吴宇桐
- 吴威龙
## 项目架构
- 开发模式：MVP
- 网络框架：Retrofit
- 短信验证：MOB
- 图片加载：Glide
- 主页架构：Fragment+RadioButton
- 异步框架：RxJava
- Json框架：Gson
- 框架整合：Retrofit+RxJava+Gson


## 接口文档
- https://www.eolinker.com/

## 原型设计
- https://modao.cc/app/d5ea3b736f7b5222267a8e7dab58297035802de7

## ToDo List
- 评论管理模块
